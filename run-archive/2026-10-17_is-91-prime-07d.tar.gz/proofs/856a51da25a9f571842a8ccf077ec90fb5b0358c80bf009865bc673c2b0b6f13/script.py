primes = [p for p in range(2, 100) if all(p % d for d in range(2, int(p ** 0.5) + 1))]
print("primes below 100:", len(primes), "largest:", primes[-1])
print("91 among them:", 91 in primes)
