def mul(x, y):
    a, b = x
    c, d = y
    return (a * c - b * d, a * d + b * c)
def norm(x):
    return x[0] * x[0] + x[1] * x[1]
z, zc = (3, 2), (3, -2)
print("(3+2i)(3-2i) =", mul(z, zc))
print("7(3+2i)(3-2i) =", mul(mul((7, 0), z), zc))
print("norms of 3+2i and 3-2i:", norm(z), norm(zc))
print("91^2 == 49*13*13:", 91 ** 2 == 49 * 13 * 13)
