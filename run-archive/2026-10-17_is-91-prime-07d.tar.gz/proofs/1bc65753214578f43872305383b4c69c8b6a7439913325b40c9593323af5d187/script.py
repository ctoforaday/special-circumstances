# Blue-respond computation: arithmetic behind the report's claims about 91.
# Reproduce: python3 -I blue-respond_verify91.py   (no arguments, no network)
from math import gcd, isqrt

def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

n = 91
units = [a for a in range(1, n) if gcd(a, n) == 1]          # unit group mod 91
bases = [a for a in units if a != 1]                         # bases 2..90 sharing no factor with 91
passes = [a for a in bases if pow(a, n - 1, n) == 1]
fails = [a for a in bases if pow(a, n - 1, n) != 1]
print("Fermat bases 2..90 coprime to 91:", len(bases), "pass:", len(passes), "fail:", len(fails))
print("Units mod 91 (including 1):", len(units), "witnesses among them:", len(fails),
      "fraction:", len(fails) / len(units))
print("2^90 mod 91 =", pow(2, 90, 91), "; 2^91 mod 91 =", pow(2, 91, 91))
print("3^90 mod 91 =", pow(3, 90, 91), "; 3^91 mod 91 =", pow(3, 91, 91))
print("64^90 mod 91 =", pow(64, 90, 91))
print("91 is prime (trial division):", is_prime(91))

r = isqrt(91)
ps = [p for p in range(2, r + 1) if is_prime(p)]
divs = [p for p in ps if 91 % p == 0]
print("isqrt(91) =", r, "; primes up to it:", ps, "; those dividing 91:", divs,
      "; cofactor:", 91 // divs[0], "; cofactor prime:", is_prime(91 // divs[0]))
print("all divisors of 91 by brute force:", [d for d in range(1, 92) if 91 % d == 0])

small_primes = [p for p in range(2, 100) if is_prime(p)]
print("primes below 100:", len(small_primes), "largest:", small_primes[-1], "91 among them:", 91 in small_primes)

# Gaussian integers: (a,b) represents a+bi
def gmul(x, y):
    return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
print("(3+2i)(3-2i) =", gmul((3, 2), (3, -2)), "; 7*13 =", 7 * 13)
print("91^2 =", 91 * 91, "; 49*13*13 =", 49 * 13 * 13)

# Bound check: for composite n that is not Carmichael, witnesses are at least half of the units mod n.
checked = 0
carmichael = []
violations = []
minfrac = 1.0
for m in range(4, 5000):
    if is_prime(m):
        continue
    U = [a for a in range(1, m) if gcd(a, m) == 1]
    W = sum(1 for a in U if pow(a, m - 1, m) != 1)
    if W == 0:
        carmichael.append(m)
        continue
    checked += 1
    f = W / len(U)
    minfrac = min(minfrac, f)
    if f < 0.5:
        violations.append(m)
print("composites below 5000 that are not Carmichael:", checked,
      "; minimum witness fraction:", round(minfrac, 6), "; violations of the half bound:", violations)
print("Carmichael numbers below 5000 found:", carmichael)
