n = 91
print("all divisors of 91:", [d for d in range(1, n + 1) if n % d == 0])
