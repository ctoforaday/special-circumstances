import math
n = 91
print("2^90 mod 91 =", pow(2, 90, n))
print("2^91 mod 91 =", pow(2, 91, n))
print("3^90 mod 91 =", pow(3, 90, n))
print("64^90 mod 91 =", pow(64, 90, n))
bases = [a for a in range(2, n) if math.gcd(a, n) == 1]
passing = [a for a in bases if pow(a, n - 1, n) == 1]
print("bases from 2 to 90 sharing no factor with 91:", len(bases))
print("passing Fermat test:", len(passing), "failing:", len(bases) - len(passing))
