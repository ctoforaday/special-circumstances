import math
n = 91
r = math.isqrt(n)
primes = [p for p in range(2, r + 1) if all(p % d for d in range(2, math.isqrt(p) + 1))]
print("sqrt(91) =", round(math.sqrt(n), 2))
print("primes up to sqrt(91):", primes)
divisors = [p for p in primes if n % p == 0]
print("primes that divide 91:", divisors)
print("cofactor:", n // divisors[0], "is prime:", all((n // divisors[0]) % d for d in range(2, math.isqrt(n // divisors[0]) + 1)))
