import math

n = 91

print("sqrt(91) =", math.sqrt(n))
print("sqrt(91) rounded to 2 places =", round(math.sqrt(n), 2))
print("primes p with p <= sqrt(91) =", [p for p in range(2, 10) if all(p % q for q in range(2, p))])
print("divisors d of 91 with 1 < d < 91 =", [d for d in range(2, n) if n % d == 0])
print("2^90 mod 91 =", pow(2, 90, n))
print("2^90 mod 7 =", pow(2, 90, 7), " 2^90 mod 13 =", pow(2, 90, 13))
print("90! mod 91 =", math.factorial(90) % n)
print("6! mod 7 =", math.factorial(6) % 7, " 12! mod 13 =", math.factorial(12) % 13)
print("3^91 mod 91 =", pow(3, 91, n))
print("(3+2i)(3-2i) =", (3 + 2j) * (3 - 2j))
