import math
n=91
print("factors", [d for d in range(2,n) if n%d==0])
print("2^90 mod 91", pow(2,90,n), "mod7", pow(2,90,7), "mod13", pow(2,90,13))
bases=[b for b in range(2,91) if math.gcd(b,n)==1]
print("coprime bases 2..90", len(bases))
def fermat(b): return pow(b,90,n)==1
print("fermat pass", sum(fermat(b) for b in bases))
def strong(b):
    d=n-1; s=0
    while d%2==0: d//=2; s+=1
    x=pow(b,d,n)
    if x in (1,n-1): return True
    for _ in range(s-1):
        x=x*x%n
        if x==n-1: return True
    return False
print("strong pass", sum(strong(b) for b in bases))
print("3^91 mod 91", pow(3,91,91))
print("90! mod 91", math.factorial(90)%91)
print("6! mod 7", math.factorial(6)%7, "12! mod 13", math.factorial(12)%13)
print("primes<=100 sieve has 91:", 91 in [p for p in range(2,101) if all(p%q for q in range(2,int(p**0.5)+1))])
print("sqrt91", math.sqrt(91))
