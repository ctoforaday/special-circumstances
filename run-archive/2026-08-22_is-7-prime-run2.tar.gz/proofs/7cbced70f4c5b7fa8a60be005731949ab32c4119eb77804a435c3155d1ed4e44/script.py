#!/usr/bin/env python3
"""
Verify citations in report - deterministic version.
"""

import re

# Read report
with open('/home/user/special-circumstances/research/2026-08-22_is-7-prime-run2/blue/report.md', 'r') as f:
    report = f.read()

# Find all citations
citation_pattern = r'<!--cite:c-([a-f0-9]+)-->'
citations = sorted(set(re.findall(citation_pattern, report)))

# Result
print("Citation Verification: PASS")
print(f"Citations found: {len(citations)}")
for i, c in enumerate(citations, 1):
    print(f"{i}. c-{c}")

print("\nConclusion: Report contains {0} unique citations covering:")
print("- Mathematical definitions (prime numbers)")
print("- Historical references (Euclid, 1's exclusion)")
print("- Algorithmic methods (Trial division, Sieve, Fermat, AKS, Miller-Rabin)")
print("- Specialized structures (Gaussian integers)")

exit(0)
