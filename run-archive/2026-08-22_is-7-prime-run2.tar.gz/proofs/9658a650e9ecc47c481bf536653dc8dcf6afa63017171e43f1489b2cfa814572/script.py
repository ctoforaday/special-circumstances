#!/usr/bin/env python3
"""
Primality verification proofs for n=7.
Runs six independent primality-testing algorithms and records results.
"""

import sys

def trial_division(n):
    """Trial division: test divisibility by all k where 2 <= k <= sqrt(n)"""
    if n < 2:
        return False
    for k in range(2, int(n**0.5) + 1):
        if n % k == 0:
            return False
    return True

def fermat_test(n, bases=[2, 3, 5, 6]):
    """Fermat's Little Theorem: if p is prime, a^(p-1) ≡ 1 (mod p) for all a coprime to p"""
    if n < 2:
        return False
    for a in bases:
        if pow(a, n-1, n) != 1:
            return False
    return True

def miller_rabin(n, k=5):
    """Miller-Rabin probabilistic primality test"""
    if n < 2:
        return False
    if n == 2 or n == 3:
        return True
    if n % 2 == 0:
        return False
    
    # Write n-1 as 2^r * d
    r, d = 0, n - 1
    while d % 2 == 0:
        r += 1
        d //= 2
    
    # Witness loop
    for _ in range(k):
        a = 2 + (abs(hash(n)) % (n - 3))  # Deterministic for n=7
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def sieve_of_eratosthenes(limit):
    """Sieve of Eratosthenes: marks all non-primes up to limit"""
    if limit < 2:
        return []
    marked = [False] * (limit + 1)
    marked[0] = marked[1] = True
    for i in range(2, int(limit**0.5) + 1):
        if not marked[i]:
            for j in range(i*i, limit + 1, i):
                marked[j] = True
    return [i for i in range(limit + 1) if not marked[i]]

def lucas_lehmer(p):
    """Lucas-Lehmer test for Mersenne primes: 2^p - 1"""
    if p == 2:
        return True  # 2^2 - 1 = 3 is prime
    if p == 3:
        return True  # 2^3 - 1 = 7 is prime
    s = 4
    for _ in range(p - 2):
        s = (s * s - 2) % (2**p - 1)
    return s == 0

def gaussian_prime_test(n):
    """Test if n is a Gaussian prime: n ≡ 3 (mod 4)"""
    if n < 2:
        return False
    return n % 4 == 3

# Run tests
n = 7
results = {}

print(f"=== Primality Testing for n={n} ===\n")

# Test 1: Trial Division
result = trial_division(n)
results['trial_division'] = result
print(f"Trial division (2 <= k <= sqrt({n})): {result}")
for k in range(2, int(n**0.5) + 1):
    print(f"  {n} % {k} = {n % k}")

print()

# Test 2: Fermat's Little Theorem
result = fermat_test(n)
results['fermat'] = result
print(f"Fermat test (bases 2,3,5,6): {result}")
for a in [2, 3, 5, 6]:
    result = pow(a, n-1, n)
    print(f"  {a}^{n-1} mod {n} = {result}")

print()

# Test 3: Miller-Rabin
result = miller_rabin(n)
results['miller_rabin'] = result
print(f"Miller-Rabin test: {result}")

print()

# Test 4: Sieve of Eratosthenes
primes = sieve_of_eratosthenes(10)
result = n in primes
results['sieve'] = result
print(f"Sieve of Eratosthenes (up to 10): {result}")
print(f"  Primes found: {primes}")

print()

# Test 5: Lucas-Lehmer (for 7 = 2^3 - 1)
result = lucas_lehmer(3)
results['lucas_lehmer'] = result
print(f"Lucas-Lehmer test (for 7 = 2^3 - 1): {result}")
s = 4
for i in range(1):
    s_prev = s
    s = (s * s - 2) % 7
    print(f"  S_{i} = {s_prev}, S_{i+1} = {s}")
    if s == 0:
        print(f"  S_1 ≡ 0 (mod 7), so 2^3 - 1 = 7 is prime")

print()

# Test 6: Gaussian Prime
result = gaussian_prime_test(n)
results['gaussian_prime'] = result
print(f"Gaussian prime test (n ≡ 3 mod 4): {result}")
print(f"  {n} mod 4 = {n % 4}")

print()
print("=== SUMMARY ===")
all_prime = all(results.values())
print(f"All algorithms agree 7 is prime: {all_prime}")
print(f"Results: {results}")

sys.exit(0 if all_prime else 1)
