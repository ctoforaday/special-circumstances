# Recorded computation behind the report's arithmetic claims about 91.
# Pure integer arithmetic; no randomness, no network, no tool calls.
import math

N = 91

divisors = [d for d in range(1, N + 1) if N % d == 0]
print("positive divisors of 91:", divisors)

primes_upto_9 = [p for p in range(2, 10) if all(p % q for q in range(2, p))]
print("primes up to 9:", primes_upto_9)
print("first prime in that list dividing 91:", next(p for p in primes_upto_9 if N % p == 0))
print("91 divided by 7:", N // 7, "is prime:", all((N // 7) % q for q in range(2, N // 7)))

print("2^90 mod 91:", pow(2, 90, N), "passes base-2 Fermat:", pow(2, 90, N) == 1)
print("2^90 mod 7:", pow(2, 90, 7), "mod 13:", pow(2, 90, 13))
print("3^90 mod 91:", pow(3, 90, N), "passes base-3 Fermat:", pow(3, 90, N) == 1)

coprime = [b for b in range(2, N) if math.gcd(b, N) == 1]
fermat_pass = [b for b in coprime if pow(b, N - 1, N) == 1]
print("coprime bases 2..90:", len(coprime))
print("Fermat passers among them:", len(fermat_pass), "base 3 included:", 3 in fermat_pass)

n1, d = N - 1, N - 1
s = 0
while d % 2 == 0:
    d //= 2
    s += 1
print("n-1 = 2^%d * %d" % (s, d))

def strong_passes(b):
    x = pow(b, d, N)
    if x in (1, N - 1):
        return True
    for _ in range(s - 1):
        x = x * x % N
        if x == N - 1:
            return True
    return False

print("3^45 mod 91:", pow(3, 45, N), "base-3 strong passes:", strong_passes(3))
strong_pass = [b for b in coprime if strong_passes(b)]
print("strong passers among coprime bases:", len(strong_pass), "base 9 included:", 9 in strong_pass)
