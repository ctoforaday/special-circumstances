# Fermat residues of 91 in bases 2 and 3, and the factor check, for the synthesis.
import math

n = 91
r2 = pow(2, n - 1, n)
r3 = pow(3, n - 1, n)
print(f"n={n} base2_residue={r2} base3_residue={r3}")
print(f"base2_witnesses_compositeness={r2 != 1} base3_passes_test={r3 == 1}")
print(f"crt_check_mod7_base3={pow(3, 90, 7)} mod13_base3={pow(3, 90, 13)}")
print(f"factor_7_divides_91={n % 7 == 0} cofactor={n // 7} is_7x13={7 * 13 == n}")
print(f"sqrt_91_floor={math.isqrt(n)}")
