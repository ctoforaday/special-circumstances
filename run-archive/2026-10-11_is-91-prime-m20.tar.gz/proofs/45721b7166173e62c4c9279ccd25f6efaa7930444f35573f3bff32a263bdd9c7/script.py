# Settles whether 91 is prime: trial division by every integer 2..floor(sqrt(91)),
# a base-2 Fermat residue, and a sieve of primes below 100 for cross-check.
import math

n = 91
limit = math.isqrt(n)
divisors = [d for d in range(2, limit + 1) if n % d == 0]
print(f"n={n} isqrt={limit} trial_divisors={divisors}")

# Smallest factor (the trial-division witness) and cofactor
smallest = next((d for d in range(2, n) if n % d == 0), None)
print(f"smallest_factor={smallest} cofactor={n // smallest if smallest else None}")
print(f"product_check_7x13={7 * 13 == n}")

# Contrary hypothesis: every prime <= sqrt(n) fails to divide n?
primes_le_limit = [p for p in range(2, limit + 1) if all(p % q for q in range(2, math.isqrt(p) + 1))]
print(f"primes_le_sqrt={primes_le_limit}")
print(f"remainders={[(p, n % p) for p in primes_le_limit]}")

# Fermat test base 2
r = pow(2, n - 1, n)
print(f"fermat_base2_residue_2^(n-1)_mod_n={r} witnesses_compositeness={r != 1}")

# Sieve of primes below 100, membership of 91
sieve = [True] * 100
sieve[0] = sieve[1] = False
for i in range(2, 10):
    if sieve[i]:
        for j in range(i * i, 100, i):
            sieve[j] = False
primes_below_100 = [i for i, v in enumerate(sieve) if v]
print(f"count_primes_below_100={len(primes_below_100)} 91_in_list={91 in primes_below_100}")
