import json, subprocess, sys

RUN = "/home/gblock_ctoforaday_com/.claude/scratch/universe-m20/src/research/2026-10-11_is-91-prime"
BIN = RUN + "/.bin/feov-record"

def proj(*args):
    out = subprocess.run([BIN, "--run", RUN, "--seat-id", "blue-respond", "show", *args, "--json"],
                         capture_output=True, text=True, check=True).stdout
    return json.loads(out)

# Each concluded approach is matched to the one bullet that names it, by a fixed key phrase.
PURSUED_KEY = {
    "Q-f478908d": "Trial division",
    "Q-510a1748": "sieve",
    "Q-0008cd4d": "A000040",
    "Q-a10bf632": "base-2",
    "Q-87d5de86": "base-3",
    "Q-5b68435a": "If 91 were prime",
    "Q-0f08f554": "Two published records",
}
REJECTED_KEY = {
    "Q-33c7bb11": "Miller-Rabin",
    "Q-d7f80d63": "certificate",
    "Q-671e099c": "published claim",
}

av = proj("avenues")["avenues"]
lines = proj("report")["lines"]

def bullets_under(term):
    heads = {l["heading"] for l in lines if term.lower() in l["heading"].lower()}
    return [l["text"].strip() for l in lines
            if l["heading"] in heads and l["text"].strip().startswith("- ")]

pursued = bullets_under("Pursued and concluded")
rejected = bullets_under("Weighed and rejected")
future = bullets_under("Future research")

concluded = [a for a in av if a["status"] == "concluded"]
declined_or_abandoned = [a for a in av if a["status"] in ("declined", "abandoned")]
deferred = [a for a in av if a["status"] == "deferred"]

failures = []
print("concluded approaches (status concluded):", len(concluded))
print("bullets under 'Pursued and concluded':", len(pursued))
for a in concluded:
    key = PURSUED_KEY.get(a["id"])
    if key is None:
        failures.append(f"{a['id']} concluded but has no key phrase")
        continue
    hits = [b for b in pursued if key.lower() in b.lower()]
    print(f"  {a['id']} hypothesis: {a['hypothesis']}")
    print(f"    named by {len(hits)} bullet(s) via key '{key}'")
    if len(hits) != 1:
        failures.append(f"{a['id']} named by {len(hits)} bullets, need exactly 1")
for b in pursued:
    hits = [k for k in PURSUED_KEY.values() if k.lower() in b.lower()]
    if len(hits) != 1:
        failures.append(f"bullet names {len(hits)} concluded approaches, need 1: {b[:60]}")
if len(concluded) != len(pursued):
    failures.append(f"count mismatch: {len(concluded)} concluded vs {len(pursued)} bullets")

print("declined or abandoned approaches:", len(declined_or_abandoned))
print("bullets under 'Weighed and rejected':", len(rejected))
for a in declined_or_abandoned:
    key = REJECTED_KEY.get(a["id"])
    hits = [b for b in rejected if key and key.lower() in b.lower()]
    print(f"  {a['id']} ({a['status']}) named by {len(hits)} bullet(s) via key '{key}'")
    if len(hits) != 1:
        failures.append(f"{a['id']} ({a['status']}) named by {len(hits)} bullets, need 1")
if len(declined_or_abandoned) != len(rejected):
    failures.append(f"count mismatch: {len(declined_or_abandoned)} declined/abandoned vs {len(rejected)} bullets")

print("deferred approaches:", len(deferred), "| bullets under 'Future research':", len(future))
if len(deferred) != len(future):
    failures.append(f"count mismatch: {len(deferred)} deferred vs {len(future)} bullets")

open_ = [a["id"] for a in av if a["status"] in ("proposed", "pursued")]
print("open approaches (proposed or pursued):", len(open_), open_)

if failures:
    print("FAIL")
    for f in failures:
        print(" -", f)
    sys.exit(1)
print("PASS: the three groups match the approach statuses one to one")
