"""Strong probable-prime test on n = 91 over bases 2 to 89 (88 bases).

Standard library only. Establishes four facts the Limits sentence on
probable-prime tests states: the strong test rejects 91 in base 2 and in
base 3; it passes 16 of the 88 bases; bases 9 and 10 both pass; and
9^45 is 1 and 10^45 is 90 (that is, -1) modulo 91. Exits non-zero if any
of these fails.
"""
import sys

N = 91
BASES = list(range(2, N - 1))  # 2 .. 89 inclusive: 88 bases


def decompose(n):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    return d, s


def strong_passes(a, n):
    d, s = decompose(n)
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = (x * x) % n
        if x == n - 1:
            return True
    return False


d, s = decompose(N)
passes = [a for a in BASES if strong_passes(a, N)]

checks = {
    "bases examined is 88": len(BASES) == 88,
    "strong test rejects 91 in base 2": not strong_passes(2, N),
    "strong test rejects 91 in base 3": not strong_passes(3, N),
    "2^45 mod 91 is 57": pow(2, d, N) == 57,
    "3^45 mod 91 is 27": pow(3, d, N) == 27,
    "strong passes count is 16": len(passes) == 16,
    "base 9 strong-passes": strong_passes(9, N),
    "base 10 strong-passes": strong_passes(10, N),
    "9^45 mod 91 is 1": pow(9, d, N) == 1,
    "10^45 mod 91 is 90": pow(10, d, N) == N - 1,
    "91 = 7 x 13": 7 * 13 == N,
}

print(f"n = {N}, n - 1 = 2^{s} * {d}")
print(f"strong passes: {len(passes)} of {len(BASES)}: " + " ".join(map(str, passes)))
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}  {label}")

sys.exit(0 if all(checks.values()) else 1)
