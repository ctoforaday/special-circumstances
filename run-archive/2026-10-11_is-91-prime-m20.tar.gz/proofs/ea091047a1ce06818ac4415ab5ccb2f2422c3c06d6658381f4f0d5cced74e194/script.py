"""Fermat and strong probable-prime tests on n = 91, over every base from 2 to 89.

Standard-library only. Prints the residues and the pass counts so each figure
can be recomputed by hand-checkable arithmetic.
"""

N = 91
BASES = list(range(2, N - 1))  # 2 .. 89, i.e. 88 bases


def decompose(n):
    """Write n - 1 = 2^s * d with d odd."""
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    return d, s


def fermat_passes(a, n):
    return pow(a, n - 1, n) == 1


def strong_passes(a, n):
    """Strong probable-prime test: pass if a^d = 1 or a^(2^r d) = -1 for some r < s."""
    d, s = decompose(n)
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = (x * x) % n
        if x == n - 1:
            return True
    return False


d, s = decompose(N)
print(f"n = {N}, n - 1 = {N - 1} = 2^{s} * {d}")
print(f"fermat residue base 2:  2^90 mod 91 = {pow(2, 90, 91)}")
print(f"fermat residue base 3:  3^90 mod 91 = {pow(3, 90, 91)}")
print(f"strong residue base 2:  2^{d} mod 91 = {pow(2, d, 91)}")
print(f"strong residue base 3:  3^{d} mod 91 = {pow(3, d, 91)}")

fermat = [a for a in BASES if fermat_passes(a, N)]
strong = [a for a in BASES if strong_passes(a, N)]

print(f"bases examined: {len(BASES)} (from 2 to {BASES[-1]})")
print(f"fermat passes: {len(fermat)} of {len(BASES)}")
print("fermat pass list: " + " ".join(str(a) for a in fermat))
print(f"strong passes: {len(strong)} of {len(BASES)}")
print("strong pass list: " + " ".join(str(a) for a in strong))
print(f"strong test rejects 91 in base 2: {not strong_passes(2, N)}")
print(f"strong test rejects 91 in base 3: {not strong_passes(3, N)}")

# Sanity: every strong pass is also a Fermat pass for this n (a strong liar is a Fermat liar).
assert set(strong) <= set(fermat), "strong pass outside Fermat pass set"
