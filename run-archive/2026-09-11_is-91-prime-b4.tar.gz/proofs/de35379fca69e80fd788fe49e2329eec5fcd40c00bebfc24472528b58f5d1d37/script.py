n = 91
d = n - 1
s = 0
while d % 2 == 0:
    d //= 2
    s += 1
print(f"n-1 = {n-1} = {d} * 2^{s}")
for a in (2, 3, 5, 10):
    x = pow(a, d, n)
    seq = [x]
    for _ in range(s):
        seq.append((seq[-1] * seq[-1]) % n)
    witness = not (x == 1 or n - 1 in seq[:-1] or (s == 0 and x == n - 1))
    fooled = (x == n - 1) or (x == 1)
    print(f"a={a}: x = a^d mod n = {x}, sequence={seq}, {'FOOLED (strong probable prime)' if fooled else 'correctly flags composite'}")
