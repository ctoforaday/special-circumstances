from math import gcd

n = 91
rng = range(2, n)  # 2..90, the report's stated range

total = len(rng)
coprime = [a for a in rng if gcd(a, n) == 1]
non_coprime = [a for a in rng if gcd(a, n) != 1]
false_pass = [a for a in coprime if pow(a, n - 1, n) == 1]

print(f"range 2..{n-1}: {total} integers total")
print(f"coprime to {n}: {len(coprime)}")
print(f"NOT coprime to {n} (multiples of 7 or 13): {len(non_coprime)} -> {non_coprime}")
print(f"of the coprime bases, count giving a false Fermat pass (a^{n-1} == 1 mod {n}): {len(false_pass)}")

assert total == 89
assert len(coprime) == 71
assert len(non_coprime) == 18
assert len(false_pass) == 35
