import math
n = 91
bound = math.isqrt(n)
divisors = [d for d in range(2, bound + 1) if n % d == 0]
print(f"sqrt({n}) = {math.sqrt(n):.4f}, isqrt = {bound}")
print(f"trial division 2..{bound}: divisors found = {divisors}")
a, b = divisors[0], n // divisors[0]
print(f"{n} = {a} x {b}")
assert divisors == [7]
assert a * b == n and a == 7 and b == 13
print("RESULT: 91 = 7 x 13, COMPOSITE")
