n = 91
factors = [7, 13]
print("Korselt criterion for Carmichael-ness: squarefree and (p-1) | (n-1) for every prime factor p")
all_divide = True
for p in factors:
    divides = (n - 1) % (p - 1) == 0
    all_divide = all_divide and divides
    print(f"  p={p}: (p-1)={p-1}, (n-1)={n-1}, divides? {divides}")
print(f"squarefree: {len(set(factors)) == len(factors)}")
print(f"Carmichael (all divide + squarefree): {all_divide}")
assert all_divide is False
print("Blum integer check: both factors == 3 mod 4?")
for p in factors:
    print(f"  p={p} mod 4 = {p % 4}")
is_blum = all(p % 4 == 3 for p in factors)
print(f"Blum integer: {is_blum}")
assert is_blum is False
