from math import gcd
n = 91
for a in (7, 13):
    g = gcd(a, n)
    print(f"gcd({a}, {n}) = {g} -> shares a nontrivial factor, so {a} is not coprime to {n} and the Fermat/Miller-Rabin machinery does not apply; gcd > 1 is itself a compositeness proof")
    assert g == a
