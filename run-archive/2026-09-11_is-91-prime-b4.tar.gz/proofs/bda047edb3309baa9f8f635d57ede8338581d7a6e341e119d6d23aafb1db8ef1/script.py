from math import gcd
n = 91
for a in (2, 3, 5, 10, 11):
    r = pow(a, n - 1, n)
    print(f"a={a}: {a}^{n-1} mod {n} = {r} -> {'PASSES (false prime signal)' if r == 1 else 'FAILS (correctly composite)'}")
count = sum(1 for a in range(2, n) if gcd(a, n) == 1 and pow(a, n - 1, n) == 1)
print(f"count of bases in 2..{n-1} coprime to {n} with a^{n-1} == 1 mod {n}: {count}")
assert count == 35
