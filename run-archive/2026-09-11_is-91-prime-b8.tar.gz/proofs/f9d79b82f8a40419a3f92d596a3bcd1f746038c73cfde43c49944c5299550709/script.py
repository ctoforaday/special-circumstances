import math


def is_prime(n):
    if n < 2:
        return False
    for d in range(2, math.isqrt(n) + 1):
        if n % d == 0:
            return False
    return True


# Independently re-derives, by direct enumeration, the two OEIS positional
# claims cited in the report: that 91 is the 66th composite number (A002808,
# counted from the first composite, 4) and that it falls strictly between the
# 24th prime (89) and the 25th prime (97) in A000040 -- i.e. is absent from
# the prime sequence.
composites = [n for n in range(4, 92) if not is_prime(n)]
primes = [n for n in range(2, 100) if is_prime(n)]

print(f"composites from 4 through 91 inclusive: {len(composites)}")
print(f"91 is the last of these: {composites[-1] == 91}")
print(f"so 91 is composite index: {len(composites)}")

idx89 = primes.index(89) + 1
idx97 = primes.index(97) + 1
print(f"index of 89 in the prime sequence: {idx89}")
print(f"index of 97 in the prime sequence: {idx97}")
print(f"91 is prime: {is_prime(91)}")
