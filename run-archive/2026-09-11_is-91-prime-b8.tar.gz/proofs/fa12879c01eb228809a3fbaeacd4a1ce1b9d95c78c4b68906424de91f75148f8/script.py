n = 91

# Fermat's test: for prime p, a^(p-1) = 1 (mod p) for every a coprime to p.
# 91 is composite, so it FAILS for most bases, but Prime Curios (t5k.org)
# claims it passes ("is pseudoprime to") 35 bases a in [1, 90].
bases_passing = [a for a in range(1, n) if pow(a, n - 1, n) == 1]

print(f"n = {n}, n-1 = {n - 1}")
print(f"bases a in [1, {n - 1}] with a^{n - 1} = 1 (mod {n}): {len(bases_passing)}")
print(f"list: {bases_passing}")

nontrivial = [a for a in bases_passing if a != 1]
print(f"excluding the trivial base a=1: {len(nontrivial)} bases")
print(f"cross-check against the claim 'pseudoprime to 35 bases less than 91': "
      f"{'MATCHES' if len(nontrivial) == 35 else 'DOES NOT MATCH'}")
