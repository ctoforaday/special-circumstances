#!/bin/sh
# Independent cross-check using pre-existing, general-purpose system software
# that was not written to investigate this question: GNU coreutils' `factor`
# and OpenSSL's `prime` subcommand. 97 is included as a known-prime control.
set -e
echo "--- factor ---"
factor 91
factor 97
echo "--- openssl prime ---"
openssl prime 91
openssl prime 97
