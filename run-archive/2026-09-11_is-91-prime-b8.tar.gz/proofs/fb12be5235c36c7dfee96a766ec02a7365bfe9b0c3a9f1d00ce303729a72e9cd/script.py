import math


def is_prime_trial(n):
    if n < 2:
        return False
    for d in range(2, math.isqrt(n) + 1):
        if n % d == 0:
            return False
    return True


def is_prime_miller_rabin(n, witnesses):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13):
        if n % p == 0:
            return n == p
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in witnesses:
        if a >= n:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


# The lane draft's Miller-Rabin implementation was only spot-checked against
# 91, 97, 90 and 89. This re-audits it for full agreement with independent
# trial division over every integer from 2 to 100,000 -- not just the four
# values already reported -- to check the implementation itself, not only
# its answer on 91, for a latent bug that a four-point spot-check would miss.
WITNESSES = [2, 3, 5, 7]
mismatches = []
for n in range(2, 100_001):
    a = is_prime_trial(n)
    b = is_prime_miller_rabin(n, WITNESSES)
    if a != b:
        mismatches.append((n, a, b))

print(f"checked n = 2..100000 against trial division")
print(f"mismatches: {len(mismatches)}")
if mismatches:
    print(mismatches[:20])
print(f"91 classified consistently across the full sweep: {is_prime_miller_rabin(91, WITNESSES) == is_prime_trial(91) == False}")
