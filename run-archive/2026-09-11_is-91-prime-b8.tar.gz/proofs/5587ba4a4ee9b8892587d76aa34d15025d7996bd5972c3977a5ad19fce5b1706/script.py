def is_prime_miller_rabin(n, witnesses):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13):
        if n % p == 0:
            return n == p
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in witnesses:
        if a >= n:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


# Deterministic witness set for all n < 3,215,031,751 (Pomerance/Selfridge/Wagstaff).
WITNESSES = [2, 3, 5, 7]

targets = [91, 97, 90, 89]
for n in targets:
    result = is_prime_miller_rabin(n, WITNESSES)
    print(f"miller_rabin({n}) -> {'PRIME' if result else 'COMPOSITE'}")

assert is_prime_miller_rabin(91, WITNESSES) is False, "Miller-Rabin disagrees with trial division on 91"
assert is_prime_miller_rabin(97, WITNESSES) is True, "sanity check: 97 is prime"
print("Miller-Rabin (independent algorithm) agrees: 91 is COMPOSITE, 97 is PRIME")
