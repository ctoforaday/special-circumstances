n = 91

# Direct check of Fermat's congruence a^(n-1) = 1 (mod n) at three small bases.
# A prime would satisfy this at every base coprime to it; a composite that
# satisfies it at some base a is a Fermat pseudoprime to that base and is
# invisible to a Fermat test restricted to a.
for a in (2, 3, 5):
    value = pow(a, n - 1, n)
    verdict = "passes (looks prime at this base)" if value == 1 else "fails (correctly flags composite)"
    print(f"{a}^{n - 1} mod {n} = {value} -> {verdict}")
