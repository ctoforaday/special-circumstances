import math


def is_prime_trial(n):
    if n < 2:
        return False
    for d in range(2, math.isqrt(n) + 1):
        if n % d == 0:
            return False
    return True


# A base-3 Fermat pseudoprime is a COMPOSITE n, coprime to 3, with
# 3^(n-1) = 1 (mod n) -- the congruence every actual prime satisfies at base 3.
# This independently re-derives the claim (sourced from OEIS A005935 by lane 2)
# that 91 is the SMALLEST such number, rather than taking the sequence's first
# term on trust: it enumerates every composite below 91 and checks each one.
candidates = []
for n in range(4, 92):
    if is_prime_trial(n):
        continue
    if math.gcd(3, n) != 1:
        continue
    if pow(3, n - 1, n) == 1:
        candidates.append(n)

print(f"composite, base-3-coprime n in [4, 91] with 3^(n-1) = 1 (mod n): {candidates}")
print(f"smallest: {candidates[0] if candidates else None}")
print(f"91 is the smallest such n below or at 91: {candidates == [91]}")
