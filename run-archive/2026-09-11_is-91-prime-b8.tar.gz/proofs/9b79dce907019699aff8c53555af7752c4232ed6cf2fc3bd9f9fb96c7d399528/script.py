def is_prime_miller_rabin_no_prefilter(n, witnesses):
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in witnesses:
        if a >= n:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


WITNESSES = [2, 3, 5, 7]
targets = [91, 97, 90, 89]
for n in targets:
    result = is_prime_miller_rabin_no_prefilter(n, WITNESSES)
    print(f"miller_rabin_no_prefilter({n}) -> {'PRIME' if result else 'COMPOSITE'}")

assert is_prime_miller_rabin_no_prefilter(91, WITNESSES) is False, "Miller-Rabin (witness loop only, no small-prime prefilter) disagrees with trial division on 91"
assert is_prime_miller_rabin_no_prefilter(97, WITNESSES) is True, "sanity check: 97 is prime"
assert is_prime_miller_rabin_no_prefilter(90, WITNESSES) is False, "sanity check: 90 is composite"
assert is_prime_miller_rabin_no_prefilter(89, WITNESSES) is True, "sanity check: 89 is prime"
print("Miller-Rabin witness-exponentiation loop alone (no small-prime prefilter) agrees: 91 is COMPOSITE, 97 is PRIME")
