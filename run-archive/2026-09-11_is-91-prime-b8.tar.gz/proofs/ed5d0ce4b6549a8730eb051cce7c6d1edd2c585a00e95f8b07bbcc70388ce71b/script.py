def nontrivial_square_decompositions(n):
    # n = a^2 - b^2 = (a-b)(a+b), b from 0 up while a = ceil-ish stays integer
    found = []
    a = 1
    while a * a <= n + (n // 2 + 2) ** 2:  # generous bound
        a2 = a * a
        if a2 < n:
            a += 1
            continue
        b2 = a2 - n
        b = int(b2 ** 0.5)
        if b * b == b2:
            lo, hi = a - b, a + b
            found.append((a, b, lo, hi))
        a += 1
        if a > n:  # safety stop
            break
    return found


for n, label in [(91, "91 (Q1/Q3 subject)"), (97, "97 (control: known prime)")]:
    print(f"--- {label} ---")
    decs = nontrivial_square_decompositions(n)
    for a, b, lo, hi in decs:
        tag = "NONTRIVIAL" if lo != 1 else "trivial (n x 1)"
        print(f"  {n} = {a}^2 - {b}^2 = ({lo})({hi})  [{tag}]")
    nontrivial = [d for d in decs if d[2] != 1]
    print(f"  nontrivial decompositions found: {len(nontrivial)}")
