def divisible_by_7_rule(n):
    # Standard rule: double the last digit, subtract from the remaining
    # leading part, repeat until a small number remains.
    steps = []
    m = n
    while m >= 10 or m <= -10:
        last = m % 10
        rest = m // 10
        new = rest - 2 * last
        steps.append((m, last, rest, new))
        m = new
    return m, steps


for n in [91, 98, 90]:
    result, steps = divisible_by_7_rule(n)
    for (m, last, rest, new) in steps:
        print(f"  {m}: last digit {last}, remainder {rest}, {rest} - 2*{last} = {new}")
    verdict = "DIVISIBLE BY 7" if result % 7 == 0 else "NOT divisible by 7"
    print(f"{n} -> rule reduces to {result} -> {verdict} (direct check: {n % 7 == 0})")
    print()
