import math

n = 91
bound = math.isqrt(n)
divisors = [d for d in range(2, bound + 1) if n % d == 0]

print(f"n = {n}")
print(f"floor(sqrt(n)) = {bound}")
print(f"candidate divisors checked: 2..{bound}")
print(f"divisors found in range: {divisors}")

if divisors:
    d = divisors[0]
    print(f"{n} = {d} x {n // d} -> COMPOSITE")
else:
    print(f"{n} has no divisor in 2..{bound} -> PRIME")
