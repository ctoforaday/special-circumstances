# Strong probable-prime test with base 2, applied to every integer n with 4 <= n < 2047.
# Claim checked: the test accepts every prime below 2,047, rejects every composite below 2,047,
# and rejects 91.
# Strong test for odd n: write n - 1 = d * 2^s with d odd; n passes for base a if
# a^d = 1 (mod n), or a^(d * 2^r) = -1 (mod n) for some 0 <= r < s.

def strong_test_passes(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = (x * x) % n
        if x == n - 1:
            return True
    return False

def is_prime_by_division(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

LIMIT = 2047
numbers = range(4, LIMIT)
primes = [n for n in numbers if is_prime_by_division(n)]
composites = [n for n in numbers if not is_prime_by_division(n)]

prime_failures = [p for p in primes if not strong_test_passes(p, 2)]
composite_passes = [n for n in composites if strong_test_passes(n, 2)]

print(f"integers 4..{LIMIT-1}: primes = {len(primes)}, composites = {len(composites)}")
print(f"primes rejected by the strong test with base 2: {prime_failures}")
print(f"composites accepted by the strong test with base 2: {composite_passes}")
print(f"91 is composite by division: {not is_prime_by_division(91)}")
print(f"strong test with base 2 accepts 91: {strong_test_passes(91, 2)}")
print(f"decides every n below {LIMIT} (no failures either way): {not prime_failures and not composite_passes}")
