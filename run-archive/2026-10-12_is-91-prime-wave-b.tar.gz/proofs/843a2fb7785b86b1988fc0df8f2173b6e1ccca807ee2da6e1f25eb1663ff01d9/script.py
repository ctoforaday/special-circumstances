# Computation for lane 1 (adversarial-disconfirming-first) on: is 91 prime?
# Checks: (1) exhaustive trial division up to floor(sqrt(91)); (2) product check 7*13;
# (3) Fermat test base-dependence; (4) Miller-Rabin with bases 2..90; (5) Gaussian-integer factorisation check.
import math

N = 91

# (1) trial division by every integer 2..floor(sqrt(N))
bound = math.isqrt(N)
divisors = [d for d in range(2, bound + 1) if N % d == 0]
print(f"sqrt bound = {bound}; divisors in [2,{bound}] = {divisors}")
print(f"first divisor found = {divisors[0] if divisors else None}; cofactor = {N // divisors[0] if divisors else None}")

# (2) explicit factorisation and primality by definition (exactly two positive divisors)
pos_divs = [d for d in range(1, N + 1) if N % d == 0]
print(f"positive divisors of {N} = {pos_divs}; count = {len(pos_divs)}; prime by definition = {len(pos_divs) == 2}")
print(f"7*13 = {7*13}; 7*13 == 91 is {7*13 == 91}")

# (3) Fermat test: a^(N-1) mod N == 1 ?  list bases that report 'probably prime'
fermat_pass = [a for a in range(2, N - 1) if pow(a, N - 1, N) == 1]
fermat_fail = [a for a in range(2, N - 1) if pow(a, N - 1, N) != 1]
print(f"Fermat bases 2..{N-2} reporting probable prime (a^(N-1)=1 mod N): {fermat_pass}")
print(f"count passing = {len(fermat_pass)} of {N-3} bases; count failing = {len(fermat_fail)}")
print(f"base 2 Fermat residue 2^90 mod 91 = {pow(2, 90, 91)}")

# (4) Miller-Rabin: N-1 = d * 2^s ; strong probable prime test per base
def miller_rabin_says_prime(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = (x * x) % n
        if x == n - 1:
            return True
    return False

mr_pass = [a for a in range(2, N - 1) if miller_rabin_says_prime(N, a)]
print(f"Miller-Rabin bases 2..{N-2} reporting probable prime: {mr_pass}")
print(f"count = {len(mr_pass)} of {N-3}")
d, s = N - 1, 0
while d % 2 == 0:
    d //= 2; s += 1
print(f"N-1 = {N-1} = {d} * 2^{s}")

# (5) Gaussian integers Z[i]: norm N(a+bi) = a^2+b^2.
# 7 inert? No a,b with a^2+b^2 = 7 (so 7 is irreducible in Z[i]).
sum_two_sq_7 = [(a, b) for a in range(-3, 4) for b in range(-3, 4) if a*a + b*b == 7]
print(f"elements of norm 7 in Z[i] (searched |a|,|b|<=3): {sum_two_sq_7}  -> none means 7 is Gaussian prime")
# 3+2i and 3-2i: norm 13 each; product = 13
print(f"(3+2i)(3-2i) = real {3*3 - 2*(-2)*1*1 if False else 3*3+2*2}, imag 0 -> 13")
# 91 = 7 * (3+2i)(3-2i) with 7, (3+2i), (3-2i) each non-units (norm > 1)
norms = {"7": 49, "3+2i": 13, "3-2i": 13}
print(f"norms of the Gaussian factors (non-units iff norm > 1): {norms}; product of norms = {49*13*13} = N(91)? {91*91 == 49*13*13}")
