# Computation for the Gaussian-integer norm identity behind the sentence
# "The norms agree: 49 x 13 x 13 = 8281 = 91 x 91".
#
# A Gaussian integer is a pair (a, b) standing for a + b*i, with integers a and b.
# Each norm is computed from its components as N(a + bi) = a*a + b*b.
# Factors are multiplied with the complex rule (a+bi)(c+di) = (ac - bd) + (ad + bc)i,
# so the product and its norm are computed, not typed in.

def mul(x, y):
    a, b = x
    c, d = y
    return (a * c - b * d, a * d + b * c)


def norm(x):
    a, b = x
    return a * a + b * b


def is_unit(x):
    # The units of the Gaussian integers are the elements of norm 1: 1, -1, i, -i.
    return norm(x) == 1


seven = (7, 0)
p = (3, 2)     # 3 + 2i
q = (3, -2)    # 3 - 2i

n7, np_, nq = norm(seven), norm(p), norm(q)
print(f"norms computed from components: N(7) = {n7}, N(3+2i) = {np_}, N(3-2i) = {nq}")
print(f"each factor is a non-unit (norm > 1): {not is_unit(seven) and not is_unit(p) and not is_unit(q)}")

pq = mul(p, q)
print(f"(3+2i)(3-2i) computed as Gaussian integers = {pq}")

prod = mul(seven, pq)
print(f"7 * (3+2i) * (3-2i) computed as Gaussian integers = {prod}")
print(f"product equals 91 with zero imaginary part: {prod == (91, 0)}")
print(f"norm of the computed product = {norm(prod)}")
print(f"product of the three computed norms 49 x 13 x 13 = {n7 * np_ * nq}")
print(f"identity 49 x 13 x 13 = 91 x 91 holds on computed values: {n7 * np_ * nq == norm(prod) == 91 * 91}")
