# Recomputes three facts the report states about 91 and the base-2 rule.
# 1. Fermat bases 2..89 that report 91 probably prime (expect 34 of 88).
# 2. Strong-test bases 2..89 that report 91 probably prime (expect 16 of 88), with the list.
# 3. For every odd n below 2,047, the base-2 strong test agrees with trial division.
def strong_passes(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

bases = range(2, 90)  # 2 through 89 inclusive: 88 bases
fermat = [a for a in bases if pow(a, 90, 91) == 1]
strong = [a for a in bases if strong_passes(91, a)]
print("bases tested:", len(list(bases)))
print("Fermat passes for 91:", len(fermat), "bases include 3:", 3 in fermat)
print("strong passes for 91:", len(strong), strong)
expected_strong = [9, 10, 12, 16, 17, 22, 29, 38, 53, 62, 69, 74, 75, 79, 81, 82]
print("strong list matches report list:", strong == expected_strong)
print("base 2 rejects 91 (Fermat and strong):", pow(2, 90, 91) != 1 and not strong_passes(91, 2))

mismatches = []
checked = 0
for n in range(3, 2047, 2):
    checked += 1
    if strong_passes(n, 2) != is_prime(n):
        mismatches.append(n)
print("odd n in [3, 2046] checked:", checked, "mismatches with primality:", mismatches[:10], len(mismatches))
ok = (len(fermat) == 34 and len(strong) == 16 and strong == expected_strong
      and pow(2, 90, 91) != 1 and not strong_passes(91, 2) and not mismatches)
print("ALL CHECKS HOLD:", ok)
raise SystemExit(0 if ok else 1)
