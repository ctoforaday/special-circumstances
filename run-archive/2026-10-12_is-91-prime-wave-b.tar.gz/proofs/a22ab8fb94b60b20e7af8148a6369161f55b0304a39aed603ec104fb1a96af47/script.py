# Computation for the sentence on Z[i][1/7]: 7 is a unit there, yet 91 is not prime,
# because 91 is an associate of 13 = (3+2i)(3-2i) and neither factor is a unit.
# A Gaussian integer is a pair (a, b) for a + b*i. Norm N(a+bi) = a*a + b*b.
# A unit of Z[i][1/7] has norm in Z[1/7]^x = {+-7^k : k in Z}, since N is multiplicative
# and N(7) = 49 = 7^2. So a Gaussian integer of norm not of the form 7^k is not a unit there.

def mul(x, y):
    a, b = x
    c, d = y
    return (a * c - b * d, a * d + b * c)


def norm(x):
    a, b = x
    return a * a + b * b


p = (3, 2)     # 3 + 2i
q = (3, -2)    # 3 - 2i
prod = mul(p, q)
print(f"N(3+2i) = {norm(p)}, N(3-2i) = {norm(q)}")
print(f"(3+2i)(3-2i) = {prod}, so 13 = (3+2i)(3-2i) as Gaussian integers: {prod == (13, 0)}")

# Powers of 7 with exponent in a finite window; a norm of a unit of Z[i][1/7] must be one of these.
powers_of_seven = {7 ** k for k in range(0, 60)}
print(f"N(3+2i) = 13 is a power of 7 in the window: {norm(p) in powers_of_seven}")
print(f"N(3-2i) = 13 is a power of 7 in the window: {norm(q) in powers_of_seven}")
print(f"both factors are non-units of Z[i][1/7]: {norm(p) not in powers_of_seven and norm(q) not in powers_of_seven}")
print(f"7 is a unit of Z[i][1/7] (norm 49 = 7^2 is a power of 7): {norm((7, 0)) in powers_of_seven}")
print(f"91 = 7 * 13 as Gaussian integers: {mul((7, 0), prod) == (91, 0)}")
