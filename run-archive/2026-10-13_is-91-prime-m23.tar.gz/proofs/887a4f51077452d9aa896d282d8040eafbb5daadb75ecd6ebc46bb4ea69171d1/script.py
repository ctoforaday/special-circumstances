n = 91
r = pow(2, n - 1, n)
r7 = pow(2, n - 1, 7)
r13 = pow(2, n - 1, 13)
print("2^90 mod 91 =", r)
print("2^90 mod 7 =", r7)
print("2^90 mod 13 =", r13)
assert r == 64
assert r7 == 1
assert r13 == 12
assert r != 1
print("base-2 Fermat test fails for 91:", r != 1)
