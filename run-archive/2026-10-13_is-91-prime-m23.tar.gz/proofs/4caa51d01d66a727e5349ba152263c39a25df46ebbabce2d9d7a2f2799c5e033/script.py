import math

n = 91
root = math.isqrt(n)
divisors = [d for d in range(2, root + 1) if n % d == 0]
print("isqrt(91) =", root)
print("divisors d with 2 <= d <= isqrt(91) that divide 91:", divisors)
assert root == 9
assert divisors == [7], divisors
assert 7 * 13 == 91
assert n // 7 == 13
print("91 / 7 =", n // 7, "remainder", n % 7)
print("trial division result: 91 has a divisor other than 1 and 91, namely 7")
