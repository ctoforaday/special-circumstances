n = 91
bases = list(range(2, 90))
passing = [a for a in bases if pow(a, n - 1, n) == 1]
print("bases examined (2 through 89):", len(bases))
print("bases passing the Fermat test for 91:", len(passing))
print("base 7 passes:", 7 in passing)
print("base 2 passes:", 2 in passing)
assert len(bases) == 88
assert len(passing) == 34
assert 2 not in passing
