n = 91
m = n - 1
s = 0
d = m
while d % 2 == 0:
    d //= 2
    s += 1
print("n - 1 = 2^s * d with s =", s, "and d =", d)
assert (s, d) == (1, 45)

a = 2
x = pow(a, d, n)
print("2^45 mod 91 =", x)
assert x == 57

# Strong test: passes if a^d = 1, or a^(2^r d) = -1 for some 0 <= r < s.
# With s = 1 only r = 0 is checked, so the only values that pass are 1 and n - 1 = 90.
passes = (x == 1) or any(pow(a, d * 2 ** r, n) == n - 1 for r in range(s))
print("strong test in base 2 passes for 91:", passes)
assert not passes
assert x != 1 and x != n - 1
print("the residue 57 is neither 1 nor 90")
