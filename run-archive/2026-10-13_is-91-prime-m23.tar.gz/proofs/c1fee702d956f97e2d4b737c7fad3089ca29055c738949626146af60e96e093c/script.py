import sys

base = "/home/gblock_ctoforaday_com/.claude/scratch/universe-m23/src/research/2026-10-13_is-91-prime/cache/"
a000040 = open(base + "771717553a8bdeca9fb8fea1b5d110977b2328952c255abc0efd8664b6a48a69", "rb").read().decode("utf-8", "replace")
a001358 = open(base + "a74a9481d9c85e3d7837e06c646472d7a42d917f048d81d492e331b0b995bd22", "rb").read().decode("utf-8", "replace")

prime_run = "2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101"
semi_run = "4, 6, 9, 10, 14, 15, 21, 22, 25, 26, 33, 34, 35, 38, 39, 46, 49, 51, 55, 57, 58, 62, 65, 69, 74, 77, 82, 85, 86, 87, 91"
assert prime_run in a000040, "A000040 cached data run not found"
assert semi_run in a001358, "A001358 cached data run not found"
print("OEIS A000040 cached data contains the run through 101: yes")
print("OEIS A001358 cached data contains the run through 91: yes")

def is_prime(p):
    return p > 1 and all(p % q for q in range(2, int(p ** 0.5) + 1))

primes_up_to_101 = [p for p in range(2, 102) if is_prime(p)]
print("primes up to 101 by computation:", primes_up_to_101)
assert primes_up_to_101 == [int(x) for x in prime_run.split(", ")]
print("91 is among the primes up to 101:", 91 in primes_up_to_101)
assert 91 not in primes_up_to_101

def big_omega(n):
    count, d = 0, 2
    while d * d <= n:
        while n % d == 0:
            n //= d
            count += 1
        d += 1
    if n > 1:
        count += 1
    return count

semiprimes = [n for n in range(2, 101) if big_omega(n) == 2]
listed = [int(x) for x in semi_run.split(", ")]
assert semiprimes[: len(listed)] == listed, "computed semiprimes differ from the OEIS run"
position = semiprimes.index(91) + 1
print("position of 91 among semiprimes (1-based):", position)
assert position == 31
print("OEIS run matches computed semiprimes through 91: yes")
sys.exit(0)
