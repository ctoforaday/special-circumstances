import math
N = 91

# 1. All divisors d with 1 < d < N, and the smallest one (Q-70b94ee3)
divs = [d for d in range(2, N) if N % d == 0]
print("divisors of 91 strictly between 1 and 91:", divs)
print("smallest such divisor:", divs[0] if divs else None)

# 2. Trial division by every prime up to isqrt(91) (Q-589433b1)
r = math.isqrt(N)
def is_prime(k):
    return k >= 2 and all(k % q for q in range(2, math.isqrt(k) + 1))
primes_upto_r = [p for p in range(2, r + 1) if is_prime(p)]
print("isqrt(91) =", r, "; primes up to it:", primes_upto_r)
hits = [p for p in primes_upto_r if N % p == 0]
print("primes up to isqrt(91) dividing 91, in order:", hits, "-> first divisor:", hits[0] if hits else None)
print("trial division by 2,3,5,7 residues:", {p: N % p for p in [2, 3, 5, 7]})

# 3. Single base-2 Fermat test (Q-510fc537)
e = pow(2, N - 1, N)
print("2^90 mod 91 =", e, "; Fermat base-2 verdict:", "composite" if e != 1 else "passes")
print("2^90 mod 7 =", pow(2, 90, 7), "; 2^90 mod 13 =", pow(2, 90, 13))
# sufficiency 'not in general': smallest composite n with 2^(n-1) = 1 mod n
pseudo = [n for n in range(3, 20000, 2) if not is_prime(n) and pow(2, n - 1, n) == 1]
print("smallest base-2 Fermat pseudoprime (composite n with 2^(n-1)=1 mod n):", pseudo[:5])

# 4. Primes up to 100 by sieve, membership of 91 (Q-830e0c9b)
sieve = [True] * 101
sieve[0] = sieve[1] = False
for i in range(2, 101):
    if sieve[i]:
        for j in range(i * i, 101, i):
            sieve[j] = False
primes = [i for i in range(101) if sieve[i]]
print("first 25 primes:", primes[:25])
print("91 in primes up to 100:", 91 in primes)
print("7 * 13 =", 7 * 13)
