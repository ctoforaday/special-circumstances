"""91 = 7 x 13. For every base a coprime to 91, classify a as a Fermat liar
(a^90 = 1 mod 91), then test whether the Miller-Rabin and Solovay-Strassen
refinements still fail to detect compositeness for that same base. n-1 = 90
= 2^1 * 45, so Miller-Rabin has only one squaring level (s=1): the witness
value is x = a^45 mod 91, and a liar is unmasked exactly when x is a
nontrivial square root of 1 mod 91 (neither 1 nor 90).
"""
from math import gcd

N = 91
D, S = 90, 0
while D % 2 == 0:
    D //= 2
    S += 1
assert (D, S) == (45, 1)


def jacobi(a, n):
    a = a % n
    result = 1
    while a != 0:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5):
                result = -result
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3:
            result = -result
        a = a % n
    return result if n == 1 else 0


def brute_legendre(a, p):
    a = a % p
    if a == 0:
        return 0
    qr = set((x * x) % p for x in range(1, p))
    return 1 if a in qr else -1


# self-test the from-scratch Jacobi symbol against a brute-force Legendre
# symbol over every residue of 14 small primes before trusting it on 91.
mismatches = sum(
    1
    for p in [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    for a in range(1, p)
    if brute_legendre(a, p) != jacobi(a, p)
)
print(f"jacobi() self-test mismatches against brute-force Legendre: {mismatches}")
assert mismatches == 0

coprime_bases = [a for a in range(2, N) if gcd(a, N) == 1]
fermat_liars = [a for a in coprime_bases if pow(a, N - 1, N) == 1]
print(f"bases coprime to 91 in [2,90]: {len(coprime_bases)}")
print(f"Fermat liars (a^90 = 1 mod 91): {len(fermat_liars)} -> {fermat_liars}")

mr_strong_liars, mr_unmasked = [], []
for a in fermat_liars:
    x = pow(a, D, N)
    (mr_strong_liars if x in (1, N - 1) else mr_unmasked).append((a, x))

ss_liars, ss_unmasked = [], []
for a in fermat_liars:
    j = jacobi(a, N)
    x = pow(a, D, N)
    expected = 1 if j == 1 else N - 1
    (ss_liars if x == expected else ss_unmasked).append((a, j, x))

print(f"Miller-Rabin strong liars: {len(mr_strong_liars)} -> {[a for a, x in mr_strong_liars]}")
print(f"Miller-Rabin unmasked (nontrivial sqrt of 1 found): {len(mr_unmasked)} -> {[a for a, x in mr_unmasked]}")
print(f"Solovay-Strassen (Euler-Jacobi) liars: {len(ss_liars)} -> {[a for a, j, x in ss_liars]}")
print(f"Solovay-Strassen unmasked: {len(ss_unmasked)} -> {[a for a, j, x in ss_unmasked]}")
print(f"MR strong-liar set == Euler-Jacobi liar set: {sorted(a for a, x in mr_strong_liars) == sorted(a for a, j, x in ss_liars)}")

qr13 = set((x * x) % 13 for x in range(1, 13))
non_qr_liars = [a for a in fermat_liars if (a % 13) not in qr13]
print(f"QRs mod 13: {sorted(qr13)}")
print(f"Fermat liars whose (a mod 13) is NOT a QR mod 13 (expect none): {non_qr_liars}")
