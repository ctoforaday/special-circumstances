n = 91
divisors = [d for d in range(2, int(n**0.5) + 1) if n % d == 0]
print(f"n={n}, sqrt_bound={int(n**0.5)}, divisors_found={divisors}")
if divisors:
    d = divisors[0]
    q = n // d
    print(f"factorization: {n} = {d} * {q}")
    for name, v in [(d, d), (q, q)]:
        pass
    def is_prime(m):
        if m < 2:
            return False
        for k in range(2, int(m**0.5) + 1):
            if m % k == 0:
                return False
        return True
    print(f"{d} prime? {is_prime(d)}")
    print(f"{q} prime? {is_prime(q)}")
print(f"91 composite: {len(divisors) > 0}")
