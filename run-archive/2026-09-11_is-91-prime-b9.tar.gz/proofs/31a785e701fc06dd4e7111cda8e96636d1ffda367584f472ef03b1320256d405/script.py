n = 91
for a in [2, 3, 5, 7, 11]:
    r = pow(a, n - 1, n)
    flag = "PASSES as probable prime (misleading)" if r == 1 else "correctly flagged composite"
    print(f"base a={a}: a^(n-1) mod n = {r} -> {flag}")
