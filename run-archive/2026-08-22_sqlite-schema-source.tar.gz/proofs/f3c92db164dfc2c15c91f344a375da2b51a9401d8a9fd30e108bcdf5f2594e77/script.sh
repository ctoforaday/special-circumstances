#!/usr/bin/env bash
# Reproduces plans/record-protobuf.md V.4's six-accessor Payload census, plus the
# record-only-channel.md schema-mention grep, against current repo HEAD.
# Run from repo root.
set -euo pipefail
cd "$(git rev-parse --show-toplevel)/plugins/frank-exchange-of-views/tools"
NOPB='grep -v recordpb'

echo "== Payload files (filtered, repo-wide) =="
grep -rl "Payload" --include="*.go" . | $NOPB | wc -l

echo "== six accessor methods (filtered) =="
TOTAL=0
for m in 'Str(' 'Has(' 'StrList(' 'Bool(' 'Keys()'; do
  N=$(grep -rn "\.$m" --include='*.go' . | $NOPB | wc -l)
  echo "$m $N"
  TOTAL=$((TOTAL+N))
done
GET=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | $NOPB | wc -l)
echo "Get( $GET"
TOTAL=$((TOTAL+GET))
echo "TOTAL $TOTAL"

echo "== Get( breakdown: unfiltered vs recordpb-alone =="
UNFILT=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | wc -l)
RPB=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | grep recordpb | wc -l)
echo "unfiltered=$UNFILT filtered=$GET recordpb-alone=$RPB (unfiltered - filtered = $((UNFILT-GET)), should equal recordpb-alone)"

echo "== plans/record-only-channel.md schema/sqlite/GORM/database/SQL mentions =="
cd "$(git rev-parse --show-toplevel)"
grep -ni -E 'sqlite|GORM|database|schema|\bSQL\b' plans/record-only-channel.md || echo "(none)"
