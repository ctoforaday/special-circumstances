#!/usr/bin/env bash
# Settles R2-1: the recordpb-internal .Get( count (15 in the plan's pinned round vs.
# this round's re-verified 17) and its accessor-method breakdown, since only some of
# the 17 hits are literally `Fields().Get(i)`. Run from repo root.
set -euo pipefail
cd "$(git rev-parse --show-toplevel)/plugins/frank-exchange-of-views/tools"

echo "== .Get( totals =="
UNFILT=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | wc -l)
FILT=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | grep -v recordpb | wc -l)
RPB=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | grep recordpb | wc -l)
echo "unfiltered=$UNFILT filtered(excl.recordpb)=$FILT recordpb-alone=$RPB (unfiltered-filtered=$((UNFILT-FILT)), should equal recordpb-alone)"

echo "== recordpb .Get( accessor-method breakdown (17 call sites) =="
LINES=$(grep -rn "\.Get(" --include="*.go" . | grep -v "opts.Get\|vm.Get" | grep recordpb)
for acc in 'Fields()' 'Values()' 'Messages()' 'Enums()' 'Oneofs()'; do
  N=$(echo "$LINES" | grep -c "\\.${acc}\\.Get(")
  echo "$acc.Get( -> $N"
done
BARE=$(echo "$LINES" | grep -vE '\.(Fields|Values|Messages|Enums|Oneofs)\(\)\.Get\(')
echo "bare .Get( (no accessor call before it) -> $(echo "$BARE" | grep -c .)"
echo "-- bare line(s) --"
echo "$BARE"

echo "== plan's own pinned-round figure (for comparison, not re-derived) =="
grep -n "15 protoreflect" ../../../plans/record-protobuf.md || true
