#!/usr/bin/env bash
# Isolated, disposable GORM + SQLite spike (R1-4 repair, --check-kind computation).
# Never touches the feov-record repo: builds a throwaway Go module in a tempdir,
# fetches gorm.io/gorm + gorm.io/driver/sqlite, and tests two claims this report
# makes on GORM's own documentation:
#   1. the `serializer:json` tag round-trips a map[string]any field cleanly
#      (the escape hatch discussed for record.Payload / recordpb.Event's oneof body)
#   2. AutoMigrate widens a narrowed column's type but never drops a column
#      removed from the struct (the migration-safety risk R1-4/Q4 discuss)
# Independently replicates red's L6-F1 finding, not merely re-describes it.
set -euo pipefail
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
cd "$WORK"

go mod init spike >/dev/null 2>&1
go get gorm.io/gorm gorm.io/driver/sqlite >/dev/null 2>&1

cat > main.go <<'GOEOF'
package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

type EventV1 struct {
	ID      uint `gorm:"primaryKey"`
	SeqNum  int8
	ToDrop  string
	Payload map[string]any `gorm:"serializer:json"`
}

func (EventV1) TableName() string { return "spike_events" }

type EventV2 struct {
	ID      uint `gorm:"primaryKey"`
	SeqNum  int64
	Payload map[string]any `gorm:"serializer:json"`
}

func (EventV2) TableName() string { return "spike_events" }

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func main() {
	dbFile := "spike.db"
	os.Remove(dbFile)
	defer os.Remove(dbFile)

	db, err := gorm.Open(sqlite.Open(dbFile), &gorm.Config{})
	must(err)

	must(db.AutoMigrate(&EventV1{}))
	orig := map[string]any{"gap_id": "R1-1", "n": 3.0}
	must(db.Create(&EventV1{SeqNum: 1, ToDrop: "x", Payload: orig}).Error)

	var got EventV1
	must(db.First(&got).Error)
	roundtripOK := got.Payload["gap_id"] == "R1-1" && got.Payload["n"] == 3.0

	origJSON, _ := json.Marshal(orig)
	gotJSON, _ := json.Marshal(got.Payload)

	must(db.AutoMigrate(&EventV2{}))

	type colInfo struct {
		CID     int
		Name    string
		Type    string
		NotNull int
		Dflt    *string
		PK      int
	}
	var cols []colInfo
	must(db.Raw("PRAGMA table_info(spike_events)").Scan(&cols).Error)

	seqType, toDropSurvives, toDropValue := "", false, ""
	for _, c := range cols {
		if c.Name == "seq_num" {
			seqType = c.Type
		}
		if c.Name == "to_drop" {
			toDropSurvives = true
			var v string
			db.Raw("SELECT to_drop FROM spike_events WHERE id = 1").Scan(&v)
			toDropValue = v
		}
	}

	fmt.Println("RESULT_serializer_json_roundtrip_ok=", roundtripOK)
	fmt.Println("RESULT_orig_json=", string(origJSON))
	fmt.Println("RESULT_got_json=", string(gotJSON))
	fmt.Println("RESULT_seq_num_column_type_after_widen=", seqType)
	fmt.Println("RESULT_to_drop_column_survives_after_automigrate=", toDropSurvives)
	fmt.Println("RESULT_to_drop_stale_value=", toDropValue)
}
GOEOF

CGO_ENABLED=1 go run main.go
