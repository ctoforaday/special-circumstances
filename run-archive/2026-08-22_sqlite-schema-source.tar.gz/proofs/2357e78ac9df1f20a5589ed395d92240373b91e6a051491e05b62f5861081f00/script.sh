#!/usr/bin/env bash
# Reproduces the remaining load-bearing repo-derived counts in Technical foundations /
# the governing-structural-fact section: the Event.body oneof case count, the
# BoardState( call-site count, the recordpb import-site count, and the go.mod
# gorm/sqlite dependency check. Run from repo root.
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel)"
TOOLS="$ROOT/plugins/frank-exchange-of-views/tools"

echo "== Event.body oneof case count (record.proto) =="
awk '/oneof body \{/{flag=1} flag{print} /^  \}/{if(flag){exit}}' \
  "$TOOLS/internal/record/recordpb/record.proto" | grep -cE '^\s*[A-Za-z_]+ [A-Za-z_.]+ = [0-9]+;'

echo "== record.BoardState( call sites (all .go files) =="
grep -rn 'record\.BoardState(' --include='*.go' "$TOOLS" | wc -l

echo "== files importing recordpb outside internal/record/recordpb itself =="
{ grep -rl 'recordpb' --include='*.go' "$TOOLS" | grep -v '/internal/record/recordpb/' || true; } | wc -l

echo "== go.mod gorm/sqlite dependency check =="
grep -i -E 'gorm|sqlite' "$TOOLS/go.mod" || echo "(no gorm/sqlite dependency found)"
