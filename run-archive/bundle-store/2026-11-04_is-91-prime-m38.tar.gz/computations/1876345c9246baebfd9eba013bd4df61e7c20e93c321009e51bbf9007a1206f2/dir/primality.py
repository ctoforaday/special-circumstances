# Blue lane 1: trial division, Fermat and Miller-Rabin tests on 91, and prime list check below 100.
import math

N = 91

def trial_division(n):
    """Return the list of divisors d with 1 < d <= sqrt(n) that divide n, and the smallest one."""
    hits = []
    for d in range(2, math.isqrt(n) + 1):
        if n % d == 0:
            hits.append(d)
    return hits

def is_prime_by_definition(n):
    if n < 2:
        return False
    return all(n % d for d in range(2, math.isqrt(n) + 1))

print("N =", N)
print("isqrt(N) =", math.isqrt(N))
divs = trial_division(N)
print("divisors d in [2, sqrt(N)] with d | N:", divs)
if divs:
    print("smallest factor:", divs[0], "cofactor:", N // divs[0])
print("trial-division verdict prime:", is_prime_by_definition(N))

# Fermat test: pow(a, N-1, N) == 1 means "probably prime" for base a
fermat = {}
for a in range(2, N - 1):
    fermat[a] = pow(a, N - 1, N) == 1
passing = [a for a in fermat if fermat[a]]
failing = [a for a in fermat if not fermat[a]]
print("Fermat bases 2..89 that return 'probably prime':", passing)
print("count passing:", len(passing), "of", len(fermat))
print("small bases 2..10 result:", {a: fermat[a] for a in range(2, 11)})

# Miller-Rabin (strong) test: write N-1 = d * 2^s, check witnesses
def miller_rabin_says_prime(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

mr = {a: miller_rabin_says_prime(N, a) for a in range(2, N - 1)}
mr_pass = [a for a in mr if mr[a]]
print("Miller-Rabin bases 2..89 that return 'probably prime':", mr_pass)
print("count MR passing:", len(mr_pass), "of", len(mr))
print("MR witnesses (bases that return composite) count:", len(mr) - len(mr_pass))
print("smallest MR witness:", min(a for a in mr if not mr[a]))

# Prime list check around 91
primes_below_100 = [p for p in range(2, 100) if is_prime_by_definition(p)]
print("primes below 100:", primes_below_100)
print("count primes below 100:", len(primes_below_100))
print("91 in list:", 91 in primes_below_100)
print("neighbours of 91 in primes list: prev", max(p for p in primes_below_100 if p < 91), "next", min(p for p in primes_below_100 if p > 91))
