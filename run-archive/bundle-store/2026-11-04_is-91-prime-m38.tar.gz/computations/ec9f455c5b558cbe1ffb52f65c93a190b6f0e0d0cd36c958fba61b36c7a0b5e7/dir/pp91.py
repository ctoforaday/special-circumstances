# Probable-prime tests on 91, computed from first principles.
# Fermat: a^(n-1) = 1 (mod n). Strong (Miller-Rabin): n-1 = d * 2^s with d odd;
# pass if a^d = 1 or a^(d*2^r) = -1 (mod n) for some 0 <= r < s.
N = 91

def fermat_pp(n, a):
    return pow(a, n - 1, n) == 1

def mr_pp(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

def verdict(passed):
    return "probably prime" if passed else "composite"

print(f"n = {N} = 7 * 13; n-1 = {N-1} = 2^1 * 45")
for a in (2, 3, 9, 10):
    print(f"base {a:>2}: Fermat {verdict(fermat_pp(N, a)):<14} Miller-Rabin {verdict(mr_pp(N, a))}")

bases = list(range(2, 90))
f = [a for a in bases if fermat_pp(N, a)]
m = [a for a in bases if mr_pp(N, a)]
print(f"Fermat probably prime for {len(f)} of {len(bases)} bases 2..89: {f}")
print(f"Miller-Rabin probably prime for {len(m)} of {len(bases)} bases 2..89: {m}")
