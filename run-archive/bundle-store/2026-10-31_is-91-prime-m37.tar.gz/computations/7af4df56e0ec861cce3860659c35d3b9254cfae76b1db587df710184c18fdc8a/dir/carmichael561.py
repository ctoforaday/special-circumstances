"""The Carmichael number 561 = 3 * 11 * 17: its factors are prime, it satisfies
Korselt's criterion, and its Fermat test passes for every base coprime to it,
checked over every residue 1 to 560 modulo 561."""

from math import gcd

N = 561
FACTORS = [3, 11, 17]


def is_prime(n):
    if n < 2:
        return False
    k = 2
    while k * k <= n:
        if n % k == 0:
            return False
        k += 1
    return True


product = 1
for p in FACTORS:
    product *= p
print(f"factors {FACTORS}: product equals {N}: {product == N}")
print(f"all factors prime: {all(is_prime(p) for p in FACTORS)}")
print(f"Korselt criterion, (p - 1) divides {N - 1} for each factor: {all((N - 1) % (p - 1) == 0 for p in FACTORS)}")
print(f"{N} is composite: {not is_prime(N)}")

coprime = [b for b in range(1, N) if gcd(b, N) == 1]
fails = [b for b in coprime if pow(b, N - 1, N) != 1]
print(f"residues b with 1 <= b < {N} coprime to {N}: {len(coprime)}")
print(f"coprime residues failing the Fermat test (b^(N-1) != 1 mod N): {fails}")
print(f"residues sharing a factor with {N}, in 2..{N - 1}: {[b for b in range(2, N) if gcd(b, N) > 1]}")
