"""Searches the text of one copy of Friedman's page on 91 for the statement about base 3 and for any congruence with exponent n."""
import re

with open("source.txt", encoding="utf-8") as f:
    text = f.read()

print("bytes:", len(text.encode("utf-8")))
print("states 'smallest pseudoprime in base 3':", "smallest pseudoprime in base 3" in text)

patterns = {
    "congruence sign (≡)": r"≡",
    "mod with n": r"\bmod\w*\s*\(?\s*n\b",
    "(mod ...) group": r"\(mod",
    "power of 3 with exponent n": r"3\s*\^\s*\{?\s*n\b",
    "3n as a product or exponent": r"\b3\s*n\b",
    "the word congruence": r"(?i)congruen",
}
total = 0
for label, pat in patterns.items():
    hits = re.findall(pat, text)
    total += len(hits)
    print(f"{label}: {len(hits)}")
print("congruence with exponent n found anywhere in the copy:", total > 0)
