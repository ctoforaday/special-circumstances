"""Independent check of the bare congruence 3^n = 3 (mod n) for n up to 91, using a sieve for primality."""
N = 91
BASE = 3

is_p = [True] * (N + 1)
is_p[0] = is_p[1] = False
for i in range(2, N + 1):
    if is_p[i]:
        for j in range(i * i, N + 1, i):
            is_p[j] = False

composites = [n for n in range(4, N + 1) if not is_p[n]]
print("composites from 4 to 91:", len(composites))
print("3^91 mod 91 =", pow(BASE, N, N))
satisfying = [n for n in composites if pow(BASE, n, n) == BASE]
print("composites up to 91 satisfying 3^n = 3 (mod n):", satisfying)
print("of those, multiples of 3:", [n for n in satisfying if n % 3 == 0])
