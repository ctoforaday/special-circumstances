"""For each base from 2 to 30, the smallest composite below 200000 that passes the Fermat test to that base, found with a smallest-prime-factor sieve."""
import math

LIM = 200000
spf = list(range(LIM + 1))
for i in range(2, math.isqrt(LIM) + 1):
    if spf[i] == i:
        for j in range(i * i, LIM + 1, i):
            if spf[j] == j:
                spf[j] = i

def composite(n):
    return n > 1 and spf[n] != n

all_found = True
for b in range(2, 31):
    hit = None
    for n in range(4, LIM):
        if composite(n) and math.gcd(n, b) == 1 and pow(b, n - 1, n) == 1:
            hit = n
            break
    if hit is None:
        all_found = False
        print(f"base {b}: none below {LIM}")
    else:
        print(f"base {b}: smallest passing composite {hit}")
print("every base from 2 to 30 has a passing composite below 200000:", all_found)
