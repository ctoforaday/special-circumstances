"""Applies the plain base-3 Fermat test to every composite from 4 to 91, and the
strong (Miller-Rabin) base-3 test only to odd composites from 9 to 91.

Plain test: n passes if 3^(n-1) mod n == 1.
Strong test, defined for odd n > 2: write n-1 = 2^s * d with s >= 1 and d odd.
n passes if 3^d mod n == 1, or 3^(d * 2^r) mod n == n-1 for some r with 0 <= r < s.
Even composites are not given to the strong test, since its definition excludes them.
"""

N = 91
BASE = 3


def is_prime(n):
    if n < 2:
        return False
    k = 2
    while k * k <= n:
        if n % k == 0:
            return False
        k += 1
    return True


def plain_pass(n):
    return pow(BASE, n - 1, n) == 1


def strong_split(n):
    s, d = 0, n - 1
    while d % 2 == 0:
        d //= 2
        s += 1
    return s, d


def strong_pass(n):
    s, d = strong_split(n)
    residues = [pow(BASE, d * (2 ** r), n) for r in range(s)]
    return residues[0] == 1 or any(x == n - 1 for x in residues)


composites = [n for n in range(4, N + 1) if not is_prime(n)]
odd_composites = [n for n in range(9, N + 1, 2) if not is_prime(n)]
even_composites = [n for n in composites if n % 2 == 0]

print(f"composites from 4 to {N}: {len(composites)}")
print(f"composites passing the plain base-{BASE} test: {[n for n in composites if plain_pass(n)]}")
print(f"odd composites from 9 to {N}: {len(odd_composites)}")
print(f"odd composites passing the strong base-{BASE} test: {[n for n in odd_composites if strong_pass(n)]}")
print(f"even composites outside the strong test's domain: {len(even_composites)}")

s, d = strong_split(N)
print(f"n = {N}: n-1 = 2^{s} * {d}; strong residues examined: {[pow(BASE, d * 2 ** r, N) for r in range(s)]}")

odd_primes = [n for n in range(5, N + 1, 2) if is_prime(n) and n != BASE]
print(f"odd primes from 5 to {N}: {len(odd_primes)}; failing the plain test: "
      f"{[p for p in odd_primes if not plain_pass(p)]}; failing the strong test: "
      f"{[p for p in odd_primes if not strong_pass(p)]}")
