"""Composites up to 91 that satisfy the bare congruence 3^n = 3 (mod n), and whether
each is a multiple of 3. For n coprime to 3, the congruence and the base-3 Fermat
condition 3^(n-1) = 1 (mod n) are checked to agree on every composite."""

N = 91
BASE = 3


def is_prime(n):
    if n < 2:
        return False
    k = 2
    while k * k <= n:
        if n % k == 0:
            return False
        k += 1
    return True


composites = [n for n in range(4, N + 1) if not is_prime(n)]
bare = [n for n in composites if pow(BASE, n, n) == BASE % n]

print(f"composites from 4 to {N}: {len(composites)}")
print(f"composites satisfying 3^n = 3 (mod n): {bare}")
for n in bare:
    print(f"  n = {n}: multiple of 3: {n % 3 == 0}; 3^(n-1) mod n = {pow(BASE, n - 1, n)}")

mult3 = [n for n in composites if n % 3 == 0]
print(f"composites that are multiples of 3: {mult3}")
print(f"multiples of 3 satisfying the congruence: {[n for n in mult3 if pow(BASE, n, n) == BASE % n]}")

coprime = [n for n in composites if n % 3 != 0]
agree = all((pow(BASE, n, n) == BASE % n) == (pow(BASE, n - 1, n) == 1) for n in coprime)
print(f"composites coprime to 3: {len(coprime)}; congruence and base-3 Fermat condition agree on all of them: {agree}")
