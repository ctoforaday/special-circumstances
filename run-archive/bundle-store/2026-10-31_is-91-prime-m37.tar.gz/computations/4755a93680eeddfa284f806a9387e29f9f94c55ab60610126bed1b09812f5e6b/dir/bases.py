"""Smallest composite that passes the Fermat test to each base from 2 to 30.

For each base b, the program searches odd composites n in ascending order, skipping any n that
shares a factor with b, and reports the first n with b^(n-1) = 1 (mod n). The search is bounded.
"""
import math

BOUND = 200000
BASES = range(2, 31)

sieve = bytearray([1]) * (BOUND + 1)
sieve[0] = 0
sieve[1] = 0
for p in range(2, math.isqrt(BOUND) + 1):
    if sieve[p]:
        sieve[p * p::p] = bytearray(len(sieve[p * p::p]))


def is_composite(n):
    return n > 1 and not sieve[n]


all_found = True
for b in BASES:
    found = None
    for n in range(3, BOUND + 1, 2):
        if not is_composite(n) or math.gcd(n, b) != 1:
            continue
        if pow(b, n - 1, n) == 1:
            found = n
            break
    if found is None:
        all_found = False
        print(f"base {b}: no composite below {BOUND} passes the Fermat test to this base")
    else:
        print(f"base {b}: smallest composite passing the Fermat test to this base is {found}")

print(f"every base from {BASES[0]} to {BASES[-1]} has a passing composite below {BOUND}: {all_found}")
