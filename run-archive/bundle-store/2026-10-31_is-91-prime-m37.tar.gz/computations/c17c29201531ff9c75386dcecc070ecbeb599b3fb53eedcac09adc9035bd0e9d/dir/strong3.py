"""Compares the plain Fermat test and the strong (Miller-Rabin) test to base 3 on 91 and on every composite up to 91.

Plain test: n passes if 3^(n-1) mod n == 1.
Strong test: write n-1 = 2^s * d with d odd. n passes if 3^d mod n is 1 or n-1, or if
3^(d * 2^r) mod n equals n-1 for some r with 0 < r < s.
"""

N = 91
BASE = 3


def is_prime(n):
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True


def plain_pass(n, a=BASE):
    return pow(a, n - 1, n) == 1


def strong_split(n):
    s, d = 0, n - 1
    while d % 2 == 0:
        d //= 2
        s += 1
    return s, d


def strong_residues(n, a=BASE):
    """The residues the strong test examines: a^(d * 2^r) mod n for r = 0 .. s-1."""
    s, d = strong_split(n)
    return [pow(a, d * (2 ** r), n) for r in range(s)]


def strong_pass(n, a=BASE):
    s, d = strong_split(n)
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True
    return False


s, d = strong_split(N)
print(f"n = {N}: n-1 = 2^{s} * {d}")
print(f"  residues the strong test examines: {strong_residues(N)}")
print(f"  plain base-3 test passes {N}: {plain_pass(N)}")
print(f"  strong base-3 test passes {N}: {strong_pass(N)}")

composites = [n for n in range(4, N + 1) if not is_prime(n)]
plain_list = [n for n in composites if plain_pass(n)]
strong_list = [n for n in composites if strong_pass(n)]
print(f"composites up to {N}: {len(composites)}")
print(f"composites passing the plain base-3 test: {plain_list}")
print(f"composites passing the strong base-3 test: {strong_list}")

# Sanity check: every prime other than the base itself must pass both tests.
primes = [n for n in range(2, N + 1) if is_prime(n) and n != BASE]
bad_plain = [p for p in primes if not plain_pass(p)]
bad_strong = [p for p in primes if not strong_pass(p)]
print(f"primes up to {N} other than the base {BASE}: {len(primes)}; failing the plain test: {bad_plain}; failing the strong test: {bad_strong}")
