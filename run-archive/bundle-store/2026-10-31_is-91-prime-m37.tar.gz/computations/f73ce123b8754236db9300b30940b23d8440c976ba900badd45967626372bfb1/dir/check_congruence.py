"""Checks the congruence 3^n = 3 (mod n) at n = 91, and lists the composites up to 91 that satisfy it."""
N = 91
print(f"3^{N} mod {N} = {pow(3, N, N)}")
print(f"3*{N} mod {N} = {(3 * N) % N}")
composites = [n for n in range(4, N + 1) if any(n % d == 0 for d in range(2, int(n ** 0.5) + 1))]
satisfying = [n for n in composites if pow(3, n, n) == 3]
print(f"composites n <= {N} with 3^n = 3 (mod n): {satisfying}")
