import math

n = 91

# Trial division over the candidates 2 .. isqrt(n): the first divisor found.
limit = math.isqrt(n)
divisors = [d for d in range(2, limit + 1) if n % d == 0]
first = divisors[0] if divisors else None
cofactor = n // first if first else None

# Fermat test in base 3 and base 2: residue of b^(n-1) mod n.
r3 = pow(3, n - 1, n)
r2 = pow(2, n - 1, n)

composite = first is not None and first * cofactor == n
passes_base3 = r3 == 1

print("n =", n)
print("isqrt(n) =", limit)
print("first divisor found by trial division:", first)
print("cofactor n / first =", cofactor)
print("composite (divisor found, product checks):", composite)
print("3^(n-1) mod n =", r3)
print("2^(n-1) mod n =", r2)
print("passes base-3 Fermat test:", passes_base3)
print("passes base-3 test AND composite:", passes_base3 and composite)
