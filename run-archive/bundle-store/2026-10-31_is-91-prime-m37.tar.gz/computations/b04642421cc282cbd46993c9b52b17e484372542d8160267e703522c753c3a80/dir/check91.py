"""Primality checks on 91, computed three independent ways plus a Fermat base sweep.

Prints every figure the lane draft states about 91, so each figure can be re-derived.
"""
import math

N = 91

# 1. Trial division by every integer from 2 up to floor(sqrt(N)).
limit = math.isqrt(N)
divisors = [d for d in range(2, limit + 1) if N % d == 0]
print(f"sqrt bound floor(sqrt({N})) = {limit}")
print(f"trial-division candidates 2..{limit}: {list(range(2, limit + 1))}")
print(f"first divisor found by trial division: {divisors[0] if divisors else None}")
print(f"cofactor: {N} / {divisors[0]} = {N // divisors[0]}")
print(f"primality by trial division: {'prime' if not divisors else 'composite'}")

# 2. Sieve of Eratosthenes over 2..N.
sieve = [True] * (N + 1)
sieve[0] = sieve[1] = False
for p in range(2, math.isqrt(N) + 1):
    if sieve[p]:
        for m in range(p * p, N + 1, p):
            sieve[m] = False
primes_upto = [i for i in range(2, N + 1) if sieve[i]]
print(f"primes <= {N} by sieve: count={len(primes_upto)} last={primes_upto[-1]}")
print(f"91 survives the sieve: {sieve[N]}")
print(f"primes list: {primes_upto}")

# 3. Fermat tests, base 2 and base 3, plus CRT decomposition of 2^90 mod 91.
for base in (2, 3):
    r = pow(base, N - 1, N)
    print(f"base {base}: {base}^{N-1} mod {N} = {r}; passes Fermat test: {r == 1}")

print(f"2^90 mod 7  = {pow(2, 90, 7)}")
print(f"2^90 mod 13 = {pow(2, 90, 13)}  (13 - 1 = 12)")
x = [v for v in range(N) if v % 7 == pow(2, 90, 7) and v % 13 == pow(2, 90, 13)]
print(f"CRT: 2^90 mod 91 is the unique x with those residues: {x}")

# 4. Smallest composite that passes the base-3 Fermat test (pseudoprime check).
composites_passing_base3 = []
for n in range(4, N + 1):
    if all(n % d for d in range(2, math.isqrt(n) + 1)):
        continue  # n is prime
    if pow(3, n - 1, n) == 1:
        composites_passing_base3.append(n)
print(f"composites n <= {N} with 3^(n-1) = 1 mod n: {composites_passing_base3}")

# 5. Order of 2 and 3 modulo 7 and 13 (explains the residues above).
def order(a, m):
    k, v = 1, a % m
    while v != 1:
        v = (v * a) % m
        k += 1
    return k
print(f"ord_7(2)={order(2,7)} ord_13(2)={order(2,13)} ord_7(3)={order(3,7)} ord_13(3)={order(3,13)}")
