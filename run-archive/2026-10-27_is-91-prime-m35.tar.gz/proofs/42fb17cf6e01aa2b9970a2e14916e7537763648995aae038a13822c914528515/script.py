# Sieve of Eratosthenes over 0..100 using only the sieving primes up to 10 (2, 3, 5, 7).
LIMIT = 100
SIEVING_PRIMES = [2, 3, 5, 7]
first_marker = {}
for p in SIEVING_PRIMES:
    for m in range(p * p, LIMIT + 1, p):
        first_marker.setdefault(m, p)
survivors = [n for n in range(2, LIMIT + 1) if n not in first_marker]
print("sieving primes used: %s" % SIEVING_PRIMES)
print("91 first removed by sieving prime: %s" % first_marker.get(91))
print("numbers 2..100 surviving the sieve: %d" % len(survivors))
assert first_marker.get(91) == 7, "91 was not removed by 7"
print("RESULT: sieving with the primes up to 10 removes 91 as a multiple of 7")
