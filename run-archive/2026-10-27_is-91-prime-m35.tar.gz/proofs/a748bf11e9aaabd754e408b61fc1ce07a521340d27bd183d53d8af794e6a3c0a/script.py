# The Catechism states that 91 is composite by a one-line division.
# Checks that dividing 91 by 7 is exact, giving 13, and that 7 is neither 1 nor 91,
# so the division exhibits a proper divisor. Standard library only.

n, d = 91, 7
assert n % d == 0, "91 divided by 7 must leave no remainder"
assert n // d == 13, "91 divided by 7 must give 13"
assert d not in (1, n), "the divisor must be proper"
print("91 / 7 = %d remainder %d" % (n // d, n % d))
print("RESULT: a one-line division exhibits the proper divisor 7 of 91, so 91 is composite")
