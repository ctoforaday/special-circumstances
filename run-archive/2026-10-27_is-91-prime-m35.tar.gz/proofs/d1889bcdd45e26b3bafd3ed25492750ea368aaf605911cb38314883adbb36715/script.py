# Base-3 Fermat test over the integers 2..1000: how often a composite passes.
N = 1000

def is_prime(n):
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True

primes = [n for n in range(2, N + 1) if is_prime(n)]
composites = [n for n in range(4, N + 1) if not is_prime(n)]
passing = [n for n in composites if pow(3, n - 1, n) == 1]
failing = [n for n in composites if pow(3, n - 1, n) != 1]
prime_fail = [p for p in primes if p != 3 and pow(3, p - 1, p) != 1]

print("primes that fail base-3 Fermat (primes other than 3): %d" % len(prime_fail))
print("composites in 4..%d: %d" % (N, len(composites)))
print("composites passing base-3 Fermat: %d" % len(passing))
print("composites passing, listed: %s" % passing)
print("ratio composites / passing composites: %.1f" % (len(composites) / len(passing)))
assert len(prime_fail) == 0
assert 91 in passing
print("RESULT: a prime other than 3 is %.1f times as likely as a composite in 4..%d to pass" % (len(composites) / len(passing), N))
