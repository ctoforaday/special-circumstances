# Base-3 Fermat test over 2..1000, reporting both pass-rate ratios and the population each one names.
# A prime's base-3 test is undefined when the prime is 3 itself (the base equals the modulus), so 3
# is counted as failing; "a prime other than 3" excludes it. Standard library only.

N = 1000

def is_prime(n):
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True

def passes(n):
    return pow(3, n - 1, n) == 1

primes = [n for n in range(2, N + 1) if is_prime(n)]
composites = [n for n in range(4, N + 1) if not is_prime(n)]
composite_pass = [n for n in composites if passes(n)]
primes_other_than_3 = [p for p in primes if p != 3]
primes_other_than_3_pass = [p for p in primes_other_than_3 if passes(p)]

assert len(primes) == 168, len(primes)
assert len(primes_other_than_3) == 167
assert len(primes_other_than_3_pass) == 167, "every prime other than 3 should pass base 3"
assert len(composites) == 831, len(composites)
assert composite_pass == [91, 121, 286, 671, 703, 949], composite_pass
assert not passes(3), "3 fails the base-3 test, because the base equals the modulus"

composite_rate = len(composite_pass) / len(composites)
r_other_than_3 = (len(primes_other_than_3_pass) / len(primes_other_than_3)) / composite_rate
r_all_primes = (sum(1 for p in primes if passes(p)) / len(primes)) / composite_rate

print("primes in 2..%d: %d; primes other than 3: %d, all passing" % (N, len(primes), len(primes_other_than_3)))
print("composites in 4..%d: %d; composites passing base 3: %d %r" % (N, len(composites), len(composite_pass), composite_pass))
print("pass rate, composites: %d/%d" % (len(composite_pass), len(composites)))
print("pass rate, primes other than 3: %d/%d" % (len(primes_other_than_3_pass), len(primes_other_than_3)))
print("pass rate, all primes 2..%d (3 fails): %d/%d" % (N, sum(1 for p in primes if passes(p)), len(primes)))
print("ratio, primes other than 3 to composites: %.1f" % r_other_than_3)
print("ratio, all primes 2..%d to composites: %.1f" % (N, r_all_primes))
print("reciprocal of composite pass rate, 831/6: %.1f" % (len(composites) / len(composite_pass)))
print("RESULT: for a prime other than 3 the ratio to a composite is %.1f; counting 3 among the primes gives %.1f"
      % (r_other_than_3, r_all_primes))
