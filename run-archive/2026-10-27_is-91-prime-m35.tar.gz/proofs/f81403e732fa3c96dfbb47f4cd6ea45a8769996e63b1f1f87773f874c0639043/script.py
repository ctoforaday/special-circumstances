# Two statements about base-3 Fermat pseudoprimes and the test set for 91.
# (1) Among the Fermat tests with bases 2, 3, 5 and 7, only base 3 passes for 91.
# (2) 91 is the smallest composite n with 3^(n-1) = 1 modulo n, so it is the first base-3 pseudoprime.
# Standard library only.

def is_prime(n):
    return n >= 2 and all(n % d for d in range(2, int(n ** 0.5) + 1))

# (1) Fermat test, bases 2, 3, 5, 7, on 91.
passing_bases = [a for a in (2, 3, 5, 7) if pow(a, 90, 91) == 1]
assert passing_bases == [3], "expected only base 3 to pass, got %r" % passing_bases
print("bases 2, 3, 5, 7 whose Fermat test passes for 91: %r" % passing_bases)

# (2) Smallest composite n with 3^(n-1) = 1 mod n.
first = next(n for n in range(4, 200) if not is_prime(n) and pow(3, n - 1, n) == 1)
assert first == 91, "first base-3 pseudoprime is %d" % first
print("smallest composite n with 3^(n-1) = 1 mod n: %d" % first)
print("RESULT: among bases 2, 3, 5, 7 only base 3 passes for 91, and 91 is the first base-3 pseudoprime")
