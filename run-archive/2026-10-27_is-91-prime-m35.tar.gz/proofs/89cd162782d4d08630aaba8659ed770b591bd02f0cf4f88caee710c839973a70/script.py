import math
n = 91
print("sqrt bound", math.isqrt(n))
print("trial divisors", [d for d in range(2, math.isqrt(n)+1) if n % d == 0])
print("pow(3, 90, 91) =", pow(3, 90, n))
print("pow(3, 90, 7) =", pow(3, 90, 7), " pow(3, 90, 13) =", pow(3, 90, 13))
def mr(n, a):
    d, s = n-1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    x = pow(a, d, n)
    if x in (1, n-1): return True
    for _ in range(s-1):
        x = x*x % n
        if x == n-1: return True
    return False
for a in (2, 3, 5, 7):
    print("MR base", a, "passes" if mr(n, a) else "reports composite")
sieve = [True]*101
sieve[0] = sieve[1] = False
for i in range(2, 11):
    if sieve[i]:
        for j in range(i*i, 101, i): sieve[j] = False
print("91 in sieve primes<=100:", sieve[91])
print("3^45 mod 7 =", pow(3, 45, 7), " 3^45 mod 13 =", pow(3, 45, 13), " 3^45 mod 91 =", pow(3, 45, 91))
