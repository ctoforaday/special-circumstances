# Arithmetic of 91 that the report states. Each assertion is one claim;
# a failed assertion is itself the result (non-zero exit is recorded).
# Standard library only; takes no input.

def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]

def is_prime(n):
    return n >= 2 and all(n % d for d in range(2, int(n ** 0.5) + 1))

def strong_test_accepts(n, a):
    # Miller-Rabin single-base test: n - 1 = 2^s * d with d odd.
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(s - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True
    return False

# Factorisation and divisors
assert 7 * 13 == 91
print("7 x 13 = %d" % (7 * 13))
assert divisors(91) == [1, 7, 13, 91]
print("positive divisors of 91: %s, count %d" % (divisors(91), len(divisors(91))))
assert [d for d in range(2, 91) if 91 % d == 0] == [7, 13]
print("divisors of 91 from 2 to 90: %s" % [d for d in range(2, 91) if 91 % d == 0])
assert [d for d in range(2, 10) if 91 % d == 0] == [7]
print("trial division by 2 through 9 finds only: %s" % [d for d in range(2, 10) if 91 % d == 0])
assert 91 % 7 == 0
print("7 divides 91: %s" % (91 % 7 == 0))
assert not is_prime(91)
print("91 is prime: %s" % is_prime(91))

# Fermat residues of 3 modulo 91, 7 and 13
assert pow(3, 90, 91) == 1 and pow(3, 90, 7) == 1 and pow(3, 90, 13) == 1
print("3^90 mod 91 = %d; mod 7 = %d; mod 13 = %d" % (pow(3, 90, 91), pow(3, 90, 7), pow(3, 90, 13)))
assert (3 ** 90 - 1) % 7 == 0 and (3 ** 90 - 1) % 13 == 0
print("7 and 13 each divide 3^90 - 1: %s" % ((3 ** 90 - 1) % 7 == 0 and (3 ** 90 - 1) % 13 == 0))

# Strong-test residues for base 3
assert 90 == 2 * 45
assert pow(3, 45, 91) == 27
assert pow(3, 45, 7) == 6 and 6 == 7 - 1
assert pow(3, 45, 13) == 1
print("3^45 mod 91 = %d; mod 7 = %d (= -1 mod 7); mod 13 = %d" % (pow(3, 45, 91), pow(3, 45, 7), pow(3, 45, 13)))
assert pow(3, 45, 91) not in (1, 90)
print("3^45 mod 91 is neither 1 nor 90, so base 3 is rejected by the strong test")

# Strong test over bases 2, 3, 5, 7
assert all(not strong_test_accepts(91, a) for a in (2, 3, 5, 7))
print("strong test rejects 91 in bases 2, 3, 5, 7: %s" % [not strong_test_accepts(91, a) for a in (2, 3, 5, 7)])

# Sieve to 100
primes_100 = [n for n in range(2, 101) if is_prime(n)]
assert len(primes_100) == 25 and 91 not in primes_100
print("primes up to 100: %d; 91 among them: %s" % (len(primes_100), 91 in primes_100))

print("RESULT: every assertion held")
