"""Independent checks that 91 is composite (= 7 x 13).

Each check uses a method different from the frontier script:
  1. Divisor search over ALL integers 2..90 (not only up to sqrt(91)).
  2. Fermat base-3 test by repeated multiplication (no pow()).
  3. Miller-Rabin strong test by explicit squaring chain, bases 2, 3, 5, 7.
  4. Sieve to 100 with a plain list, and a count of primes <= 100 to compare with the known count.
  5. Factor 91 by gcd with 3^90 - 1 (rather than by trial division).
Exit status 0 only if every assertion holds.
"""
import math
import sys

N = 91
fail = []


def check(label, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + label + (" :: " + detail if detail else ""))
    if not ok:
        fail.append(label)


# 1. All divisors in 2..N-1
divs = [d for d in range(2, N) if N % d == 0]
check("divisors of 91 in 2..90 are exactly [7, 13]", divs == [7, 13], str(divs))
check("7 * 13 == 91", 7 * 13 == N)

# 2. Fermat base 3, multiply repeatedly: 3^90 mod 91
def powmod_loop(base, exp, mod):
    r = 1
    for _ in range(exp):
        r = (r * base) % mod
    return r

r91 = powmod_loop(3, 90, 91)
r7 = powmod_loop(3, 90, 7)
r13 = powmod_loop(3, 90, 13)
check("3^90 mod 91 == 1 (Fermat base-3 passes)", r91 == 1, str(r91))
check("3^90 mod 7 == 1", r7 == 1, str(r7))
check("3^90 mod 13 == 1", r13 == 1, str(r13))
check("gcd(3^90 - 1, 91) == 91", math.gcd(3 ** 90 - 1, N) == N)
check("gcd(3^90 - 1, 7) == 7 and gcd(3^90 - 1, 13) == 13",
      math.gcd(3 ** 90 - 1, 7) == 7 and math.gcd(3 ** 90 - 1, 13) == 13)

# 3. Miller-Rabin strong test, explicit squaring chain. n - 1 = 90 = 2^1 * 45
def strong_probable_prime(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = powmod_loop(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = (x * x) % n
        if x == n - 1:
            return True
    return False

check("n - 1 = 2^1 * 45", (N - 1) == 2 * 45)
mr = {a: strong_probable_prime(N, a) for a in (2, 3, 5, 7)}
for a, v in mr.items():
    print("   MR base", a, "->", "probable prime" if v else "composite witness")
check("Miller-Rabin with bases 2,3,5,7 rejects 91 in every base", not any(mr.values()))
x45_mod7 = powmod_loop(3, 45, 7)
x45_mod13 = powmod_loop(3, 45, 13)
check("3^45 == -1 (mod 7)", x45_mod7 == 6, str(x45_mod7))
check("3^45 == +1 (mod 13)", x45_mod13 == 1, str(x45_mod13))
check("3^45 mod 91 is 27 (neither 1 nor 90)", powmod_loop(3, 45, 91) == 27,
      str(powmod_loop(3, 45, 91)))

# 4. Sieve of Eratosthenes to 100, plain list
limit = 100
is_p = [True] * (limit + 1)
is_p[0] = is_p[1] = False
for i in range(2, limit + 1):
    if is_p[i]:
        for j in range(i * i, limit + 1, i):
            is_p[j] = False
primes = [i for i in range(limit + 1) if is_p[i]]
check("sieve to 100 has 25 primes", len(primes) == 25, str(len(primes)))
check("91 absent from sieve primes <= 100", 91 not in primes)
check("sieve primes <= 100 are all prime by trial division",
      all(p > 1 and all(p % d for d in range(2, math.isqrt(p) + 1)) for p in primes))

# 5. Non-primality under the definition: exactly one divisor pair strictly between 1 and n
pairs = [(d, N // d) for d in range(2, math.isqrt(N) + 1) if N % d == 0]
check("91 has a factorisation with both factors > 1", len(pairs) == 1 and pairs[0] == (7, 13), str(pairs))

print()
print("RESULT:", "all checks pass" if not fail else "FAILED: " + "; ".join(fail))
sys.exit(0 if not fail else 1)
