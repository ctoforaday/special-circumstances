# The sentence states that 91 is the product of two smaller natural numbers, 7 and 13.
# Checks the product, that both factors are natural numbers smaller than 91, and that
# no other factor pair with both factors in 2..90 exists. Standard library only.

a, b = 7, 13
assert a * b == 91, "7 x 13 must equal 91"
assert 1 <= a < 91 and 1 <= b < 91, "both factors must be smaller than 91"
pairs = [(x, y) for x in range(2, 91) for y in range(2, 91) if x * y == 91]
assert pairs == [(7, 13), (13, 7)], "factor pairs with both factors in 2..90: %r" % pairs
print("7 x 13 = %d" % (a * b))
print("factor pairs of 91 with both factors in 2..90: %r" % pairs)
print("RESULT: 91 is the product of the smaller natural numbers 7 and 13, and of no other pair")
