# The base-3 Fermat test on 91: the power 3^90 modulo 91 is 1, so the test passes, although 91 is composite.
# Standard library only.

n = 91
residue = pow(3, n - 1, n)
assert residue == 1, "3^90 mod 91 must be 1 for the Fermat test to pass"
assert n % 7 == 0 and n // 7 == 13, "91 = 7 x 13, so 91 is composite"
print("3^90 mod 91 = %d" % residue)
print("base-3 Fermat test on 91 passes: %s" % (residue == 1))
print("RESULT: the base-3 Fermat test passes for 91, which is composite (91 = 7 x 13)")
