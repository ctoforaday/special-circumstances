#!/usr/bin/env python3
"""Trial division up to floor(sqrt(n)) for n=91."""
import math

n = 91
limit = math.isqrt(n)
divisors_found = []
for d in range(2, limit + 1):
    q, r = divmod(n, d)
    if r == 0:
        divisors_found.append((d, q))

print(f"n={n}, floor(sqrt(n))={limit}")
if divisors_found:
    d, q = divisors_found[0]
    print(f"d={d} divides evenly: {n}/{d}={q}, {d}*{q}={d*q} -> COMPOSITE")
else:
    print("no divisor found in [2, floor(sqrt(n))] -> PRIME")
