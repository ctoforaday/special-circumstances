#!/usr/bin/env python3
"""Wilson's theorem: n is prime iff (n-1)! = -1 (mod n).
Computed as an iterative modular product to avoid materializing the exact
~140-digit factorial and to avoid any floating-point precision loss."""

n = 91
fact_mod = 1
for k in range(1, n):
    fact_mod = (fact_mod * k) % n

print(f"(n-1)! mod n = {fact_mod}  (prime would require {n - 1}, i.e. -1 mod {n})")
print("COMPOSITE" if fact_mod != n - 1 else "PRIME")
