#!/usr/bin/env python3
"""Fermat's factorization method: n = a^2 - b^2 = (a-b)(a+b).
Searches a starting at ceil(sqrt(n)) for the first a where a^2-n is a
perfect square."""
import math

n = 91
a = math.isqrt(n)
if a * a < n:
    a += 1

found = None
while a <= (n + 1) // 2:
    b2 = a * a - n
    b = math.isqrt(b2)
    if b * b == b2:
        found = (a, b, a - b, a + b)
        break
    a += 1

if found:
    a, b, p, q = found
    print(f"a={a}: a^2-n={a*a-n}={b}^2 -> n = {a}^2 - {b}^2 = ({a}-{b})({a}+{b}) = {p} x {q}")
    print(f"check: {p}*{q} = {p*q}")
else:
    print("no factorization found in range -> n is prime")
