#!/usr/bin/env python3
"""Sieve of Eratosthenes over [2,100]: elimination by multiples across a whole
neighborhood, rather than testing 91 in isolation."""
import math

LIMIT = 100
sieve = [True] * (LIMIT + 1)
sieve[0] = sieve[1] = False
for p in range(2, math.isqrt(LIMIT) + 1):
    if sieve[p]:
        for multiple in range(p * p, LIMIT + 1, p):
            sieve[multiple] = False

primes = [i for i, is_p in enumerate(sieve) if is_p]
prev_p = max(p for p in primes if p < 91)
next_p = min(p for p in primes if p > 91)
print(f"91 marked prime by the sieve? {sieve[91]}")
print(f"nearest primes either side of 91: {prev_p}, {next_p}")
