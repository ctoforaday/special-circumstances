#!/usr/bin/env python3
"""Unbounded brute-force divisor enumeration over [1, n], not assuming the
sqrt(n) shortcut, then checks that every divisor <= sqrt(n) pairs with one
found above sqrt(n) via n // d -- confirming rather than assuming the pairing
property trial division relies on."""
import math

n = 91
all_divisors = [d for d in range(1, n + 1) if n % d == 0]
limit = math.isqrt(n)
below = [d for d in all_divisors if d <= limit]
above = [d for d in all_divisors if d > limit]
pairs_ok = all((n // d) in all_divisors for d in below)

print(f"divisors of {n} in [1,{n}]: {all_divisors}")
print(f"floor(sqrt({n}))={limit}; <=limit: {below}; >limit: {above}")
print(f"every divisor<=limit pairs with n//d found above: {pairs_ok}")
