#!/usr/bin/env python3
"""Exhaustive sweep of every base a in [2,90] coprime to 91: how many wrongly
pass a one-shot Fermat test (a^90 mod 91 == 1)? Also checks whether 91 is a
Carmichael number (would require ALL phi(91) coprime bases to pass)."""
import math

n = 91
fooling_bases = [a for a in range(2, n) if math.gcd(a, n) == 1 and pow(a, n - 1, n) == 1]
totient = (7 - 1) * (13 - 1)

print(f"phi({n}) = {totient}")
print(f"fooling bases (a^{n-1} mod {n} == 1): {fooling_bases}")
print(f"count: {len(fooling_bases)} of {totient}")
print("IS a Carmichael number" if len(fooling_bases) == totient else "is NOT a Carmichael number")
