#!/usr/bin/env python3
"""Fermat's little theorem, base 2: if n is prime and gcd(2,n)=1, 2^(n-1) mod n == 1.
Failure disconfirms primality outright (success alone would not confirm it --
Fermat pseudoprimes exist, which is what the 72-base sweep in
coprime_base_sweep.py characterizes for n=91)."""

n = 91
result = pow(2, n - 1, n)
print(f"2^{n-1} mod {n} = {result}")
print("base-2 Fermat test FAILS (result != 1) -> disconfirms primality" if result != 1
      else "base-2 Fermat test PASSES (result == 1) -> does not disconfirm primality")
