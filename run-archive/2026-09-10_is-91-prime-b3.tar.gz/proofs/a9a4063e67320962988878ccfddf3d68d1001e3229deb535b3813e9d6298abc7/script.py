#!/usr/bin/env python3
"""Deterministic Miller-Rabin for n < 3,215,031,751 with witness set {2,3,5,7},
run as the genuine modular-exponentiation witness test -- no small-prime
divisibility pre-filter.

Correction on the record: an earlier script in this run (second_methods.py)
implemented is_prime_miller_rabin() with a short-circuit
`for p in (2,3,5,7,11,13): if n % p == 0: return n == p` ahead of the witness
loop. For n=91, 91 % 7 == 0 fires that line and the function returns before
ever running a single witness, so its COMPOSITE verdict for n=91 specifically
came from divisibility by 7 -- the same operation trial division already
performs -- not from the witness test. This script performs only the witness
test proper, so its result is the structurally independent corroboration the
report's "six methods, no shared machinery" claim requires.
"""

n = 91
witnesses = [2, 3, 5, 7]

d = n - 1
r = 0
while d % 2 == 0:
    d //= 2
    r += 1
print(f"n-1 = {n-1} = {d} * 2^{r}  (d={d}, r={r})")

all_composite_witness = True
for a in witnesses:
    x = pow(a, d, n)
    trace = [x]
    conclusive = (x == 1 or x == n - 1)
    if not conclusive:
        for _ in range(r - 1):
            x = pow(x, 2, n)
            trace.append(x)
            if x == n - 1:
                conclusive = True
                break
    verdict = "inconclusive at this witness (a^d in {1,n-1} or a square hit n-1)" if conclusive \
        else "WITNESSES COMPOSITE (a^d and every squaring avoid {1,n-1})"
    note = "  [note: gcd(a,n)>1 here -- a is one of n's own factors]" if __import__("math").gcd(a, n) != 1 else ""
    print(f"a={a}: a^d mod n = {a}^{d} mod {n} = {trace[0]}; squarings={trace[1:] or '(r-1=0, none)'} -> {verdict}{note}")
    if conclusive:
        all_composite_witness = False

print("COMPOSITE (every witness proves it)" if all_composite_witness else "not proven composite by all witnesses")
