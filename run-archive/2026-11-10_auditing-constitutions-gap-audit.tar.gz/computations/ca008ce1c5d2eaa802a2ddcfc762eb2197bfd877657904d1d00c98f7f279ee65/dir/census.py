import tarfile,re,collections
tf=tarfile.open('seats.tgz')
files={m.name:tf.extractfile(m).read().decode() for m in tf.getmembers() if m.isfile()}
def split(t):
    L=t.split('\n')
    b=[i for i,l in enumerate(L) if 'BEGIN GENERATED SURFACE' in l]
    e=[i for i,l in enumerate(L) if 'END GENERATED SURFACE' in l]
    if not b: return t,''
    return '\n'.join(L[:b[0]]+L[e[0]+1:]),'\n'.join(L[b[0]:e[0]+1])
auth={};gen={}
for n,t in sorted(files.items()):
    a,g=split(t);auth[n.split('/')[-1][:-3] if n.startswith('agents') else 'SKILL']=a;gen[n]=g
print('authored share of each agent definition (authored chars / total chars)')
for n,t in sorted(files.items()):
    if n.startswith('agents'):
        a=len(auth[n.split('/')[-1][:-3]]);print(n.split('/')[-1][:-3].ljust(24),'%.1f%%'%(100*a/len(t)))
lens=[k for k in auth if k.startswith('red-lens-')]
paras=collections.defaultdict(set)
for k in lens:
    for p in re.split(r'\n\s*\n|\n(?=- )',auth[k]):
        p=p.strip()
        if len(p)>200: paras[p].add(k)
sh=[p for p,v in paras.items() if len(v)==len(lens)]
print('\nparagraphs over 200 chars shared verbatim by all',len(lens),'lenses:',len(sh),'totalling',sum(map(len,sh)),'chars')
for k in lens: print(k.ljust(24),'share of authored text %.0f%%'%(100*sum(len(p) for p in sh if p in auth[k])/len(auth[k])))
lines=[set(l for l in auth[k].split('\n') if l.strip()) for k in lens]
common=set.intersection(*lines);print('\nnon-empty lines identical in all lenses:',len(common),'chars',sum(map(len,common)))
for k,s in zip(lens,lines): print(k.ljust(24),'share of authored text %.0f%%'%(100*sum(map(len,common&s))/len(auth[k])))
terms=['conflict of interest','recus','competen','impairment','self-review|self review','collusion|collude','independen']
print('\nline hits per term in authored text of all 13 carriers (12 seat definitions and the skill)')
for t in terms:
    print(t.ljust(28),sum(1 for a in auth.values() for l in a.split('\n') if re.search(t,l,re.I)))
print('\nline hits per term in the whole text of every definition and the skill')
for t in terms+['petition','vote_laundering','secondary_citation','reversal rate']:
    print(t.ljust(28),sum(1 for a in files.values() for l in a.split('\n') if re.search(t,l,re.I)))
cl={}
for m in re.finditer(r'^    (\w+)\s+\[(always|never|by_grade)\]',files['agents/red-chair.md'],re.M): cl[m.group(1)]=m.group(2)
c=collections.Counter(cl.values());print('\ndefect classes in the red-chair definition:',len(cl),dict(c))
