import tarfile, re, collections
tf = tarfile.open("carriers.tar.gz")
tot = 0
per = {}
cats = collections.Counter()
samples = collections.defaultdict(list)
def cat(l):
    s = l.lower()
    if "vote_laundering" in s: return "vote_laundering class entry (class-table line naming the class)"
    if "independently shippable" in s: return "'independently shippable' (software parts)"
    if "independent recount" in s or "figure_recount_fails" in s: return "figure_recount_fails entry (independent recount)"
    if "independent supports" in s: return "derivation_status_overclaim entry (how many independent supports exist)"
    if "independent implementation" in s: return "generated help for computations (an independent implementation as a method note)"
    if "`independent`" in s or "independent:[" in s or "under `independent`" in s: return "generated help for the evidence view (the field named independent)"
    return "other"
files = sorted(m.name for m in tf.getmembers() if m.isfile())
for n in files:
    text = tf.extractfile(n).read().decode("utf-8", "replace")
    hits = [l for l in text.splitlines() if "independen" in l.lower()]
    per[n] = len(hits)
    tot += len(hits)
    for l in hits:
        c = cat(l); cats[c] += 1
        if len(samples[c]) < 3: samples[c].append(l.strip()[:140])
vl = sum(tf.extractfile(n).read().decode("utf-8","replace").count("vote_laundering") for n in files)
vll = sum(sum(1 for l in tf.extractfile(n).read().decode("utf-8","replace").splitlines() if "vote_laundering" in l) for n in files)
print("files:", len(files))
for n in files: print(f"{per[n]:4d} lines containing 'independen'  {n}")
print("TOTAL lines containing 'independen':", tot)
print("TOTAL lines containing 'vote_laundering':", vll)
print("Lines categorised other (must be 0 for the breakdown to be complete):", cats["other"])
print("Sum of categories:", sum(cats.values()))
for c, k in cats.most_common(): print(f"{k:4d}  {c}")
for c in samples:
    for s in samples[c]: print("  [%s] %s" % (c[:20], s))
