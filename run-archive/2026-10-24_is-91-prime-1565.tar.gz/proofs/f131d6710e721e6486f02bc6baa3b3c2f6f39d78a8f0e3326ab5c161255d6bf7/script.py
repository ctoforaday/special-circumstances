# Settles the modular-test claims about n = 91 that the report states as counts and verdicts.
# Exits non-zero if any stated figure is wrong.
n = 91

def strong_passes(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

def fermat_passes(n, a):
    return pow(a, n - 1, n) == 1

bases = range(2, 90)  # 2..89 inclusive: 88 bases
fer = sum(1 for b in bases if fermat_passes(n, b))
st = sum(1 for b in bases if strong_passes(n, b))
checks = {
    "bases in 2..89 = 88": len(list(bases)) == 88,
    "Fermat passes among 88 bases = 34": fer == 34,
    "strong passes among 88 bases = 16": st == 16,
    "base 2 rejects 91 under Fermat": not fermat_passes(n, 2),
    "base 2 rejects 91 under strong": not strong_passes(n, 2),
    "base 3 passes Fermat": fermat_passes(n, 3),
    "base 9 passes strong": strong_passes(n, 9),
    "base 9 is in the strong-passing set and base 2 is not, so strong verdict depends on base": strong_passes(n, 9) and not strong_passes(n, 2),
}
for k, v in checks.items():
    print(("PASS " if v else "FAIL ") + k)
print("Fermat passes:", fer, "of 88; strong passes:", st, "of 88")
raise SystemExit(0 if all(checks.values()) else 1)
