# Trial division, divisor enumeration, Fermat and strong (Miller-Rabin) tests for n = 91.
import math

def primes_upto(m):
    return [p for p in range(2, m + 1) if all(p % q for q in range(2, int(math.isqrt(p)) + 1))]

n = 91
root = math.isqrt(n)
print(f"n={n} isqrt={root}")
ps = primes_upto(root)
print("primes up to isqrt:", ps)
divs = [p for p in ps if n % p == 0]
print("prime divisors found by trial division:", divs, "quotients:", [n // p for p in divs])
allp = [d for d in range(1, n + 1) if n % d == 0]
print("all positive divisors:", allp, "count:", len(allp))
print("is prime by definition (exactly two divisors):", len(allp) == 2)

def fermat_pass(a, n):
    return pow(a, n - 1, n) == 1

def strong_pass(a, n):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

fermat_bases = [a for a in range(2, n - 1) if fermat_pass(a, n)]
print("Fermat-liar bases a in [2,n-2] (a^(n-1)=1 mod n):", fermat_bases)
print("Fermat fraction of bases passing:", round(len(fermat_bases) / (n - 3), 4))
strong_bases = [a for a in range(2, n - 1) if strong_pass(a, n)]
print("strong (Miller-Rabin) liar bases:", strong_bases)
print("base 2 Fermat:", fermat_pass(2, n), "base 2 strong:", strong_pass(2, n))
print("base 3 Fermat:", fermat_pass(3, n), "base 3 strong:", strong_pass(3, n))
print("residues 3^90, 2^90 mod 91:", pow(3, 90, 91), pow(2, 90, 91))
print("bases 2,3,5,7 strong-test verdict (composite if any fails):", [strong_pass(a, n) for a in (2, 3, 5, 7)])
