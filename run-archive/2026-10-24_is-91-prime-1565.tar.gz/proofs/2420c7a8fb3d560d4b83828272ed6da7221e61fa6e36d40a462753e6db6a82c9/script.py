# Counts the distinct sources the report cites, by kind.
# Input: the cited-source URLs transcribed from the record's evidence projection
# (every citation anchor in the report, one row each). Pure computation; no tool calls.
from urllib.parse import urlparse

cited = [
    ("C-f2c16a1a", "https://en.wikipedia.org/wiki/Prime_number"),
    ("C-da703a8d", "https://oeis.org/A001358"),
    ("C-16462053", "https://oeis.org/A001358"),
    ("C-696ae6ea", "https://en.wikipedia.org/wiki/Fermat_primality_test"),
    ("C-09c2ef59", "https://en.wikipedia.org/wiki/Miller%E2%80%93Rabin_primality_test"),
    ("C-ed45d7d5", "https://en.wikipedia.org/wiki/Miller%E2%80%93Rabin_primality_test"),
    ("C-e52978ff", "https://en.wikipedia.org/wiki/Miller%E2%80%93Rabin_primality_test"),
]

urls = sorted({u for _, u in cited})
encyclopedia = [u for u in urls if urlparse(u).netloc.endswith("wikipedia.org")]
integer_seq = [u for u in urls if urlparse(u).netloc == "oeis.org"]
other = [u for u in urls if u not in encyclopedia and u not in integer_seq]

print("citation anchors:", len(cited))
print("distinct source URLs:", len(urls))
print("general encyclopedia articles:", len(encyclopedia))
for u in encyclopedia:
    print("   ", u)
print("integer-sequence entries:", len(integer_seq))
for u in integer_seq:
    print("   ", u)
print("other:", len(other))

assert len(encyclopedia) == 3, len(encyclopedia)
assert len(integer_seq) == 1, len(integer_seq)
assert len(urls) == 4, len(urls)
print("OK: three general encyclopedia articles, one integer-sequence entry, four distinct sources")
