#!/usr/bin/env python3
"""Checks the strong-test bound sentences of the modular section.

Claims settled:
  1. No odd composite n < 2,047 passes the strong (Miller-Rabin) test at base 2;
     2,047 = 23 x 89 is composite and does pass it. So base 2 alone decides
     primality under the strong test for n < 2,047, and not at 2,047.
  2. 3,215,031,751 = 151 x 751 x 28,351 is composite and passes the strong test
     at bases 2, 3, 5 and 7. So no bound above 3,215,031,751 holds for that base set.
Exit status 0 when every check comes out as stated, 1 otherwise.
"""


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def strong_pass(n, a):
    """Strong probable-prime test for odd n >= 3 and base a."""
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False


ok = True

# Check 1: exhaustive over odd n in [3, 2047)
odd_composites = [n for n in range(3, 2047, 2) if not is_prime(n)]
passers = [n for n in odd_composites if strong_pass(n, 2)]
print(f"odd composites below 2047: {len(odd_composites)}")
print(f"odd composites below 2047 passing strong base 2: {passers}")
if passers:
    ok = False

print(f"2047 = 23 x 89 product check: {23 * 89 == 2047}; 23 prime: {is_prime(23)}; 89 prime: {is_prime(89)}")
print(f"2047 passes strong base 2: {strong_pass(2047, 2)}")
if not strong_pass(2047, 2) or 23 * 89 != 2047:
    ok = False

# Check 2: the bases 2,3,5,7 witness
p, q, r = 151, 751, 28351
N = 3215031751
print(f"151 x 751 x 28351 = {p * q * r}; equals 3,215,031,751: {p * q * r == N}")
print(f"151, 751, 28351 each prime: {is_prime(p)}, {is_prime(q)}, {is_prime(r)}")
if p * q * r != N or not (is_prime(p) and is_prime(q) and is_prime(r)):
    ok = False
for a in (2, 3, 5, 7):
    res = strong_pass(N, a)
    print(f"3,215,031,751 passes strong test at base {a}: {res}")
    if not res:
        ok = False

print("ALL CHECKS AS STATED" if ok else "A CHECK FAILED")
raise SystemExit(0 if ok else 1)
