"""Strong (Miller-Rabin) test at base 2 on the composite 2047.

Claim settled: 2047 = 23 * 89, and base 2 passes the strong test on 2047,
so base 2 does not reject every composite number.
Exact integer arithmetic only; no external calls.
"""


def strong_pass(a, n):
    # n odd, n - 1 = d * 2^s with d odd
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True
    return False


def smallest_factor(n):
    f = 2
    while f * f <= n:
        if n % f == 0:
            return f
        f += 1
    return n


n = 2047
p = smallest_factor(n)
q = n // p
assert p * q == n and p > 1 and q > 1, "2047 should be composite"
print(f"2047 = {p} x {q}")
print("composite:", p > 1 and q > 1)
verdict = strong_pass(2, n)
print("base 2 strong test on 2047:", "pass" if verdict else "reject")
assert verdict, "expected base 2 to pass the strong test on 2047"
print("base 2 does not reject every composite: confirmed")
