# Arithmetic for the Eiffel Tower height record: step changes from the height table,
# and the thermal expansion range for the iron structure.
# Inputs are the figures as printed by the sources named in the report; no external data read.
table = [  # (label, metres) from the Wikipedia height-change table, pinnacle values
    ("1889-1956 flagpole era", 312.27),
    ("1957-1991 antenna", 320.75),
    ("1991-1994 antenna change", 317.96),
    ("1994-2000", 318.70),
    ("2000-2022 UHF antenna", 324.00),
    ("2022-now DAB+ antenna", 330.00),
]
print("Step changes between consecutive table values (m):")
for (a, x), (b, y) in zip(table, table[1:]):
    print(f"  {a} -> {b}: {y - x:+.2f}")
print(f"Total 1889 flagpole value to 2022 value: {330.00 - 312.27:+.2f} m")
print(f"Total 1889 architectural 300 m to 330 m: {330.00 - 300.0:+.2f} m")
print()
# Official text says the 1957 antenna raised the height by 18.7 m (Wikipedia prose).
# Table implies 320.75 - 312.27 = 8.48 m. Print the mismatch.
print(f"Table-implied 1957 increment: {320.75 - 312.27:.2f} m; Wikipedia prose says 18.7 m; gap {18.7 - (320.75 - 312.27):.2f} m")
print()
# Thermal expansion of a steel/puddle-iron column, linear coefficient alpha ~ 12e-6 per K (one source's 11e-6, another 12e-6).
L = 300.0
for alpha in (11e-6, 12e-6):
    for dT in (20, 40, 60, 80):
        print(f"alpha={alpha*1e6:.0f}e-6/K  dT={dT:>2} K  growth={L*alpha*dT*100:6.2f} cm")
print()
print("Antenna share of 330 m tip above 300 m architectural height: "
      f"{(330-300)/330*100:.1f}% of total; above 312.27 m flagpole value: {(330-312.27)/330*100:.1f}%")
print()
# Temperature swing that would give 15 cm for a uniform 300 m column
for alpha in (11e-6, 12e-6):
    print(f"swing needed for 15 cm at alpha={alpha*1e6:.0f}e-6/K: {0.15/(L*alpha):.1f} K")
# Ratios: smallest antenna step in the table (1994, +0.74 m) and DAB+ step (6 m) against a 15 cm seasonal figure
print(f"ratio 0.74 m step / 0.15 m: {0.74/0.15:.1f}x  (order of magnitude ~{__import__('math').log10(0.74/0.15):.2f})")
print(f"ratio 6.00 m step / 0.15 m: {6.00/0.15:.1f}x  (order of magnitude ~{__import__('math').log10(6.00/0.15):.2f})")
print(f"ratio 8.48 m step / 0.15 m: {8.48/0.15:.1f}x")

