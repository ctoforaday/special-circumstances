# Strong (Miller-Rabin) and plain Fermat tests on n = 91, swept over the bases
# 2..89 that share no factor with 91, with controls that the strong test must pass or fail.
import math

def decompose(n):
    s, d = 0, n - 1
    while d % 2 == 0:
        s, d = s + 1, d // 2
    return s, d

def fermat_pass(n, a):
    return pow(a, n - 1, n) == 1

def strong_pass(n, a):
    s, d = decompose(n)
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

n = 91
bases = [a for a in range(2, n - 1) if math.gcd(a, n) == 1]
print("n = 91: n-1 =", n - 1, "= 2^%d * %d" % decompose(n))
print("bases 2..89 coprime to 91:", len(bases))

plain = [a for a in bases if fermat_pass(n, a)]
strong = [a for a in bases if strong_pass(n, a)]
print("plain Fermat test passes:", len(plain), "of", len(bases))
print("strong test passes:", len(strong), "of", len(bases))
print("strong-test passing bases:", strong)
print("plain-test passing bases:", plain)

for a in (2, 3, 5, 11):
    print("strong test on 91, base %d: %s" % (a, strong_pass(91, a)))
print("3^45 mod 91 =", pow(3, 45, 91))

print("control: strong test on 2047 (= 23 * 89), base 2:", strong_pass(2047, 2))
for a in (2, 3, 5, 11):
    print("control: strong test on 97 (prime), base %d:" % a, strong_pass(97, a))
