# Arithmetic checks on n = 91. Run: python3 -I blue-lane-1-check91.py
import math

n = 91

# H1: trial division by primes up to sqrt(n)
def primes_upto(m):
    return [p for p in range(2, m + 1) if all(p % q for q in range(2, int(p**0.5) + 1))]

limit = math.isqrt(n)
trial = [p for p in primes_upto(limit) if n % p == 0]
print("H1 sqrt bound:", limit, "primes tried:", primes_upto(limit))
print("H1 divisors found among those primes:", trial)
print("H1 cofactor pairs:", [(d, n // d) for d in trial])

# All divisors by brute force
divs = [d for d in range(2, n) if n % d == 0]
print("H3/H1 all divisors in [2, n-1]:", divs)

# H2: Fermat tests in bases 2 and 3
for a in (2, 3):
    r = pow(a, n - 1, n)
    print(f"H2 base {a}: {a}^90 mod 91 = {r}; passes Fermat test: {r == 1}")

# Count bases in [2, 89] (coprime to 91) for which n passes Fermat test
coprime = [a for a in range(2, n - 1) if math.gcd(a, n) == 1]
passing = [a for a in coprime if pow(a, n - 1, n) == 1]
print("H2 coprime bases tested:", len(coprime), "bases passing:", len(passing))
print("H2 fraction passing:", round(len(passing) / len(coprime), 4))
print("H2 first 20 passing bases:", passing[:20])

# Euler-Jacobi / strong test base 2 and 3 for completeness
def strong(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False
for a in (2, 3, 5, 7, 11):
    print(f"strong test base {a} passes: {strong(n, a)}")

# Korselt criterion: squarefree, and p-1 divides n-1 for each prime p | n
print("Korselt: p-1 | n-1 for 7:", 90 % 6 == 0, "; for 13:", 90 % 12 == 0)
print("Carmichael (Korselt) holds for 91:", (90 % 6 == 0) and (90 % 12 == 0))

# H4: Gaussian integers Z[i]: 7 is inert (7 = 3 mod 4), so 7 is a Gaussian prime; 91 = 7*13 with 13 = (3+2i)(3-2i)
# Test: does any Gaussian prime divide 91 with a unit cofactor? Check norms.
def gauss_norm(a, b): return a * a + b * b
# 91 as Gaussian integer factorization check: is there a, b with a+bi dividing 91 and norm strictly between 1 and 91^2 non-trivially?
nontrivial = []
for a in range(-91, 92):
    for b in range(-91, 92):
        N = gauss_norm(a, b)
        if N in (0, 1):
            continue
        # divides 91 iff 91/(a+bi) is Gaussian integer: 91*(a-bi)/N integer
        if (91 * a) % N == 0 and (91 * b) % N == 0 and N != 91 * 91 and N not in (1,):
            if N not in (1, 91 * 91):
                nontrivial.append((a, b, N))
norms = sorted(set(x[2] for x in nontrivial))
print("H4 Gaussian divisors of 91 with norm not 1 or 91^2 (norms):", norms)

# Eisenstein integers: 7 = (3+ω)... 7 splits (7 ≡ 1 mod 3); 91 not prime there either: norm argument
# 91 has norm-divisor structure; check whether 91 is a prime element by counting: a prime element p has N(p) prime or p^2 for rational prime.
print("H4 Eisenstein: 91 = 7*13, both rational primes split in Z[omega] (7 = 1 mod 3, 13 = 1 mod 3), so 91 is reducible there too")

# H4 check: 91 is prime in the sense of the sieve? sieve to 100
sieve = [True] * 101
sieve[0] = sieve[1] = False
for i in range(2, 11):
    if sieve[i]:
        for j in range(i * i, 101, i):
            sieve[j] = False
print("Sieve says 91 prime:", sieve[91], "; primes up to 100 count:", sum(sieve))
