n = 91
divs = [d for d in range(2, 10) if n % d == 0]
print("divisors of 91 in 2..9:", divs)
print("smallest divisor:", divs[0], "cofactor:", n // divs[0])
print("remainders of 91 for 2, 3, 5:", [n % d for d in (2, 3, 5)])
print("7 mod 4 =", 7 % 4)
a, b, c, d = 3, 2, 3, -2
print("norm(3+2i) =", a*a + b*b, " norm(3-2i) =", c*c + d*d)
re, im = a*c - b*d, a*d + b*c
print("(3+2i)(3-2i) =", re, "+", im, "i")
print("7 * (3+2i)(3-2i) =", 7 * re)
