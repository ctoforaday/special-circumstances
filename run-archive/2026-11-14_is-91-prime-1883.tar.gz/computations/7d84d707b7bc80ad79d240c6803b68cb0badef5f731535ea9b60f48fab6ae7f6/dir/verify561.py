from math import gcd

def is_prime(n):
    return n > 1 and all(n % d for d in range(2, int(n ** 0.5) + 1))

def fermat_passes_all_coprime(n):
    bases = [a for a in range(2, n) if gcd(a, n) == 1]
    return bases, all(pow(a, n - 1, n) == 1 for a in bases)

def strong_passes(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

# 1. Composites up to 561 that pass the Fermat test for every base coprime to them.
hits = []
for n in range(4, 562):
    if is_prime(n):
        continue
    bases, ok = fermat_passes_all_coprime(n)
    if ok:
        hits.append(n)
print("composites n <= 561 passing the Fermat test for every base coprime to n:", hits)

# 2. For n = 561: count coprime bases and list those that fail the Fermat test.
n = 561
bases = [a for a in range(2, n) if gcd(a, n) == 1]
failing = [a for a in bases if pow(a, n - 1, n) != 1]
print("n = 561: coprime bases tested:", len(bases))
print("n = 561: coprime bases failing the Fermat test:", failing)
print("n = 561 = 3 * 11 * 17:", 3 * 11 * 17 == 561)

# 3. Strong probable-prime test for n = 561 with small bases.
for a in (2, 3, 5, 7):
    print("strong test, n = 561, base", a, ":", "passes" if strong_passes(561, a) else "rejects")

# 4. Strong test on 91 for base 3, for comparison with the Fermat result.
print("strong test, n = 91, base 3 :", "passes" if strong_passes(91, 3) else "rejects")
print("Fermat test, n = 91, base 3 : pow(3, 90, 91) =", pow(3, 90, 91))
