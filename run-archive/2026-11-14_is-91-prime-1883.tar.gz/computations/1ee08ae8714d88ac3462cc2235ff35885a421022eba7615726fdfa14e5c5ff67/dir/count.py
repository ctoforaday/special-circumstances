from math import gcd

n = 91
bases = [a for a in range(2, n) if gcd(a, n) == 1]
passing = [a for a in bases if pow(a, n - 1, n) == 1]
print("bases a with 2 <= a <= 90 that share no factor with 91:", len(bases))
print("of those, bases with a^90 mod 91 = 1 (pass the Fermat test):", len(passing))
print("passing bases:", passing)

small = range(2, 11)
print("bases 2 to 10 that pass (a^90 mod 91 = 1):", [a for a in small if pow(a, 90, 91) == 1])
print("bases 2 to 10 that fail:", [a for a in small if pow(a, 90, 91) != 1])
print("residues a^90 mod 91 for bases 2 to 10:", [pow(a, 90, 91) for a in small])
