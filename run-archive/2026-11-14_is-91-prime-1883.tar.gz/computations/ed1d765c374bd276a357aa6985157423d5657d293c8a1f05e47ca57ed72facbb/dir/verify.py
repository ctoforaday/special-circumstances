from math import gcd
n = 91
for a in range(2, 11):
    print(f"{a}^90 mod 91 = {pow(a, 90, n)}")
print("7^90 mod 91 =", pow(7, 90, n))
print("2^90 mod 7 =", pow(2, 90, 7), " 2^90 mod 13 =", pow(2, 90, 13))
print("3^90 mod 7 =", pow(3, 90, 7), " 3^90 mod 13 =", pow(3, 90, 13))
bases = [a for a in range(2, 91) if gcd(a, n) == 1]
passing = [a for a in bases if pow(a, 90, n) == 1]
print("coprime bases in 2..90:", len(bases), " passing:", len(passing))
print("64^90 mod 91 =", pow(64, 90, n))
