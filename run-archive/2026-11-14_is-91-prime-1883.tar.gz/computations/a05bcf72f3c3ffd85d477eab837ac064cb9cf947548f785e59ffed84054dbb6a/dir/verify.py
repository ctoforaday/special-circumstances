def isprime(k):
    return k > 1 and all(k % d for d in range(2, int(k ** 0.5) + 1))
ps = [k for k in range(2, 100) if isprime(k)]
print("primes below 100:", len(ps), "from", ps[0], "to", ps[-1])
print("91 among them:", 91 in ps)
print(ps)
