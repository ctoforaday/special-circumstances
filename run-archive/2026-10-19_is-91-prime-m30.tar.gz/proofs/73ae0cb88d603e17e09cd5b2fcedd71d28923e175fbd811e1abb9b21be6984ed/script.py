import math

# Terms <= 100 of OEIS A002808 (composite numbers), copied from the fetched data file (b-file), in order.
OEIS_B_TERMS_UP_TO_100 = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28, 30, 32, 33, 34, 35, 36, 38, 39, 40, 42, 44, 45, 46, 48, 49, 50, 51, 52, 54, 55, 56, 57, 58, 60, 62, 63, 64, 65, 66, 68, 69, 70, 72, 74, 75, 76, 77, 78, 80, 81, 82, 84, 85, 86, 87, 88, 90, 91, 92, 93, 94, 95, 96, 98, 99, 100]

def is_prime(n):
    if n < 2:
        return False
    for d in range(2, math.isqrt(n) + 1):
        if n % d == 0:
            return False
    return True

primes = [n for n in range(2, 101) if is_prime(n)]
composites = [n for n in range(2, 101) if not is_prime(n)]

assert len(primes) == 25, len(primes)
assert 91 not in primes
assert composites == OEIS_B_TERMS_UP_TO_100, "trial division disagrees with the OEIS data terms"
assert composites[65] == 91, composites[65]   # 66th term
print("primes up to 100:", len(primes))
print("composites 2..100 by trial division:", len(composites))
print("trial-division composites equal the OEIS A002808 data terms up to 100: True")
print("66th composite is", composites[65], "; 91 is composite with factor 7 x 13:", 7 * 13 == 91)
