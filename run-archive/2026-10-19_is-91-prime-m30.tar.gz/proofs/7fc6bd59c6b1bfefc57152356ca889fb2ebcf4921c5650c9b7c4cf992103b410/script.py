# Settles the arithmetic claims about 91: divisors, trial division, Fermat and strong (Miller-Rabin) tests, and the prime count below 100.
# Standalone: uses only the Python standard library and does not call any record tool.
from math import gcd, isqrt

n = 91

# Trial division over 2..isqrt(n)
limit = isqrt(n)
hits = [d for d in range(2, limit + 1) if n % d == 0]
assert limit == 9
assert hits == [7]
assert n // 7 == 13
print(f"trial division range 2..{limit}: divisors found {hits}; cofactor {n // hits[0]}")

# Full positive divisor list
divs = [d for d in range(1, n + 1) if n % d == 0]
assert divs == [1, 7, 13, 91]
print(f"positive divisors of {n}: {divs}")

# Fermat test, base 2
r = pow(2, n - 1, n)
assert r == 64
print(f"2^90 mod 91 = {r} (a prime would give 1)")

# Fermat liars among bases 2..89 that share no factor with 91
coprime = [a for a in range(2, n - 1) if gcd(a, n) == 1]
assert len(coprime) == 70
liars = [a for a in coprime if pow(a, n - 1, n) == 1]
assert len(liars) == 34
print(f"coprime bases 2..89: {len(coprime)}; Fermat passes: {len(liars)}")

# Strong (Miller-Rabin) test
d, s = n - 1, 0
while d % 2 == 0:
    d //= 2
    s += 1
assert (s, d) == (1, 45)
x = pow(2, d, n)
assert x == 57
print(f"n-1 = 2^{s} * {d}; base 2 gives 2^{d} mod 91 = {x}")

def strong_pass(a):
    y = pow(a, d, n)
    if y in (1, n - 1):
        return True
    for _ in range(s - 1):
        y = y * y % n
        if y == n - 1:
            return True
    return False

strong = [a for a in range(2, n - 1) if strong_pass(a)]
assert strong == [9, 10, 12, 16, 17, 22, 29, 38, 53, 62, 69, 74, 75, 79, 81, 82]
assert len(strong) == 16
assert all(gcd(a, n) == 1 for a in strong)
print(f"strong liars among bases 2..89: {len(strong)} -> {strong}")

# Primes below 100 by trial division
primes = [p for p in range(2, 100) if all(p % q for q in range(2, isqrt(p) + 1))]
assert len(primes) == 25
assert 91 not in primes
print(f"primes below 100: {len(primes)}; 91 among them: {91 in primes}")
