# Independent checks of whether 91 is prime. Standard library only.
import math

N = 91

# 1. Trial division by every integer d with 2 <= d <= floor(sqrt(N)).
limit = math.isqrt(N)
divisors = [d for d in range(2, limit + 1) if N % d == 0]
print(f"trial_division_range=2..{limit}")
print(f"divisors_found_in_range={divisors}")
print(f"cofactor_of_first_divisor={N // divisors[0] if divisors else None}")
print(f"factorisation_check_7x13={7 * 13 == N}")

# 2. Sieve of Eratosthenes up to 100, independent of step 1.
sieve = [True] * 101
sieve[0] = sieve[1] = False
for i in range(2, 11):
    if sieve[i]:
        for j in range(i * i, 101, i):
            sieve[j] = False
primes_below_100 = [i for i in range(100) if sieve[i]]
print(f"primes_below_100_count={len(primes_below_100)}")
print(f"91_in_sieve_prime_list={91 in primes_below_100}")

# 3. Fermat test: a^(N-1) mod N for bases 2..N-2.
fermat_liar_bases = [a for a in range(2, N - 1) if pow(a, N - 1, N) == 1]
print(f"pow2_90_mod_91={pow(2, 90, 91)}")
print(f"pow3_90_mod_91={pow(3, 90, 91)}")
print(f"fermat_pass_bases_2_to_89_count={len(fermat_liar_bases)}")
print(f"fermat_pass_bases_first_10={fermat_liar_bases[:10]}")

# 4. Miller-Rabin (strong test). N-1 = 2^s * d with d odd.
s, d = 0, N - 1
while d % 2 == 0:
    s += 1
    d //= 2
print(f"N_minus_1_decomposition s={s} d={d}")

def strong_pass(a):
    x = pow(a, d, N)
    if x in (1, N - 1):
        return True
    for _ in range(s - 1):
        x = (x * x) % N
        if x == N - 1:
            return True
    return False

strong_liars = [a for a in range(2, N - 1) if strong_pass(a)]
print(f"strong_liar_bases_2_to_89_count={len(strong_liars)}")
print(f"strong_liar_bases_first_10={strong_liars[:10]}")
print(f"base2_strong_test_passes={strong_pass(2)}")

# 5. Verdict from a definitive witness: any divisor in range means composite.
verdict = "composite" if divisors else "prime"
print(f"verdict_by_trial_division={verdict}")
