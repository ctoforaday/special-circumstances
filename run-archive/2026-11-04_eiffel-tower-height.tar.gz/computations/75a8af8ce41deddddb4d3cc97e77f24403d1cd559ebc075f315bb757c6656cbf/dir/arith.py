# Height-chain arithmetic for the Eiffel Tower report, with every input stated in metres as the cited sources print it.
from decimal import Decimal as D

structure_1889 = D("300")          # iron structure, 1889 (cited official history page)
flag_1889_top = D("312")           # "a little more than 312 metres" with the 1889 flag (cited)
antenna_1957 = D("18.7")           # 1957 television antenna increase (cited Wikipedia)
figure_1957_1991 = D("320.75")     # Wikipedia height table, 1957 to 1991 (cited)
figure_1991_1994 = D("317.96")     # table, 1991 to 1994 (cited)
figure_1994_2000 = D("318.7")      # table, 1994 to 2000 (cited)
figure_2000 = D("324")             # official history page, after 2000 UHF antenna (cited)
addition_2022 = D("6")             # 2022 DAB+ antenna (cited)

def show(label, value):
    print(f"{label}: {value} m")

# S1: removing the 1957 antenna from the 1957-1991 figure
base = figure_1957_1991 - antenna_1957
show("1957-1991 figure minus 1957 antenna (base)", base)
show("base minus the 1889 structure", base - structure_1889)

# S2: 1949 top (about 312) plus the 1957 antenna, against the table figure
chain = flag_1889_top + antenna_1957
show("1889 flag top plus 1957 antenna", chain)
show("gap to the table figure 320.75", chain - figure_1957_1991)

# S3: the 2000 step applied to each candidate 1991-1994 or 1994-2000 value
step_2000 = figure_2000 - figure_1994_2000
show("2000 step (324 minus 318.7)", step_2000)
from_317_96 = figure_1991_1994 + step_2000
show("317.96 plus the 2000 step", from_317_96)
show("shortfall of that result from 324", figure_2000 - from_317_96)
show("318.7 plus the 2000 step recovers 324", figure_1994_2000 + step_2000)

# S4: the 2022 step
show("324 plus the 2022 addition", figure_2000 + addition_2022)
