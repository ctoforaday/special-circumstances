# Adds the cited 2000 height step, typed as the 5.3 m the cited sentence gives, to each pre-2000 table value.
from decimal import Decimal as D

step_2000 = D("5.3")           # "added a further 5.3 m (17 ft)" for work in 2000, as the cited sentence prints it
table_1994_2000 = D("318.7")   # cited table value, 1994 to 2000
table_1991_1994 = D("317.96")  # cited table value, 1991 to 1994
total_2000 = D("324")          # cited total after the 2000 work

print(f"318.7 plus typed 5.3 step: {table_1994_2000 + step_2000} m")
print(f"317.96 plus typed 5.3 step: {table_1991_1994 + step_2000} m")
print(f"shortfall of 317.96 result from the cited total 324: {total_2000 - (table_1991_1994 + step_2000)} m")
