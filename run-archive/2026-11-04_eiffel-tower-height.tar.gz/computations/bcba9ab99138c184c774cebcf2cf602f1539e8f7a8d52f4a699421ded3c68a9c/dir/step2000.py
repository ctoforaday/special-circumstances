# Reconciliation of the Eiffel Tower's 2000 height step, with the step typed as the value the cited source prints.
from decimal import Decimal as D

step_2000 = D("5.3")          # "added a further 5.3 m (17 ft)" for work in 2000 (cited Wikipedia article)
total_2000 = D("324")         # "giving a total height of 324 m" (same cited sentence)
table_1994_2000 = D("318.7")  # Wikipedia height table, 1994 to 2000 (cited)
table_1991_1994 = D("317.96") # Wikipedia height table, 1991 to 1994 (cited)

print(f"318.7 plus typed 2000 step: {table_1994_2000 + step_2000} m")
print(f"318.7 plus typed 2000 step equals cited total 324: {table_1994_2000 + step_2000 == total_2000}")
print(f"317.96 plus typed 2000 step: {table_1991_1994 + step_2000} m")
print(f"shortfall of that result from 324: {total_2000 - (table_1991_1994 + step_2000)} m")
print(f"typed step equals 324 minus 318.7: {step_2000 == total_2000 - table_1994_2000}")
