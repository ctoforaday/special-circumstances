# Height chain arithmetic over figures quoted from cited sources.
# Each input carries the source it comes from; nothing is measured here.
FT_PER_M = 3.28084

# official history page (1889 entry): "exactly 984 feet tall", named "300m Tower"
structure_1889_ft = 984.0
structure_1889_m = 300.0
# official history page (1889 entry): flagpole took height to "a little more than 312 metres"
flag_height_1889_m = 312.0
# cached Wikipedia article: television antenna first installed 1957, "increasing its height by 18.7 m"
tv_antenna_1957_m = 18.7
# cached Wikipedia height table
table_1957_1991_m = 320.75
table_1991_1994_m = 317.96
table_1994_2000_m = 318.7
# cached Wikipedia: "Work carried out in 2000 added a further 5.3 m, giving a total height of 324 m"
work_2000_m = 5.3
table_2000_m = 324.0
# official pages: 2022 DAB+ antenna "+6 meters", reached 330 metres
antenna_2022_m = 6.0
table_2022_m = 330.0

print("1889 structure in feet converted to metres: %.2f (published 300 m)" % (structure_1889_ft / FT_PER_M))
print("1889 flagpole increment over structure: %.2f m" % (flag_height_1889_m - structure_1889_m))
pre_1957 = table_1957_1991_m - tv_antenna_1957_m
print("height before 1957 antenna implied by table: %.2f m" % pre_1957)
print("residual of that against 1889 structure (300 m): %.2f m" % (pre_1957 - structure_1889_m))
print("residual of that against 1889 structure plus flagpole (312 m): %.2f m" % (pre_1957 - flag_height_1889_m))
print("1991 step, 320.75 -> 317.96: %.2f m" % (table_1991_1994_m - table_1957_1991_m))
print("1994 step, 317.96 -> 318.7: %.2f m (no stated cause in cited sources)" % (table_1994_2000_m - table_1991_1994_m))
print("2000 step, 318.7 + 5.3 = %.2f; table 324 m; residual %.2f m" % (table_1994_2000_m + work_2000_m, table_2000_m - (table_1994_2000_m + work_2000_m)))
print("2022 step, 324 + 6 = %.2f; table 330 m; residual %.2f m" % (table_2000_m + antenna_2022_m, table_2022_m - (table_2000_m + antenna_2022_m)))
