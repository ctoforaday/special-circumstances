# Linear thermal expansion of a 330 m steel/wrought-iron vertical structure.
# Coefficient: iron/steel ~1.2e-5 per K (textbook value; assumption, not measured on this tower).
H = 330.0          # m, current published height (Wikipedia, official 2022 figure)
alpha = 1.2e-5     # per K, assumption
for dT in (10, 20, 30, 40):   # K swing between winter and summer
    dH_cm = H * alpha * dT * 100
    print(f"dT={dT:>2} K  -> dH = {dH_cm:5.1f} cm")
# Published range 12-15 cm implies dT of:
for target in (12, 15):
    print(f"target {target} cm -> dT = {target/100/(H*alpha):5.1f} K")
# Precision check: a published height in whole metres has half-metre rounding = 50 cm
print("whole-metre rounding half-width: 50 cm; ratio of 15 cm swing to that:", round(15/50, 2))
