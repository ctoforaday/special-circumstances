# Share of true heights whose whole-metre rounding changes across a seasonal swing.
# Assumptions: linear thermal expansion, coefficient 1.2e-5 per kelvin, height 330 m,
# swings of 10 to 40 K; true height placed uniformly within a 1 m rounding interval.
from fractions import Fraction as F
import math

ALPHA = F(12, 10**6)
H = F(330)
N = 1_000_000  # grid positions across one metre of rounding interval

def rounds_differently(frac, d):
    # frac in [0,1): fractional position of the true height; d: seasonal range in metres
    return math.floor(frac + 0.5) != math.floor(frac + d + 0.5)

print("swing_K  range_cm  analytic_share_pct  grid_share_pct")
for dT in (10, 20, 30, 40):
    D = ALPHA * H * dT              # exact seasonal range in metres
    d = float(D)
    changed = sum(1 for i in range(N) if rounds_differently(i / N, d))
    print(f"{dT:7d}  {float(D*100):8.2f}  {float(D*100):18.2f}  {100*changed/N:14.2f}")
