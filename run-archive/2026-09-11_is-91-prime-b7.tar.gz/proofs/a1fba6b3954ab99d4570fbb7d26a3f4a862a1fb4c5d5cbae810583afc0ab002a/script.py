#!/usr/bin/env python3
"""Full census of the plain Fermat test (b^(n-1) mod n) against every base
b in [2, 89], distinguishing it from the stronger Miller-Rabin census already
run in fips186_5_miller_rabin_91.py -- answers whether the set of bases that
fool Fermat is the same as, or larger than, the set that fools Miller-Rabin."""

n = 91
fermat_pass = sorted(b for b in range(2, n - 1) if pow(b, n - 1, n) == 1)
print(f"bases b in [2, {n-2}] with b^{n-1} mod {n} == 1 (Fermat liars): "
      f"{len(fermat_pass)} of {n-3} -> {fermat_pass}")

mr_false = {9, 10, 12, 16, 17, 22, 29, 38, 53, 62, 69, 74, 75, 79, 81, 82}
print(f"Miller-Rabin false witnesses (from fips186_5_miller_rabin_91.py): {sorted(mr_false)}")
print(f"Fermat liars not caught by Miller-Rabin either: {sorted(set(fermat_pass) & mr_false)}")
print(f"Fermat liars that Miller-Rabin DOES catch (extra squaring closes the gap): "
      f"{sorted(set(fermat_pass) - mr_false)}")
