#!/usr/bin/env bash
# Cross-checks 91's primality and factorization against two independently
# authored, widely deployed tools that were not written to answer this
# question: GNU coreutils' factor, and OpenSSL's prime subcommand.
set -euo pipefail
echo "factor 91: $(factor 91)"
echo "factor 7:  $(factor 7)"
echo "factor 13: $(factor 13)"
echo "openssl prime 91: $(openssl prime 91 2>&1)"
echo "openssl prime 7:  $(openssl prime 7 2>&1)"
echo "openssl prime 13: $(openssl prime 13 2>&1)"
