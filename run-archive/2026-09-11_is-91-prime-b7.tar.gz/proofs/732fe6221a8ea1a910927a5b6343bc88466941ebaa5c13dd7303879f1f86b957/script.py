#!/usr/bin/env python3
"""Two small self-contained checks on 91, run independently of any external claim:
(1) the classical digit rule for divisibility by 7 (double the last digit and
subtract it from the remaining leading digits; repeat until small enough to judge),
applied to 91; (2) Euler's totient of 91, computed directly from its prime
factorization, compared against the count of misleading Miller-Rabin witness
bases already found by fips186_5_miller_rabin_91.py."""

n = 91
last = n % 10
rest = n // 10
check = rest - 2 * last
print(f"digit rule for 7 on {n}: last digit {last}, remaining leading digits {rest}, "
      f"{rest} - 2*{last} = {check} -> divisible by 7: {check % 7 == 0}")

def phi(n):
    result, nn, p = n, n, 2
    while p * p <= nn:
        if nn % p == 0:
            while nn % p == 0:
                nn //= p
            result -= result // p
        p += 1
    if nn > 1:
        result -= result // nn
    return result

print(f"phi(91) = {phi(91)}  (phi(7) = {phi(7)}, phi(13) = {phi(13)}, product = {phi(7)*phi(13)})")

composite_witnesses = 72
tested_bases = 88
noncoprime_tested = sum(1 for b in range(2, 90) if b % 7 == 0 or b % 13 == 0)
coprime_tested = tested_bases - noncoprime_tested
false_witnesses = coprime_tested - (composite_witnesses - noncoprime_tested)
print(f"tested bases 2..89: {tested_bases}; non-coprime to 91 among them: {noncoprime_tested}; "
      f"coprime tested: {coprime_tested}")
print(f"false (probably-prime) witnesses among coprime tested bases: {false_witnesses} "
      f"of {coprime_tested} ({100*false_witnesses/coprime_tested:.1f}%)")
print(f"reconciles with phi(91) = {phi(91)} (72 coprime residues in [1,90], "
      f"minus residues 1 and 90 = {phi(91)-2} coprime bases in the tested range [2,89])")
