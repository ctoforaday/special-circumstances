#!/usr/bin/env python3
"""Independent algorithmic cross-check for 91's primality: Fermat test (bases 2,3,5)
and deterministic Miller-Rabin (bases sufficient for n < 3,317,044,064,679,887,385,961,981),
neither of which searches for an explicit factor."""

n = 91

def fermat_witness(a, n):
    return pow(a, n - 1, n) != 1

print(f"Fermat test on n = {n}:")
for a in (2, 3, 5):
    r = pow(a, n - 1, n)
    print(f"  {a}^{n-1} mod {n} = {r}  -> {'FAILS (composite witness)' if r != 1 else 'passes (inconclusive)'}")

def is_probable_prime_miller_rabin(n, bases):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in bases:
        if a % n == 0:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
result = is_probable_prime_miller_rabin(n, bases)
print(f"\nDeterministic Miller-Rabin (bases {bases}) on {n}: {'probably prime' if result else 'composite'}")
