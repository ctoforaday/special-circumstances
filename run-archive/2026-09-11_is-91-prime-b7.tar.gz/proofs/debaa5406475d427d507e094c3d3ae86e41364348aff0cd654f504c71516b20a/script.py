#!/usr/bin/env python3
"""Deterministic re-implementation of the Miller-Rabin test as specified in
NIST FIPS 186-5, Appendix B.3.1 ("Miller-Rabin Probabilistic Primality Test"),
run against every witness base b in [2, w-2] instead of a random DRBG sample —
turning the probabilistic procedure into an exhaustive one for a number this
small, so the result is settled rather than merely likely."""

def miller_rabin_fips_186_5(w, b):
    """Steps 1-5 of FIPS 186-5 Appendix B.3.1, for one candidate witness b."""
    a = 0
    m = w - 1
    while m % 2 == 0:
        m //= 2
        a += 1
    z = pow(b, m, w)
    if z == 1 or z == w - 1:
        return "PROBABLY PRIME"
    for _ in range(a - 1):
        z = (z * z) % w
        if z == w - 1:
            return "PROBABLY PRIME"
        if z == 1:
            return "COMPOSITE"
    return "COMPOSITE"

w = 91
results = {}
for b in range(2, w - 1):
    results[b] = miller_rabin_fips_186_5(w, b)

composite_witnesses = sorted(b for b, r in results.items() if r == "COMPOSITE")
prime_looking = sorted(b for b, r in results.items() if r == "PROBABLY PRIME")

print(f"w = {w}")
print(f"witnesses tested: b = 2 .. {w - 2} (every value the FIPS 186-5 procedure could draw)")
print(f"bases returning COMPOSITE: {len(composite_witnesses)} of {len(results)} -> {composite_witnesses}")
print(f"bases returning PROBABLY PRIME (false witnesses to primality, none disqualifying): {prime_looking}")
print()
if composite_witnesses:
    print("VERDICT: at least one base returns COMPOSITE under the FIPS 186-5 B.3.1 procedure, "
          "so 91 fails the Miller-Rabin test and is composite.")
else:
    print("VERDICT: no base returns COMPOSITE; 91 is a probable prime under every witness tried.")
