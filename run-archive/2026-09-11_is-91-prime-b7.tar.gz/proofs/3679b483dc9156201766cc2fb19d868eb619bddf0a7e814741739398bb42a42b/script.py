#!/usr/bin/env python3
"""Confirms, by exhaustive check rather than by trusting the standard theorem's
statement, that the square-root bound used by trial division on 91 is not a
partial sample: every divisor pair of 91 has its smaller member at or below
floor(sqrt(91)), so scanning 2..9 cannot miss a factor that a wider scan would
find."""
import math

n = 91
limit = math.isqrt(n)
all_divisors = [d for d in range(1, n + 1) if n % d == 0]
pairs = [(d, n // d) for d in all_divisors if d <= n // d]

print(f"n = {n}, floor(sqrt(n)) = {limit}")
print(f"every divisor of {n}: {all_divisors}")
print(f"divisor pairs (d, n/d) with d <= n/d: {pairs}")
for d, co in pairs:
    print(f"  min({d}, {co}) = {min(d, co)} <= {limit}: {min(d, co) <= limit}")

within_bound = all(min(d, co) <= limit for d, co in pairs)
print()
print(f"VERDICT: every divisor pair's smaller member is within the sqrt bound: {within_bound}")
print(f"primes at or below the bound: {[p for p in (2,3,5,7) if p <= limit]} "
      f"(no prime above {limit} needs to be tried to catch a factor of {n})")
