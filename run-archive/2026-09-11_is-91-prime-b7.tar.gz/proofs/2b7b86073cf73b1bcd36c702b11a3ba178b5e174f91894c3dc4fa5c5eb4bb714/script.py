#!/usr/bin/env python3
"""Trial division primality check for 91, testing every integer divisor up to floor(sqrt(91))."""
import math

n = 91
limit = math.isqrt(n)
divisors = []
for d in range(2, limit + 1):
    if n % d == 0:
        divisors.append(d)

print(f"n = {n}")
print(f"floor(sqrt(n)) = {limit}")
print(f"divisors found in [2, {limit}]: {divisors}")
if divisors:
    d = divisors[0]
    print(f"{n} = {d} * {n // d}")
    print("VERDICT: composite")
else:
    print("VERDICT: prime")
