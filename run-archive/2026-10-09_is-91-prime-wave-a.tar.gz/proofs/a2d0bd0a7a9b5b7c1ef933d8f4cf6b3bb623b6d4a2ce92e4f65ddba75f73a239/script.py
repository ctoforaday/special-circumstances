"""Count the primes below 100 by trial division and test whether 91 is one of them.

Establishes: there are 25 primes below 100, and 91 is not among them.
"""

def is_prime(n: int) -> bool:
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True


primes = [n for n in range(2, 100) if is_prime(n)]
print("primes below 100:", len(primes))
print("91 among them:", 91 in primes)
print("last five:", primes[-5:])
