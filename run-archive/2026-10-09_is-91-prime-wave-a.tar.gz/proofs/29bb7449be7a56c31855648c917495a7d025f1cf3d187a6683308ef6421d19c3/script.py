import math


def primes_upto(n):
    return [p for p in range(2, n + 1) if all(p % q for q in range(2, math.isqrt(p) + 1))]


n = 91
small = primes_upto(math.isqrt(n))
print("square root of 91 (rounded):", round(math.sqrt(n), 2))
print("primes not larger than the square root:", small)
print("those primes that divide 91:", [p for p in small if n % p == 0])
print("integers from 2 to 90 that divide 91:", [d for d in range(2, 91) if n % d == 0])
print("quotient of 91 by 7:", n // 7)
print("numeral 91 read in base 12 denotes:", 9 * 12 + 1)
print("109 is prime:", primes_upto(109)[-1] == 109)
print("primes below 100:", primes_upto(99))
print("count of primes below 100:", len(primes_upto(99)))
print("91 among primes below 100:", 91 in primes_upto(99))
