def order(a, m):
    k, x = 1, a % m
    while x != 1:
        x = (x * a) % m
        k += 1
    return k


for a in (2, 3, 5, 7, 10):
    print("base", a, "a^90 mod 91 =", pow(a, 90, 91))
print("order of 3 mod 7 =", order(3, 7))
print("order of 3 mod 13 =", order(3, 13))
print("both orders divide 90:", 90 % order(3, 7) == 0 and 90 % order(3, 13) == 0)
print("3^91 mod 91 =", pow(3, 91, 91))
pseudo = [n for n in range(4, 300)
          if n % 3 and any(n % d == 0 for d in range(2, n)) and pow(3, n - 1, n) == 1]
print("base-3 Fermat pseudoprimes below 300:", pseudo[:5])
