import math

LIMIT = 10000
composites = 0
failures = []
for n in range(4, LIMIT + 1):
    smallest = next((d for d in range(2, n) if n % d == 0), None)
    if smallest is None:
        continue
    composites += 1
    # smallest divisor of a composite n is a prime; check it is no larger than sqrt(n)
    if smallest > math.isqrt(n):
        failures.append(n)
print("composites checked from 4 to", LIMIT, ":", composites)
print("composites whose smallest prime factor exceeds the square root:", failures)
