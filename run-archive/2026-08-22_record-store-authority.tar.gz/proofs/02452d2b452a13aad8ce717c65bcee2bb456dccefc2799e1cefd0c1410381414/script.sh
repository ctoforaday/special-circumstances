#!/bin/sh
# P4 — the live read path's behaviour on a line it cannot parse, at the pin AND at the working
# tree's HEAD (the two differ elsewhere in replay.go, so the comparison is stated, not assumed).
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
REC=plugins/frank-exchange-of-views/tools/internal/record
cd "$REPO"

extract() { sed -n '/^func ReadShard(/,/^}/p'; }

echo "pin=$PIN  head=$(git rev-parse --short=8 HEAD)"
echo "--- ReadShard at the pin ---"
git show $PIN:$REC/replay.go | extract | sed 's/^/  /'
A=$(git show $PIN:$REC/replay.go | extract | shasum | cut -d' ' -f1)
B=$(git show HEAD:$REC/replay.go | extract | shasum | cut -d' ' -f1)
echo "ReadShard sha1 at pin : $A"
echo "ReadShard sha1 at HEAD: $B"
[ "$A" = "$B" ] && echo "IDENTICAL at pin and HEAD" || echo "DIFFERENT at pin and HEAD"
echo "--- what the built-but-unwired replacement says about that behaviour ---"
git show $PIN:$REC/recordpb/read_test.go | grep -n 'pre-existing behaviour this replaces' -B 2 | sed 's/^/  /'
