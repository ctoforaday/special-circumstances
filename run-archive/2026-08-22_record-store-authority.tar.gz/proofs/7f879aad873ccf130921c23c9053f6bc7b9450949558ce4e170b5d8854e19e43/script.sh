#!/bin/sh
# P16 — R1-4: Analysis's "no test asserts that a promoted precedent's source run still resolves
# to anything" carried no proof anchor; it is a negative census. This script runs that census
# so a reader can re-verify the negative directly rather than trust the prose.
set -eu
REPO=/home/user/special-circumstances
cd "$REPO"

echo "--- every test-file hit for 'precedents' in the tools tree ---"
git grep -n "precedents" -- 'plugins/frank-exchange-of-views/tools/**_test.go' | sed 's/^/  /'
echo "--- what the one hit actually asserts ---"
sed -n '170,190p' plugins/frank-exchange-of-views/tools/internal/setup/setup_test.go | sed 's/^/  /'
echo "--- census: does any test assert a promoted PRECEDENT's SOURCE RUN still resolves? ---"
echo "  files mentioning 'provenance' in the tools test tree, and what each is about:"
git grep -ln "provenance" -- 'plugins/frank-exchange-of-views/tools/**_test.go' | sed 's/^/    /'
echo "  none of those hits concern a precedent's source run (they cover gap --answers"
echo "  provenance (#267) and citation provenance, a different concept sharing the word):"
git grep -n "provenance" -- 'plugins/frank-exchange-of-views/tools/**_test.go' | grep -iv "precedent" | cut -c1-140 | sed 's/^/    /'
echo "  a targeted search for the specific claim finds nothing:"
git grep -ln "precedent.*source run\|precedent.*still resolves\|precedent.*SourceRun" -- 'plugins/frank-exchange-of-views/tools/**_test.go' || echo "    (no matches)"
