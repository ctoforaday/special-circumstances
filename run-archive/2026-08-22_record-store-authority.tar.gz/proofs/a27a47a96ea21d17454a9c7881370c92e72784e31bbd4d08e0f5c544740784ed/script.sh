#!/bin/sh
# P11 — the 16-of-227 false-fatal count red flagged as stale (R1-1): the first-draft classifier
# misclassified 16 of 227 truncation offsets as fatal; the fuzz test asserts that count is now
# zero, by rule, and CI-enforced. This script proves the CURRENT state, not the historical one.
set -eu
REPO=/home/user/special-circumstances
TOOLS=$REPO/plugins/frank-exchange-of-views/tools
cd "$TOOLS"

echo "--- running the fuzz test that asserts zero false fatals at every truncation offset ---"
go test ./internal/record/recordpb/ -run TestTruncationAtEveryOffsetNeverYieldsAFalseEvent -v

echo "--- the plan's own resolution line, three lines past the historical 16-of-227 row ---"
git grep -n 'now zero by rule rather than by luck' cd1fc73 -- plans/record-protobuf.md | cut -c1-260 | sed 's/^/  /'
