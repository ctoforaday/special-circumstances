#!/bin/sh
# P9 — would a pull request that wires the schema discriminator into the live path be caught by
# the repository's own protocol-surface sibling-sweep gate?
set -eu
cd /home/user/special-circumstances
PIN=cd1fc73

echo "pin=$PIN — the protocol surfaces rulesweep gates:"
git show $PIN:scripts/rulesweep/sweep.go | sed -n '/^var protocolSurfaces/,/^}/p' | grep 'MustCompile' | sed 's/^\t*/  /'
echo "patterns matching .proto or internal/record: $(git show $PIN:scripts/rulesweep/sweep.go | sed -n '/^var protocolSurfaces/,/^}/p' | grep -c 'proto\\\.\|internal/record' || true)"
