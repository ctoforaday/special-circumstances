#!/bin/sh
# P15 — R1-4: F4's "run 2's deselected shard holds the ten citations whose anchors still sit
# unresolved in that report" carried no proof anchor. This script extracts the committed archive
# and counts cite events per shard directly.
set -eu
REPO=/home/user/special-circumstances
ARCHIVE=run-archive/2026-08-22_is-7-prime-run2.tar.gz
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
cd "$REPO"

tar xzf "$ARCHIVE" -C "$WORK"
echo "--- cite events per shard, run 2's archived records/ ---"
find "$WORK" -path '*records/events-*.jsonl' | while read -r shard; do
  n=$(grep -c '"type":"cite"' "$shard" || true)
  echo "  $(basename "$shard"): $n"
done
