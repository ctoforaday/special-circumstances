#!/bin/sh
# P3 — what actually survives a run, by default? Tracked-ness at the pinned commit, plus the
# ignore rule that covers the run directory (report.md included, not just records/).
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
cd "$REPO"

echo "pin=$PIN"
echo "tracked run-archive tarballs: $(git ls-tree -r --name-only $PIN -- run-archive/ | wc -l | tr -d ' ')"
git ls-tree -r --name-only $PIN -- run-archive/ | sed 's/^/  /'
echo "tracked law/proposed harvests: $(git ls-tree -r --name-only $PIN -- law/proposed/ | wc -l | tr -d ' ')"
echo "tracked files under research/ at the pin: $(git ls-tree -r --name-only $PIN -- research/ | wc -l | tr -d ' ')"
git ls-tree -r --name-only $PIN -- research/ | sed 's/^/  /'
echo "--- the ignore rule, quoted from the pin ---"
git show $PIN:.gitignore | grep -n 'research/\*/' | sed 's/^/  /'
echo "--- what that rule catches in THIS run (working tree) ---"
git check-ignore -v research/2026-08-22_record-store-authority/report.md | sed 's/^/  /'
git check-ignore -v research/2026-08-22_record-store-authority/records | sed 's/^/  /'
echo "--- every 'retention' mention in plans/ or CLAUDE.md at the pin, and what it governs ---"
git grep -i -n 'retention' $PIN -- 'plans/*' CLAUDE.md | cut -c1-150 | sed 's/^/  /'
echo "  mentions naming records/ or run-archive/: $(git grep -i -n 'retention' $PIN -- 'plans/*' CLAUDE.md | grep -c 'records/\|run-archive' || true)"
