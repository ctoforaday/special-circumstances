#!/bin/sh
# Who mentions run-archive, who can decompress a tarball, and what is actually tracked in git.
# File-type UNFILTERED, to avoid the verification-file-type blindspot.
set -e
REPO=/home/user/special-circumstances
cd "$REPO"

echo "HEAD=$(git rev-parse --short HEAD)"

echo "files mentioning 'run-archive' (all file types, excluding .git and research/):"
grep -rl "run-archive" . --exclude-dir=.git --exclude-dir=research --exclude-dir=node_modules \
  | sed 's|^\./||' | sort

echo "tar.NewReader / gzip.NewReader call sites in the repo:"
grep -rn "tar\.NewReader\|gzip\.NewReader" --include='*.go' . | sed 's|^\./||' | sort

echo -n "tracked tarballs under run-archive/: "; git ls-files run-archive/ | wc -l | tr -d ' '
echo -n "tracked files under law/proposed/: "; git ls-files law/proposed/ | wc -l | tr -d ' '
echo -n "tracked files under research/: "; git ls-files research/ | wc -l | tr -d ' '
echo -n "tracked files under research/ (names): "; git ls-files research/ | tr '\n' ' '
echo
echo -n ".gitignore rule for run directories: "; grep -n '^research/\*/$' .gitignore

echo -n "retention wording in plans/storage.md, CLAUDE.md, research-protocol SKILL: "
grep -ric "retention" plans/storage.md CLAUDE.md plugins/frank-exchange-of-views/skills/research-protocol/SKILL.md \
  | awk -F: '{s+=$2} END {print s+0}'

echo -n "rulesweep protocolSurfaces regex count: "
sed -n '/^var protocolSurfaces = /,/^}/p' scripts/rulesweep/sweep.go | grep -c 'regexp.MustCompile'
echo "protocolSurfaces patterns:"
sed -n '/^var protocolSurfaces = /,/^}/p' scripts/rulesweep/sweep.go | grep 'regexp.MustCompile' | sed 's/^[ 	]*/  /'
echo -n "any protocolSurfaces pattern matching .proto or internal/record: "
if sed -n '/^var protocolSurfaces = /,/^}/p' scripts/rulesweep/sweep.go | grep 'regexp.MustCompile' | grep -q '\.proto\|internal/record'; then echo yes; else echo no; fi
