#!/bin/sh
# P6 — evidence-base integrity: the run's PINNED commit versus the working tree the lane drafts
# actually read, and exactly which cited files moved between them.
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
cd "$REPO"

echo "pinned in inputs/PINNED.md: $PIN"
echo "working-tree HEAD        : $(git rev-parse --short=8 HEAD)"
echo "commits from pin to HEAD : $(git rev-list --count $PIN..HEAD)"
echo "--- files changed between them, whole tree ---"
git diff --stat $PIN HEAD | sed 's/^/  /'
echo "--- of the files this report cites, which moved? ---"
for f in \
  plugins/frank-exchange-of-views/tools/internal/record/record.go \
  plugins/frank-exchange-of-views/tools/internal/record/replay.go \
  plugins/frank-exchange-of-views/tools/internal/record/recordpb/record.proto \
  plugins/frank-exchange-of-views/tools/internal/capture/capture.go \
  plugins/frank-exchange-of-views/tools/internal/setup/setup.go \
  CLAUDE.md .gitignore ; do
  if git diff --quiet $PIN HEAD -- "$f"; then echo "  unchanged: $f"; else echo "  CHANGED  : $f"; fi
done
