#!/bin/sh
# P12 — fixes the class red flagged in R1-3: p6-evidence-base.sh compared the pin against a LIVE
# HEAD, so its "commits from pin to HEAD" line drifts upward every time the repo advances and no
# longer matches the frozen number F8's sentence states. This script compares the pin against the
# SAME two fixed commits the sentence names — cd1fc73 (the pin) and 106f412f (the commit the lane
# drafts actually read) — so it reproduces the same result on every re-run, not just today's.
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
LANES_TREE=106f412f
cd "$REPO"

echo "pin (frozen)        : $PIN"
echo "lanes'-tree (frozen) : $LANES_TREE"
echo "commits from pin to lanes'-tree : $(git rev-list --count $PIN..$LANES_TREE)"
echo "--- of the files this report cites, which moved between pin and lanes'-tree? ---"
for f in \
  plugins/frank-exchange-of-views/tools/internal/record/record.go \
  plugins/frank-exchange-of-views/tools/internal/record/replay.go \
  plugins/frank-exchange-of-views/tools/internal/record/recordpb/record.proto \
  plugins/frank-exchange-of-views/tools/internal/capture/capture.go \
  plugins/frank-exchange-of-views/tools/internal/setup/setup.go \
  CLAUDE.md .gitignore ; do
  if git diff --quiet $PIN $LANES_TREE -- "$f"; then echo "  unchanged: $f"; else echo "  CHANGED  : $f"; fi
done
echo "--- informational only, NOT part of the claim above: today's live working-tree HEAD ---"
echo "live HEAD (advisory, will differ on every future re-run): $(git rev-parse --short=8 HEAD)"
