#!/bin/sh
# P7 — is a FOREIGN, finished run's archived record mechanically readable by the live binary today?
# Extract a committed archive of a different run into a scratch directory and point the tool's
# board projection at it. Nothing is written into either run directory.
#
# The answer is a count, not the board itself, so the output is stable across runs.
set -eu
REPO=/home/user/special-circumstances
ARCHIVE=$REPO/run-archive/2026-08-22_sqlite-schema-source.tar.gz
BIN=$(ls /tmp/claude-0/*/*/scratchpad/runbin/feov-record 2>/dev/null | head -1 || true)
[ -n "$BIN" ] || BIN=$(command -v feov-record || true)
if [ -z "$BIN" ]; then echo "feov-record binary not found on this host"; exit 1; fi

SCRATCH=$(mktemp -d)
trap 'rm -rf "$SCRATCH"' EXIT
tar -xzf "$ARCHIVE" -C "$SCRATCH"

echo "archive: run-archive/2026-08-22_sqlite-schema-source.tar.gz (a different, already-finished run)"
echo "shards extracted: $(ls "$SCRATCH"/records/*.jsonl | wc -l | tr -d ' ')"
if OUT=$("$BIN" --seat-id blue-synthesize --run "$SCRATCH" show board 2>&1); then RC=0; else RC=$?; fi
echo "tool exit code reading the foreign run: $RC"
echo "tool-level refusal object in the output: $(printf '%s' "$OUT" | grep -c '"ok":false' || true)"
echo "gap ids rendered from the foreign run: $(printf '%s' "$OUT" | grep -o '"id": *"R[0-9]*-[0-9]*"' | sort -u | wc -l | tr -d ' ')"
