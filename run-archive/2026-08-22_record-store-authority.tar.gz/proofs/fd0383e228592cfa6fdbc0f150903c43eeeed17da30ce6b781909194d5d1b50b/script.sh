#!/bin/sh
# P2 — does anything in the repository READ an archived run back?
# Census at the pinned commit: every site that can open a .tar.gz, and every mention of the
# archive path, across the whole tree.
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
cd "$REPO"

echo "pin=$PIN"
echo "--- files containing tar.NewReader or gzip.NewReader (whole tree, *.go) ---"
git grep -l 'tar\.NewReader\|gzip\.NewReader' $PIN -- '*.go' | sed 's/^/  /' || echo "  (none)"
echo "--- files mentioning the literal string run-archive (whole tree, any type) ---"
git grep -l 'run-archive' $PIN | sed 's/^/  /' || echo "  (none)"
echo "--- run-archive mentions under scripts/ and plugins/sleeper-service/ ---"
echo "  scripts/: $(git grep -l 'run-archive' $PIN -- 'scripts/*' | wc -l | tr -d ' ')"
echo "  plugins/sleeper-service/: $(git grep -l 'run-archive' $PIN -- 'plugins/sleeper-service/*' | wc -l | tr -d ' ')"
echo "--- the one cross-run READER that does exist: law/ mirrored into every run's inputs ---"
git grep -n 'func MirrorLaw' $PIN -- '*.go' | sed 's/^/  /'
git grep -n 'MirrorLaw(' $PIN -- '*.go' | grep -v 'func MirrorLaw' | sed 's/^/  /'
