#!/bin/sh
# P5 — the record IS read back authoritatively, once, in-process, by the same run's capture step.
# Shows the harvest reading the replayed board (not the harness journal), where it is called from,
# and the doctrine claim about the archive that the P2 census contradicts.
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
CAP=plugins/frank-exchange-of-views/tools/internal/capture/capture.go
cd "$REPO"

echo "pin=$PIN"
echo "--- the harvest: signature, call site, and the board argument it reads ---"
git grep -n 'func HarvestPrecedents\|HarvestPrecedents(runDir\|func rulingsFromRecord' $PIN -- "$CAP" | sed 's/^/  /'
echo "--- rulingsFromRecord reads board.Events, and says why not the journal ---"
git show $PIN:$CAP | sed -n '/^\/\/ rulingsFromRecord/,/^func rulingsFromRecord/p' | sed 's/^/  /'
echo "--- ArchiveRecord: the writer ---"
git grep -n 'func ArchiveRecord' $PIN -- "$CAP" | sed 's/^/  /'
echo "--- CLAUDE.md's claim about the archive ---"
git show $PIN:CLAUDE.md | grep -n 'every audit re-reads it' | cut -c1-120 | sed 's/^/  /'
