#!/bin/sh
# P1 — is the schema discriminator declared, and does anything the shipped binary runs emit or read it?
# Everything is read out of the PINNED commit (inputs/PINNED.md: cd1fc73) with `git show`/`git grep`,
# so the answer does not depend on the working tree.
#
# The two categories are kept apart on purpose: a Go IMPORT of the recordpb package is a code path;
# a file that merely contains the package's PATH as a string (the generator) is not.
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
REC=plugins/frank-exchange-of-views/tools/internal/record
PKG='"github.com/ctoforaday/special-circumstances/plugins/frank-exchange-of-views/tools/internal/record/recordpb"'
cd "$REPO"

echo "pin=$PIN"
echo "record.go SchemaVersion-or-schema_version occurrences: $(git show $PIN:$REC/record.go | grep -c 'SchemaVersion\|schema_version' || true)"
echo "record.proto schema_version field declaration:"
git show $PIN:$REC/recordpb/record.proto | grep -n '  optional SchemaVersion schema_version' | sed 's/^/  /'
echo "live Event struct json tags (record.go), in order:"
git show $PIN:$REC/record.go | sed -n '/^type Event struct/,/^}/p' | grep -o 'json:"[^"]*"' | sed 's/^/  /'
echo "--- files that IMPORT the recordpb package, at the pin ---"
git grep -l "$PKG" $PIN -- '*.go' | sed 's/^/  /' || echo "  (none)"
echo "--- files that merely contain the package PATH as a string, outside recordpb/ ---"
git grep -l 'internal/record/recordpb' $PIN -- '*.go' | grep -v "$REC/recordpb/" | sed 's/^/  /' || echo "  (none)"
echo "callers of recordpb.ClassifyLine outside recordpb, at the pin: $(git grep -l 'ClassifyLine' $PIN -- '*.go' | grep -v "$REC/recordpb/" | wc -l | tr -d ' ')"
