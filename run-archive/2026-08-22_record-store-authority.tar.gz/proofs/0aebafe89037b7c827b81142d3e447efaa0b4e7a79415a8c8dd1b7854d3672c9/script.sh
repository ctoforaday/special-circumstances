#!/bin/sh
# P10 — the migration's own account of itself: what the plan says is BUILT, what its sequence
# table says is not started, and what the storage plan says about versioning.
set -eu
cd /home/user/special-circumstances
PIN=cd1fc73
P=plans/record-protobuf.md

echo "pin=$PIN"
echo "--- the section header that reads present-tense ---"
git grep -n '^## II.5\|Reading: BUILT' $PIN -- $P | cut -c1-200 | sed 's/^/  /'
echo "--- the sequence table's status for the write path ---"
git grep -n 'READ RULE DONE' $PIN -- $P | cut -c1-240 | sed 's/^/  /'
echo "--- the deliberate hard break, in the plan's own words ---"
git grep -n 'stop being readable at all' $PIN -- $P | cut -c1-240 | sed 's/^/  /'
echo "--- the storage plan on versioning/upcasters ---"
git grep -n 'upcasters on read' $PIN -- plans/storage.md | cut -c1-260 | sed 's/^/  /'
