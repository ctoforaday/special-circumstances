#!/bin/sh
# P8 — the project's own dated incident record for this exact failure class, quoted from the
# commits and the plan rather than paraphrased.
set -eu
cd /home/user/special-circumstances

echo "--- c732b2a: why the archive exists at all, and why it is not read back ---"
git log -1 --format='%h %ad %s' --date=short c732b2a
git log -1 --format='%b' c732b2a | grep -n 'container-reclaim\|never run-archive/\|ffc4bf4 deleted' | cut -c1-200 | sed 's/^/  /'
echo "--- daa5660: a write/read root mismatch (#299) and a flag-guess refusal (#371) ---"
git log -1 --format='%h %ad %s' --date=short daa5660
git log -1 --format='%b' daa5660 | grep -n '#299 defect\|#371' | cut -c1-200 | sed 's/^/  /'
echo "--- the fuzz result the schema read-rule build reported ---"
git grep -n '16 of 227' cd1fc73 -- plans/record-protobuf.md | cut -c1-260 | sed 's/^/  /'
