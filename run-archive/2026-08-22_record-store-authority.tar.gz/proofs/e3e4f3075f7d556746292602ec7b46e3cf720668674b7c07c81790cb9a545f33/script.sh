#!/bin/sh
# Did the evidence base move under the report? Compare inputs/PINNED.md's launch HEAD
# against the working tree, and show which files changed in between.
set -e
REPO=/home/user/special-circumstances
RUN=$REPO/research/2026-08-22_record-store-authority
cd "$REPO"

PIN=$(grep -o '`[0-9a-f]\{7\}`' "$RUN/inputs/PINNED.md" | head -1 | tr -d '`')
NOW=$(git rev-parse --short HEAD)
echo "PINNED launch HEAD=$PIN"
echo "working tree HEAD=$NOW"
echo -n "commits from pin to HEAD: "; git rev-list --count "$PIN".."$NOW"
echo "commits in between:"; git log --format='  %h %s' "$PIN".."$NOW"
echo "files changed in between:"; git diff --name-only "$PIN".."$NOW" | sed 's/^/  /'
echo -n "PINNED-cited paths changed in between: "
git diff --name-only "$PIN".."$NOW" -- \
  plugins/frank-exchange-of-views/tools/internal/record/recordpb/record.proto \
  plugins/frank-exchange-of-views/tools/internal/capture/capture.go \
  CLAUDE.md | wc -l | tr -d ' '
echo -n "replay.go changed in between: "
if git diff --name-only "$PIN".."$NOW" | grep -q 'internal/record/replay.go'; then echo yes; else echo no; fi
echo -n "ReadShard still drops an unparseable line with a bare continue at HEAD: "
if sed -n '/^func ReadShard(/,/^}/p' plugins/frank-exchange-of-views/tools/internal/record/replay.go \
   | grep -A1 'json.Unmarshal' | grep -q 'continue'; then echo yes; else echo no; fi
echo -n "ReadShard records an anomaly on parse failure: "
if sed -n '/^func ReadShard(/,/^}/p' plugins/frank-exchange-of-views/tools/internal/record/replay.go \
   | grep -qi 'anomal'; then echo yes; else echo no; fi
