#!/bin/sh
# P17 — companion for R2-1 (successor to R1-1). p11-truncation-zero.sh's second section prints
# nothing on every run, for two independent reasons: it `cd`s into the tools/ directory and then
# passes a pathspec relative to the repo root (`-- plans/record-protobuf.md`), which resolves
# against a tools/plans/ that does not exist; and even from the right directory its pattern
# ('now zero by rule rather than by luck') would not match, because the plan's text carries
# markdown emphasis ('now zero **by rule** rather than by luck'). This script runs from the repo
# root with the correct pattern, and follows p16's convention of a loud, explicit miss so a
# future drift in the plan's wording is visible rather than silent. p11 is left byte-for-byte
# untouched, per F8's disclosure discipline: editing a proof in place breaks the byte-for-byte
# binding of its already-recorded anchor, turning a true claim into a permanent non-reproduction.
set -eu
REPO=/home/user/special-circumstances
cd "$REPO"

echo "--- re-running the fuzz test p11 anchors, from the repo root ---"
(cd plugins/frank-exchange-of-views/tools && go test ./internal/record/recordpb/ -run TestTruncationAtEveryOffsetNeverYieldsAFalseEvent -v)

echo "--- the plan's own resolution line, at the pinned commit, matched against its actual text ---"
git grep -n -- 'now zero \*\*by rule\*\* rather than by luck' cd1fc73 -- plans/record-protobuf.md \
  | cut -c1-260 | sed 's/^/  /' \
  || echo "  (no matches — the plan's wording has moved; the fuzz result above stands on its own)"
