#!/bin/sh
# Can the LIVE binary read a DIFFERENT, finished run's archived shards?
# Extract a git-tracked archive from another run and point `show board` at it.
# Deterministic output: counts and flags only, no paths or timestamps.
set -e
REPO=/home/user/special-circumstances
BIN=/tmp/claude-0/-home-user-special-circumstances/8a8082a8-caa2-5e49-b514-88dcf45e90f1/scratchpad/runbin/feov-record
ARCHIVE=$REPO/run-archive/2026-08-22_sqlite-schema-source.tar.gz
WORK=/tmp/feov-crossrun-proof

echo "HEAD=$(cd $REPO && git rev-parse --short HEAD)"
echo -n "archive is git-tracked: "; (cd "$REPO" && git ls-files --error-unmatch run-archive/2026-08-22_sqlite-schema-source.tar.gz >/dev/null 2>&1 && echo yes || echo no)

rm -rf "$WORK"; mkdir -p "$WORK"
tar -xzf "$ARCHIVE" -C "$WORK"
echo -n "entries under the extracted records/: "; ls "$WORK/records" | wc -l | tr -d ' '
echo -n "  of which .jsonl shards: "; ls "$WORK/records" | grep -c '\.jsonl$'

OUT=$WORK/board.txt
set +e
"$BIN" --seat-id blue-synthesize --run "$WORK" show board --format markdown > "$OUT" 2>&1
RC=$?
set -e
echo "show board exit code: $RC"
echo -n "closure-index rows rendered from the foreign run: "; grep -c '^R[0-9]*-[0-9]* | ' "$OUT"
echo -n "render-anomaly lines: "; grep -c 'DISCARDED' "$OUT"
echo -n "board header present: "; grep -q '^# The board' "$OUT" && echo yes || echo no
echo -n "any refusal naming schema/version/run-identity: "
if grep -qi 'schema version\|refused\|does not match this run' "$OUT"; then echo yes; else echo no; fi
rm -rf "$WORK"
