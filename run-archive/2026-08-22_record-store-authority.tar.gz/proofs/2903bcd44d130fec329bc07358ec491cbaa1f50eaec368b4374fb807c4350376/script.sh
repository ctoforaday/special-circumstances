#!/bin/sh
# Does the LIVE write path carry a schema discriminator, and does anything import the
# package that defines one? Deterministic: prints counts and the field list, no timestamps.
set -e
REPO=/home/user/special-circumstances
REC=$REPO/plugins/frank-exchange-of-views/tools/internal/record

echo "HEAD=$(cd $REPO && git rev-parse --short HEAD)"

echo -n "Event struct fields: "
sed -n '/^type Event struct {/,/^}/p' "$REC/record.go" \
  | grep -E '^	[A-Z][A-Za-z]*[ 	]+[a-zA-Z*\[]' | awk '{print $1}' | tr '\n' ' '
echo
echo -n "Event struct field COUNT: "
sed -n '/^type Event struct {/,/^}/p' "$REC/record.go" \
  | grep -cE '^	[A-Z][A-Za-z]*[ 	]+[a-zA-Z*\[]'

echo -n "SchemaVersion|schema_version hits in record.go+replay.go: "
grep -c "SchemaVersion\|schema_version" "$REC/record.go" "$REC/replay.go" 2>/dev/null | awk -F: '{s+=$2} END {print s+0}'

cd "$REPO"
echo -n "Go files outside recordpb/ in the TRACKED tree with an IMPORT line for the package: "
git ls-files '*.go' | grep -v '/recordpb/' | xargs grep -l '^	"github.com/ctoforaday/special-circumstances/plugins/frank-exchange-of-views/tools/internal/record/recordpb"' 2>/dev/null | wc -l | tr -d ' '

echo -n "same, over the WHOLE working tree including ignored dirs: "
grep -rl '"github.com/ctoforaday/special-circumstances/plugins/frank-exchange-of-views/tools/internal/record/recordpb"' --include='*.go' "$REPO" 2>/dev/null | grep -v '/recordpb/' | sed "s|$REPO/||" | sort | tr '\n' ' '
echo

echo -n "scripts/protogen references recordpb as (import|path-string): "
if grep -q '"github.com/ctoforaday/special-circumstances/.*recordpb"' "$REPO/scripts/protogen/main.go" 2>/dev/null; then echo "import"; else echo "path-string-only"; fi

echo -n "plan status line: "
grep -o 'PR2 — the write path\. READ RULE DONE; the bulk edit NOT started\.' "$REPO/plans/record-protobuf.md" | head -1
