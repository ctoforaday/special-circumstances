#!/bin/sh
# P13 — companion fix for the same class (R1-3): p4-silent-drop.sh prints a live `git rev-parse
# HEAD` into its output, so the tool's byte-for-byte `reproduce` check flags it as non-reproducing
# every time the repo advances even though the substantive comparison (ReadShard's sha1 at two
# FIXED commits) has not changed. This script drops the live reference from the comparison
# entirely: it compares the pin against 106f412f, the lanes'-tree commit F6/F8 actually name.
set -eu
REPO=/home/user/special-circumstances
PIN=cd1fc73
LANES_TREE=106f412f
REC=plugins/frank-exchange-of-views/tools/internal/record
cd "$REPO"

extract() { sed -n '/^func ReadShard(/,/^}/p'; }

echo "pin=$PIN  lanes-tree=$LANES_TREE (both frozen)"
A=$(git show $PIN:$REC/replay.go | extract | shasum | cut -d' ' -f1)
B=$(git show $LANES_TREE:$REC/replay.go | extract | shasum | cut -d' ' -f1)
echo "ReadShard sha1 at pin        : $A"
echo "ReadShard sha1 at lanes-tree : $B"
[ "$A" = "$B" ] && echo "IDENTICAL at pin and lanes'-tree" || echo "DIFFERENT at pin and lanes'-tree"
