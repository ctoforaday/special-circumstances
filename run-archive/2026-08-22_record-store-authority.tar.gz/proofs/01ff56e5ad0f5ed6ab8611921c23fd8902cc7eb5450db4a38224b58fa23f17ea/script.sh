#!/bin/sh
# P14 — R1-4: F4's "49 KB gzipped for a fifteen-seat run" and "7.3 MB fetched-source cache"
# carried no proof anchor. This script quotes the figures from their primary source (the commit
# that created the archive) and checks the first against the actual committed tarball's size.
set -eu
REPO=/home/user/special-circumstances
cd "$REPO"

echo "--- the commit's own stated figures ---"
git log -1 --format='%B' c732b2a | grep -n '49 KB gzipped\|7.3 MB' | sed 's/^/  /'
echo "--- the actual committed run-2 tarball size ---"
ls -la run-archive/2026-08-22_is-7-prime-run2.tar.gz | awk '{print "  " $5 " bytes ("  $5/1024 " KB)"}'
