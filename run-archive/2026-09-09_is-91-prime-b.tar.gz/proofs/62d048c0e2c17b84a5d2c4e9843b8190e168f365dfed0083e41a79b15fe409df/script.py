#!/usr/bin/env python3
"""Reconciles the report's Analysis > Direct computation claim ("three separately
authored programs ... All five independent implementations agree") against this run's
own apparatus, in response to G1 (Q8's local-repo critical-stance finding that this
report's apparatus counts should be checked against the apparatus-count-cadence /
cadence-exemption-ends-at-generation precedents in law/precedents.md).

Before this sitting, only ONE of the three programs the claim describes was part of
this run's own tracked apparatus (blue/candidates/lane-3-checks.py); lane-1's script
lived only in ephemeral, gitignored-equivalent home-directory scratch (copied in here
as lane-1-trial-division.py), and lane-2's check was never saved to a file at all --
blue/candidates/lane-2.md line 13 documents it only as an inline
`python3 -c "print(91%7==0, 91//7, [13%d for d in (2,3)])"` command, so no directory
walk of any kind could ever have discovered it. This script re-derives that leg
verbatim, giving it a durable, walkable home for the first time, and then walks and
re-runs everything else needed to regenerate the report's count rather than trusting
the hand-typed number.
"""
import subprocess
import sys
import pathlib

CANDIDATES = pathlib.Path(__file__).resolve().parent

results = []


def run_py(path):
    return subprocess.run(
        [sys.executable, str(path)], capture_output=True, text=True, check=True
    ).stdout


# Leg 1: lane-1's script -- previously scratch-only, now committed to this run's own
# tracked apparatus alongside this reconciliation script.
out1 = run_py(CANDIDATES / "lane-1-trial-division.py")
composite1 = "DISCONFIRMED: divisor found: [7]" in out1
evidence1 = next(line for line in out1.splitlines() if "divides 91 exactly" in line)
results.append(("lane-1-trial-division.py (was scratch-only; now committed)", composite1, evidence1))

# Leg 2: lane-2's check was never a file -- re-derived verbatim from lane-2.md's own
# transcript of the inline command it ran.
d7 = (91 % 7 == 0)
cofactor = 91 // 7
cof_divs = [13 % d for d in (2, 3)]
composite2 = d7 and cofactor == 13 and all(x != 0 for x in cof_divs)
results.append(("lane-2 inline check (re-derived; was never a file)", composite2,
                 f"91%7==0: {d7}, 91//7: {cofactor}, [13%2,13%3]: {cof_divs}"))

# Leg 3: lane-3's script -- already committed before this sitting.
out3 = run_py(CANDIDATES / "lane-3-checks.py")
first_line = out3.splitlines()[0]
composite3 = "[7]" in first_line
results.append(("lane-3-checks.py (already committed)", composite3, first_line))

# Legs 4-5: the two external system tools the report cites.
factor_out = subprocess.run(
    ["factor", "91"], capture_output=True, text=True, check=True
).stdout.strip()
composite4 = factor_out == "91: 7 13"
results.append(("coreutils factor", composite4, factor_out))

ossl_out = subprocess.run(
    ["openssl", "prime", "91"], capture_output=True, text=True, check=True
).stdout.strip()
composite5 = "is not prime" in ossl_out
results.append(("openssl prime", composite5, ossl_out))

agree = sum(1 for _, ok, _ in results if ok)
for name, ok, evidence in results:
    print(f"{'AGREE   ' if ok else 'DISAGREE'}: {name} -- {evidence}")
print(f"\n{agree}/{len(results)} independent implementations agree n=91 is composite (7 x 13)")

sys.exit(0 if agree == len(results) else 1)
