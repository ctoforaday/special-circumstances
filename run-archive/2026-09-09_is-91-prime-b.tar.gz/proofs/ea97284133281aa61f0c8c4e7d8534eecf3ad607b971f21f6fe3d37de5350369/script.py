#!/usr/bin/env python3
"""Self-contained re-derivation of the report's Analysis > Direct computation claim
("three separately authored programs ... All five independent implementations
agree"), written so it can be re-run from a cached proof-store copy with no
dependency on sibling files at any particular path (an earlier version of this
script shelled out to blue/candidates/lane-1-trial-division.py and
blue/candidates/lane-3-checks.py by relative path and was NOT reproducible once
the proof tool re-ran the cached copy from its own store, where those siblings do
not exist -- this version inlines the same three computations instead).

Program A reproduces lane-1's trial-division script logic. Program B reproduces
lane-2's check, which was originally run once as an inline
`python3 -c "print(91%7==0, 91//7, [13%d for d in (2,3)])"` command and never saved
to a file at all (blue/candidates/lane-2.md line 13) -- inlined here verbatim.
Program C reproduces lane-3-checks.py's trial-division portion. Legs D and E shell
out to the two external system tools the report cites.
"""
import math
import subprocess
import sys

results = []

# Program A: lane-1's trial-division script, reproduced.
divisors_a = [d for d in range(2, math.isqrt(91) + 1) if 91 % d == 0]
composite_a = divisors_a == [7]
results.append(("Program A (lane-1 trial division, reproduced)", composite_a,
                 f"divisors found in 2..9: {divisors_a}"))

# Program B: lane-2's inline check, verbatim -- this is the leg that was never a
# file until this script existed.
d7 = (91 % 7 == 0)
cofactor = 91 // 7
cof_divs = [13 % d for d in (2, 3)]
composite_b = d7 and cofactor == 13 and all(x != 0 for x in cof_divs)
results.append(("Program B (lane-2 inline check, reproduced)", composite_b,
                 f"91%7==0: {d7}, 91//7: {cofactor}, [13%2,13%3]: {cof_divs}"))

# Program C: lane-3-checks.py's trial-division portion, reproduced.
divisors_c = [d for d in range(2, int(91 ** 0.5) + 1) if 91 % d == 0]
composite_c = divisors_c == [7]
results.append(("Program C (lane-3 trial division, reproduced)", composite_c,
                 f"divisors found in 2..9: {divisors_c}"))

# Leg D: coreutils factor.
factor_out = subprocess.run(
    ["factor", "91"], capture_output=True, text=True, check=True
).stdout.strip()
composite_d = factor_out == "91: 7 13"
results.append(("coreutils factor", composite_d, factor_out))

# Leg E: OpenSSL's Miller-Rabin-based primality check.
ossl_out = subprocess.run(
    ["openssl", "prime", "91"], capture_output=True, text=True, check=True
).stdout.strip()
composite_e = "is not prime" in ossl_out
results.append(("openssl prime", composite_e, ossl_out))

agree = sum(1 for _, ok, _ in results if ok)
for name, ok, evidence in results:
    print(f"{'AGREE   ' if ok else 'DISAGREE'}: {name} -- {evidence}")
print(f"\n{agree}/{len(results)} independent implementations agree n=91 is composite (7 x 13)")

sys.exit(0 if agree == len(results) else 1)
