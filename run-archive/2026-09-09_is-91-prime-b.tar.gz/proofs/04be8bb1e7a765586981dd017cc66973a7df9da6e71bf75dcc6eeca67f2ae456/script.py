#!/usr/bin/env python3
"""Settles G2 (evidence-F1/logic-F5): the Open Questions sentence "confirms 5/5
agree 91 is composite by execution rather than assertion" cited two proof anchors,
p-efb28de8 and p-808ae840, as if interchangeable. This computes which of the two
actually reproduces from its own cached proof-store copy, rather than asserting it.

Each proof's script is looked up in the run's proofs/ store by the sha256 the
record already assigned it (recorded on `show evidence`), and run exactly as the
prove tool re-runs it: from its own cached location, with no access to files
outside that directory.
"""
import pathlib
import subprocess
import sys

RUN_DIR = pathlib.Path(__file__).resolve().parents[2]
PROOFS = RUN_DIR / "proofs"

CASES = [
    ("p-808ae840", "62d048c0e2c17b84a5d2c4e9843b8190e168f365dfed0083e41a79b15fe409df", False),
    ("p-efb28de8", "ea97284133281aa61f0c8c4e7d8534eecf3ad607b971f21f6fe3d37de5350369", True),
]

all_as_expected = True
for anchor, sha, expect_reproduces in CASES:
    script = PROOFS / sha / "script.py"
    proc = subprocess.run([sys.executable, str(script)], capture_output=True, text=True)
    reproduces = proc.returncode == 0 and "5/5 independent implementations agree" in proc.stdout
    as_expected = reproduces == expect_reproduces
    all_as_expected = all_as_expected and as_expected
    print(f"{anchor} (sha {sha[:12]}...): exit={proc.returncode}, "
          f"reproduces={reproduces}, expected_to_reproduce={expect_reproduces}, "
          f"{'MATCHES DIAGNOSIS' if as_expected else 'CONTRADICTS DIAGNOSIS'}")
    if not reproduces:
        last_line = (proc.stderr.strip().splitlines() or ["(no stderr)"])[-1]
        print(f"  failure detail: {last_line}")

print()
print("Diagnosis confirmed by execution:" if all_as_expected else "Diagnosis NOT confirmed:",
      "p-808ae840 does not reproduce from the proof store (sibling-path dependency); "
      "p-efb28de8 does (self-contained).")

sys.exit(0 if all_as_expected else 1)
