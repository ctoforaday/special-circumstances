#!/usr/bin/env python3
"""Blue-synthesize consolidated verification for 'Is 91 a prime number?'.
Independent of lane-1/lane-2/lane-3 scripts; written fresh at synthesis to
settle the specific claims the report makes. Deterministic."""

from math import gcd

n = 91

# --- factorization / trial division ---
divisors = [d for d in range(2, int(n ** 0.5) + 1) if n % d == 0]
print("trial division 2..9:", divisors)
print("91 // 7 =", 91 // 7, "remainder", 91 % 7)
print("13 divisors 2..3:", [d for d in (2, 3) if 13 % d == 0])

# --- Fermat base 3 ---
print("3^90 mod 91 =", pow(3, 90, 91))


def order(a, m):
    x = a % m
    k = 1
    while x != 1:
        x = (x * a) % m
        k += 1
    return k


print("ord_7(3) =", order(3, 7), " ord_13(3) =", order(3, 13))
print("lcm check: lcm(6,3)=6 divides 90:", 90 % 6 == 0)
print("lcm(6,12)=12 divides 90 (also true, but 12 is not the real order):", 90 % 12 == 0)


# --- Miller-Rabin combined-base ---
def is_prime_miller_rabin(n, bases):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in bases:
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


print("Miller-Rabin(91, bases=[2,3,5,7]) ->", is_prime_miller_rabin(91, [2, 3, 5, 7]))

for a in range(2, 11):
    d = 90
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    seq = [x]
    witness = not (x == 1 or x == n - 1)
    if witness:
        for _ in range(r - 1):
            x = pow(x, 2, n)
            seq.append(x)
            if x == n - 1:
                witness = False
                break
    print(f"MR base {a}: seq={seq} witness={witness}")

# --- composite-number index (matches OEIS A002808 claim) ---
primes = [p for p in range(2, n + 1) if all(p % d for d in range(2, int(p ** 0.5) + 1))]
composites_upto_n = [x for x in range(4, n + 1) if x not in primes]
print("91 is the", len(composites_upto_n), "th composite number (index of 91):",
      composites_upto_n.index(91) + 1)
print("7 is prime index", [p for p in primes].index(7) + 1,
      "; 13 is prime index", [p for p in primes].index(13) + 1)

# --- pseudoprime-to-base count (Prime Curios "35 bases" claim) ---
count_incl_n_minus_1 = sum(1 for a in range(2, n) if gcd(a, n) == 1 and pow(a, n - 1, n) == 1)
count_excl_n_minus_1 = sum(1 for a in range(2, n - 1) if gcd(a, n) == 1 and pow(a, n - 1, n) == 1)
print("pseudoprime-base count, a in 2..90 inclusive:", count_incl_n_minus_1)
print("pseudoprime-base count, a in 2..89 (excl n-1):", count_excl_n_minus_1)
