# Settles the count of bases for 91 used in the Fermat section and reconciles it with OEIS A175101.
from math import gcd
n = 91
def prime_factors_with_multiplicity(m):
    fs, d = [], 2
    while d * d <= m:
        while m % d == 0:
            fs.append(d); m //= d
        d += 1
    if m > 1:
        fs.append(m)
    return fs
def is_odd_squarefree_semiprime(m):
    fs = prime_factors_with_multiplicity(m)
    return m % 2 == 1 and len(fs) == 2 and fs[0] != fs[1]
seq = [m for m in range(3, 400) if is_odd_squarefree_semiprime(m)]
print("A046388 first 14 terms:", seq[:14])
print("14th term (A046388(14)):", seq[13], " is 91:", seq[13] == 91)
coprime_2_89 = [b for b in range(2, 90) if gcd(b, n) == 1]
pass_2_89 = [b for b in coprime_2_89 if pow(b, n - 1, n) == 1]
print("coprime bases in 2..89:", len(coprime_2_89), " passing in 2..89:", len(pass_2_89))
print("passing in 2..90 (census):", len([b for b in range(2, 91) if gcd(b, n) == 1 and pow(b, n - 1, n) == 1]))
print("A063994-style count, bases 1..90 incl. 1 and 90:", len([b for b in range(1, n) if pow(b, n - 1, n) == 1]))
