import math

n = 91
root = math.isqrt(n)
trial = list(range(2, root + 1))
found = [d for d in trial if n % d == 0]
print("floor sqrt 91 =", root)
print("trial divisors 2..9 that divide 91:", found, "first:", found[0], "cofactor:", n // found[0])
print("7 * 13 == 91:", 7 * 13 == 91)

print("2^90 mod 91 =", pow(2, 90, 91))
print("base-2 test rejects 91:", pow(2, 90, 91) != 1)
print("3^90 mod 91 =", pow(3, 90, 91))
print("base-3 test accepts 91:", pow(3, 90, 91) == 1)

coprime = [b for b in range(2, 91) if math.gcd(b, 91) == 1]
liars = [b for b in coprime if pow(b, 90, 91) == 1]
print("coprime bases 2..90:", len(coprime))
print("Fermat liars:", len(liars), liars)
print("Fermat rejecting bases:", len(coprime) - len(liars))

# Passing bases listed on the ProofWiki page "91 is Pseudoprime to 35 Bases less than 91"
proofwiki = [3, 4, 9, 10, 12, 16, 17, 22, 23, 25, 27, 29, 30, 36, 38, 40, 43, 48, 51, 53,
             55, 61, 62, 64, 66, 68, 69, 74, 75, 79, 81, 82, 87, 88, 90]
print("ProofWiki list size:", len(proofwiki))
print("computed liars equal ProofWiki list:", liars == proofwiki)

print("7 as a sum of two squares:", [(a, b) for a in range(-2, 3) for b in range(-2, 3) if a * a + b * b == 7])
prod = 7 * (3 + 2j) * (3 - 2j)
print("7 * (3+2i) * (3-2i) =", prod, "equals 91:", prod == 91)
print("(3+2i) * (3-2i) =", (3 + 2j) * (3 - 2j), "equals 13:", (3 + 2j) * (3 - 2j) == 13)

N = 100
sieve = [True] * (N + 1)
sieve[0] = sieve[1] = False
for i in range(2, math.isqrt(N) + 1):
    if sieve[i]:
        for j in range(i * i, N + 1, i):
            sieve[j] = False
primes = [i for i in range(N + 1) if sieve[i]]
print("primes up to 100:", len(primes), primes)
print("91 among primes up to 100:", 91 in primes)
