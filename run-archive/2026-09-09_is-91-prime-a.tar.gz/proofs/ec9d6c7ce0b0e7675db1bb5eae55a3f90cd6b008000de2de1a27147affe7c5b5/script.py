#!/usr/bin/env python3
"""Settle Q1-Q3 by direct computation: trial division and full factorization of 91."""
import math

n = 91
limit = math.isqrt(n)
divisors = [d for d in range(2, limit + 1) if n % d == 0]

print(f"n = {n}, floor(sqrt(n)) = {limit}")
print(f"trial divisors tested: 2..{limit}")
print(f"divisors found: {divisors}")
print(f"Q1 verdict: {'PRIME (no divisor found)' if not divisors else 'COMPOSITE (divisor found: ' + str(divisors) + ')'}")

# Q2/Q3: full factorization, not stopping at first factor
def factorize(x):
    factors = []
    d = 2
    while d * d <= x:
        while x % d == 0:
            factors.append(d)
            x //= d
        d += 1
    if x > 1:
        factors.append(x)
    return factors

factors = factorize(n)
print(f"full prime factorization of {n}: {factors}")
assert factors == [7, 13], f"expected [7, 13], got {factors}"

# confirm each factor is itself prime (trial division to its own sqrt)
def is_prime(x):
    if x < 2:
        return False
    for d in range(2, math.isqrt(x) + 1):
        if x % d == 0:
            return False
    return True

for f in factors:
    print(f"is_prime({f}) = {is_prime(f)}")
    assert is_prime(f), f"{f} is not prime, factorization incomplete"

print("Q3 verdict: exactly two prime factors (semiprime), no third factor hiding in either cofactor")
print("FINAL: 91 is COMPOSITE = 7 x 13, both prime; the naive trial-division-to-9 check that stops at 9 without testing 7 would have missed nothing here since 7 <= 9 -- the divisor is within range")
