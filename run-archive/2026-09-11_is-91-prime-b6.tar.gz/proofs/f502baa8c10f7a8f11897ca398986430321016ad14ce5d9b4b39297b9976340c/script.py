import math

n = 91
coprime_bases = [a for a in range(2, n) if math.gcd(a, n) == 1]
passing = [a for a in coprime_bases if pow(a, n - 1, n) == 1]

print(f"coprime_count={len(coprime_bases)}")
print(f"passes={len(passing)}")
