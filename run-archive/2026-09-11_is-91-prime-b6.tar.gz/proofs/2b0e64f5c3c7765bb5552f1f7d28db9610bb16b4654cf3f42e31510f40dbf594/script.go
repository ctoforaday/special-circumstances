package main

import (
	"fmt"
	"math/big"
)

func main() {
	n91 := big.NewInt(91)
	n97 := big.NewInt(97)
	fmt.Println("ProbablyPrime(91) =", n91.ProbablyPrime(20))
	fmt.Println("ProbablyPrime(97) =", n97.ProbablyPrime(20))

	mod := big.NewInt(91)
	exp := big.NewInt(90)
	for _, b := range []int64{2, 3, 5} {
		base := big.NewInt(b)
		result := new(big.Int).Exp(base, exp, mod)
		fmt.Printf("go_exp_base_%d: %d^90 mod 91 = %s\n", b, b, result.String())
	}
}
