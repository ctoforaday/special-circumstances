#!/usr/bin/env python3
import math

n = 91

bound = math.isqrt(n)
primes_le_bound = [p for p in range(2, bound + 1) if all(p % d for d in range(2, int(math.isqrt(p)) + 1))]
divisor = None
for p in primes_le_bound:
    if n % p == 0:
        divisor = p
        break
print(f"trial_division: bound=isqrt({n})={bound}, primes_tested={primes_le_bound}, divisor={divisor}, cofactor={n // divisor if divisor else None}")

a = math.isqrt(n - 1) + 1
found = None
while a <= (n + 1) // 2:
    b2 = a * a - n
    b = math.isqrt(b2)
    if b * b == b2 and a - b > 1:
        found = (a, b)
        break
    a += 1
print(f"difference_of_squares: a={found[0]}, b={found[1]}, factors=({found[0]-found[1]}, {found[0]+found[1]})")

for base in (2, 3, 5):
    print(f"fermat_base_{base}: {base}^{n-1} mod {n} = {pow(base, n-1, n)}")

fact = 1
for k in range(1, n):
    fact = (fact * k) % n
print(f"wilson: {n-1}! mod {n} = {fact}")

print("VERDICT: composite" if divisor else "VERDICT: prime")
