#!/usr/bin/env python3
"""
Verification proof: 7 is prime via trial division.

A number n is prime iff:
1. n > 1
2. n has no divisors d where 1 < d < n
Equivalently: n has no divisors 2 <= d <= sqrt(n)

For n=7: sqrt(7) ≈ 2.646
So we test divisibility by 2 and check if any remain.
"""

import math

def is_prime_trial_division(n):
    """Check if n is prime using trial division."""
    if n <= 1:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    
    # Test odd divisors up to sqrt(n)
    for d in range(3, int(math.sqrt(n)) + 1, 2):
        if n % d == 0:
            return False
    return True

# Test 7
n = 7
result = is_prime_trial_division(n)
sqrt_n = math.sqrt(n)

print(f"Testing n = {n}")
print(f"sqrt({n}) ≈ {sqrt_n:.3f}")
print(f"\nDivisibility checks required: d in range [2, floor({sqrt_n:.3f})] = [2, 2]")
print(f"  7 % 2 = {7 % 2} → 7 is not divisible by 2")
print(f"\nNo divisors found between 2 and {int(sqrt_n)}")
print(f"7 > 1 and only divisors are {1, 7}")
print(f"\nConclusion: {n} is prime: {result}")

# Verify factors explicitly
factors = [i for i in range(1, n + 1) if n % i == 0]
print(f"Explicit factor list: {factors}")
print(f"Distinct positive divisors: {len(factors)}")
print(f"Is prime (exactly 2 distinct divisors {1, n}): {factors == [1, n]}")
