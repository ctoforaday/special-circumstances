#!/usr/bin/env python3
"""Lane-2 verification program for the quadratic-formula run.

Five independent checks, each printed with its own PASS/FAIL line so a reader can
re-run the file and disagree with any one of them:

  A. EXACT SYMBOLIC IDENTITY. Over the rational function field, with z constrained by
     z^2 = B^2/4 - C, the Loh factorisation (x-(-B/2+z))(x-(-B/2-z)) equals x^2+Bx+C
     identically. Done with exact Fraction arithmetic on a hand-rolled multivariate
     polynomial type, reducing modulo the relation. No computer-algebra system is used
     (none is installed in this container).

  B. STEP-FOR-STEP MAP. The substitution x = -B/2 + u carries the completing-the-square
     equation (x+B/2)^2 = B^2/4 - C to the Loh equation u^2 = B^2/4 - C, and back.
     Checked as an exact polynomial identity, both directions.

  C. CHARACTERISTIC-2 BOUNDARY. Both routes need 2 to be invertible. Enumerated over
     GF(2) and GF(4): for which (B,C) does an "average" m with m+m = -B exist?

  D. OPERATION COUNT under a stated convention (counted by instrumenting an arithmetic
     type, not by hand-tallying a written derivation).

  E. FLOATING-POINT ACCURACY SWEEP. Relative error of the SMALLER-magnitude root for
     three procedures against an exact rational reference, over a swept range of
     coefficient magnitudes.
"""

from fractions import Fraction as Fr
import itertools
import math

FAILURES = []


def check(name, ok, detail=""):
    print(("PASS  " if ok else "FAIL  ") + name + ("  " + detail if detail else ""))
    if not ok:
        FAILURES.append(name)


# ----------------------------------------------------------------------------
# Minimal exact multivariate polynomial over Q in the variables x, B, C, z.
# Monomials are (ex, eB, eC, ez) tuples -> Fraction coefficient.
# ----------------------------------------------------------------------------
VARS = ("x", "B", "C", "z", "u")


class P:
    __slots__ = ("t",)

    def __init__(self, terms=None):
        self.t = {}
        if terms:
            for m, c in terms.items():
                if c:
                    self.t[m] = Fr(c)

    @staticmethod
    def const(c):
        return P({(0, 0, 0, 0, 0): Fr(c)})

    @staticmethod
    def var(name):
        i = VARS.index(name)
        m = [0] * len(VARS)
        m[i] = 1
        return P({tuple(m): Fr(1)})

    def __add__(self, o):
        o = o if isinstance(o, P) else P.const(o)
        r = dict(self.t)
        for m, c in o.t.items():
            r[m] = r.get(m, Fr(0)) + c
            if r[m] == 0:
                del r[m]
        return P(r)

    def __neg__(self):
        return P({m: -c for m, c in self.t.items()})

    def __sub__(self, o):
        return self + (-(o if isinstance(o, P) else P.const(o)))

    def __mul__(self, o):
        o = o if isinstance(o, P) else P.const(o)
        r = {}
        for m1, c1 in self.t.items():
            for m2, c2 in o.t.items():
                m = tuple(a + b for a, b in zip(m1, m2))
                r[m] = r.get(m, Fr(0)) + c1 * c2
                if r[m] == 0:
                    del r[m]
        return P(r)

    __rmul__ = __mul__
    __radd__ = __add__

    def is_zero(self):
        return not self.t

    def __repr__(self):
        if not self.t:
            return "0"
        out = []
        for m, c in sorted(self.t.items()):
            s = str(c)
            for v, e in zip(VARS, m):
                if e:
                    s += "*" + v + ("^" + str(e) if e > 1 else "")
            out.append(s)
        return " + ".join(out)


def reduce_z2(p, relation_rhs):
    """Repeatedly rewrite z^2 -> relation_rhs (a P free of z) until z-degree < 2."""
    zi = VARS.index("z")
    while True:
        hi = [m for m in p.t if m[zi] >= 2]
        if not hi:
            return p
        m = hi[0]
        c = p.t[m]
        m2 = list(m)
        m2[zi] -= 2
        p = p - P({m: c}) + P({tuple(m2): c}) * relation_rhs


x = P.var("x")
B = P.var("B")
C = P.var("C")
z = P.var("z")
u = P.var("u")
half = P.const(Fr(1, 2))
quarter = P.const(Fr(1, 4))

# --- A: exact symbolic identity -------------------------------------------------
rel = quarter * B * B - C                      # z^2 = B^2/4 - C
R = -half * B + z
S = -half * B - z
lhs = (x - R) * (x - S)
lhs = reduce_z2(lhs, rel)
rhs = x * x + B * x + C
check("A. (x-R)(x-S) == x^2+Bx+C given z^2 = B^2/4 - C", (lhs - rhs).is_zero(),
      "residual: %r" % (lhs - rhs))

# also: the sum/product conditions themselves
check("A2. R+S == -B", ((R + S) - (-B)).is_zero())
check("A3. R*S == C", (reduce_z2(R * S, rel) - C).is_zero())

# --- B: substitution maps one derivation onto the other -------------------------
# completing the square, as an equation E1(x) = 0 with E1 = (x+B/2)^2 - (B^2/4 - C)
E1 = (x + half * B) * (x + half * B) - (quarter * B * B - C)
# Loh, as an equation E2(u) = 0 with E2 = u^2 - (B^2/4 - C)
E2 = u * u - (quarter * B * B - C)
# substitute x = -B/2 + u into E1 and compare with E2
subst = (-half * B + u)
E1_sub = (subst + half * B) * (subst + half * B) - (quarter * B * B - C)
check("B. x = -B/2 + u carries completing-the-square to u^2 = B^2/4 - C",
      (E1_sub - E2).is_zero(), "residual: %r" % (E1_sub - E2))
# and the reverse substitution u = x + B/2 carries E2 back to E1
E2_sub = (x + half * B) * (x + half * B) - (quarter * B * B - C)
check("B2. u = x + B/2 carries it back", (E2_sub - E1).is_zero())
# and E1 expanded is literally the original quadratic
check("B3. completing-the-square equation expands to x^2+Bx+C",
      (E1 - (x * x + B * x + C)).is_zero())

# --- C: characteristic-2 boundary ----------------------------------------------
# GF(2) and GF(4). GF(4) = GF(2)[w]/(w^2+w+1), elements encoded as 2-bit ints,
# multiplication by carry-less multiply reduced mod w^2+w+1 (0b111).
def gf2_add(a, b):
    return a ^ b


def gf4_mul(a, b):
    r = 0
    for i in range(2):
        if (b >> i) & 1:
            r ^= a << i
    # reduce mod w^2 + w + 1  (0b111)
    for i in (3, 2):
        if (r >> i) & 1:
            r ^= 0b111 << (i - 2)
    return r & 0b11


def report_char2(field_name, elems, mul):
    # For each (Bv, Cv), does there exist m with m + m = -Bv ?  (char 2: m+m = 0)
    have_avg = []
    for Bv in elems:
        # -Bv == Bv in characteristic 2
        exists = any(gf2_add(m, m) == Bv for m in elems)
        have_avg.append((Bv, exists))
    n_ok = sum(1 for _, e in have_avg if e)
    print("      %s: 'average' m with m+m=-B exists for %d of %d values of B (only B=0)"
          % (field_name, n_ok, len(elems)))
    return n_ok


n2 = report_char2("GF(2)", [0, 1], None)
n4 = report_char2("GF(4)", [0, 1, 2, 3], gf4_mul)
check("C. in characteristic 2 the average parameterisation exists only when B=0",
      n2 == 1 and n4 == 1, "(GF(2): %d/2, GF(4): %d/4)" % (n2, n4))
# and a concrete irreducible witness over GF(2): x^2 + x + 1 has no root in GF(2)
roots_gf2 = [r for r in (0, 1) if (gf2_add(gf2_add(r & r, r), 1) if False else
                                   ((r * r) ^ r ^ 1) % 2) == 0]
check("C2. x^2+x+1 has no root in GF(2)", roots_gf2 == [], "roots found: %r" % roots_gf2)

# --- D: operation count ---------------------------------------------------------
# CONVENTION, stated before counting (this is where a dishonest comparison would hide):
#   * we count field operations executed on NUMBERS at run time -- addition/subtraction
#     (add), multiplication (mul), division (div), square root (sqrt);
#   * negation counts as one add; comparisons, copies and sign tests are free;
#   * COMMON SUBEXPRESSIONS ARE HOISTED in every route, so no route is charged for a
#     transcription accident (the first draft of this script charged completing-the-
#     square an extra add purely because "-h" was written out twice, and the check
#     built on that artefact FAILED -- which is why the convention is now explicit);
#   * every route solves the general ax^2+bx+c=0 and returns BOTH roots.
# Counting is done by instrumenting a wrapper type, so the count is executed, not
# tallied by eye.
COUNTS = {"add": 0, "mul": 0, "div": 0, "sqrt": 0}


class N:
    __slots__ = ("v",)

    def __init__(self, v):
        self.v = float(v)

    def __add__(self, o):
        COUNTS["add"] += 1
        return N(self.v + o.v)

    def __sub__(self, o):
        COUNTS["add"] += 1
        return N(self.v - o.v)

    def __neg__(self):
        COUNTS["add"] += 1
        return N(-self.v)

    def __mul__(self, o):
        COUNTS["mul"] += 1
        return N(self.v * o.v)

    def __truediv__(self, o):
        COUNTS["div"] += 1
        return N(self.v / o.v)

    def sqrt(self):
        COUNTS["sqrt"] += 1
        return N(math.sqrt(self.v))


def reset():
    for k in COUNTS:
        COUNTS[k] = 0
    return None


def snap():
    return dict(COUNTS)


def route_formula(a, b, c):
    """Textbook closed form: (-b +- sqrt(b^2-4ac)) / (2a)."""
    disc = (b * b - N(4) * a * c).sqrt()
    two_a = N(2) * a
    return ((-b + disc) / two_a, (-b - disc) / two_a)


def route_loh(a, b, c):
    """Loh as written: divide through by a, average -B/2, z^2 = B^2/4 - C."""
    Bc = b / a
    Cc = c / a
    m = -(Bc / N(2))
    zz = (m * m - Cc).sqrt()
    return (m + zz, m - zz)


def route_complete_square(a, b, c):
    """Completing the square, executed as a procedure on numbers.

    (x + B/2)^2 = B^2/4 - C, so x = -B/2 +- sqrt(B^2/4 - C).  The subexpression -B/2
    is hoisted, per the stated convention.
    """
    Bc = b / a
    Cc = c / a
    h = Bc / N(2)
    m = -h
    rhs = (h * h - Cc).sqrt()
    return (m + rhs, m - rhs)


def route_stable(a, b, c):
    """Cancellation-avoiding form (Vieta for the second root)."""
    disc = (b * b - N(4) * a * c).sqrt()
    # q = -(b + sign(b)*sqrt(disc)) / 2 ; sign test is free under our convention
    if b.v >= 0:
        q = -((b + disc) / N(2))
    else:
        q = -((b - disc) / N(2))
    r1 = q / a
    r2 = c / q
    return (r1, r2)


print("\n  D. operation counts (both roots returned; add/mul/div/sqrt):")
opcounts = {}
for name, fn in [("textbook formula", route_formula),
                 ("completing the square", route_complete_square),
                 ("Loh (as written)", route_loh),
                 ("cancellation-avoiding", route_stable)]:
    reset()
    fn(N(1.0), N(-5.0), N(6.0))
    opcounts[name] = snap()
    tot = sum(opcounts[name].values())
    print("      %-24s add=%d mul=%d div=%d sqrt=%d  total=%d"
          % (name, opcounts[name]["add"], opcounts[name]["mul"],
             opcounts[name]["div"], opcounts[name]["sqrt"], tot))

tot_formula = sum(opcounts["textbook formula"].values())
tot_loh = sum(opcounts["Loh (as written)"].values())
tot_cs = sum(opcounts["completing the square"].values())
check("D. Loh and completing-the-square execute the IDENTICAL multiset of operations",
      opcounts["Loh (as written)"] == opcounts["completing the square"],
      "(Loh=%r, completing-the-square=%r)" % (opcounts["Loh (as written)"],
                                              opcounts["completing the square"]))
print("      MEASURED, not predicted: Loh/completing-the-square = %d ops, textbook closed"
      " form = %d ops, difference = %d" % (tot_loh, tot_formula, tot_formula - tot_loh))
# The textbook closed form is charged for 4ac and 2a because it does NOT divide through
# by a first. Counting it on an already-monic input removes that handicap:
reset()
route_formula(N(1.0), N(-5.0), N(6.0))
monic_formula = snap()
print("      textbook closed form on a MONIC input (a=1 still executed): %d ops"
      % sum(monic_formula.values()))

# SENSITIVITY TO THE CONVENTION. Unit cost is not the only defensible weighting: on
# real hardware a divide and a square root cost several multiplies. Re-total under a
# second, equally stated convention -- add=1, mul=1, div=4, sqrt=8 -- and see whether
# the ordering survives. If it does not, "computationally light" is convention-relative
# and must be reported as such.
W = {"add": 1, "mul": 1, "div": 4, "sqrt": 8}
print("      re-totalled with add=1 mul=1 div=4 sqrt=8:")
weighted = {}
for name, cnt in opcounts.items():
    weighted[name] = sum(W[k] * v for k, v in cnt.items())
    print("        %-24s weighted total = %d" % (name, weighted[name]))
check("D3. the 'computationally light' ordering is CONVENTION-DEPENDENT: the unit-cost"
      " advantage of the Loh/completing-the-square route over the closed form does not"
      " survive division-weighted counting",
      weighted["Loh (as written)"] >= weighted["textbook formula"],
      "(weighted: Loh %d vs textbook %d; unit-cost was 9 vs 12)"
      % (weighted["Loh (as written)"], weighted["textbook formula"]))

# --- E: floating-point accuracy sweep -------------------------------------------
# Exact reference: for integer coefficients, compute the smaller-magnitude root to
# high precision using Fraction arithmetic plus an exactly-controlled integer sqrt
# via Newton iteration on scaled integers (no float anywhere in the reference).
def isqrt_scaled(n, scale_bits):
    """floor(sqrt(n * 4^scale_bits)) -- integer square root at chosen precision."""
    return math.isqrt(n << (2 * scale_bits))


def exact_smaller_root(a, b, c, bits=200):
    """Exact-to-`bits` value of the smaller-magnitude real root, as a Fraction.

    Roots are (-b +- sqrt(D)) / 2a with D = b^2-4ac >= 0. The smaller-magnitude root
    is the one where the numerator cancels; we compute it in the CANCELLATION-FREE
    form 2c / (-b -+ sqrt(D)) so the reference itself is not the thing under test.
    """
    D = b * b - 4 * a * c
    assert D > 0
    s = Fr(isqrt_scaled(D, bits), 1 << bits)   # sqrt(D) to `bits` binary places
    # denominator chosen to be the LARGE one, so no cancellation in the reference
    denom = -b - s if b >= 0 else -b + s
    return Fr(2 * c, 1) / denom


# self-test of the reference itself, on a case whose roots are known exactly
_ref = exact_smaller_root(1, -5, 6)
check("E0. the exact reference is right on x^2-5x+6 (roots 2 and 3)",
      abs(_ref - 2) < Fr(1, 10 ** 40), "reference gave %s" % float(_ref))


def rel_err(approx, exact):
    if exact == 0:
        return abs(approx)
    return abs(Fr(approx) - exact) / abs(exact)


def f_textbook(a, b, c):
    d = math.sqrt(b * b - 4.0 * a * c)
    r1 = (-b + d) / (2.0 * a)
    r2 = (-b - d) / (2.0 * a)
    return r1, r2


def f_loh(a, b, c):
    Bc = b / a
    Cc = c / a
    m = -Bc / 2.0
    zz = math.sqrt(m * m - Cc)
    return m + zz, m - zz


def f_stable(a, b, c):
    d = math.sqrt(b * b - 4.0 * a * c)
    q = -(b + d) / 2.0 if b >= 0 else -(b - d) / 2.0
    return q / a, c / q


print("\n  E. relative error of the SMALLER-magnitude root, double precision")
print("     a=1, c=1, b=10^k  (exact reference computed in Fraction arithmetic)")
print("     %-6s %-14s %-14s %-14s" % ("k", "textbook", "Loh-as-written", "cancel-avoiding"))
worst = {"textbook": Fr(0), "loh": Fr(0), "stable": Fr(0)}
rows = []
for k in range(1, 11):
    a_i, b_i, c_i = 1, 10 ** k, 1
    ex = exact_smaller_root(a_i, b_i, c_i)
    af = float(a_i)
    bf = float(b_i)
    cf = float(c_i)

    def smaller(pair):
        return min(pair, key=abs)

    e_tb = rel_err(smaller(f_textbook(af, bf, cf)), ex)
    e_lo = rel_err(smaller(f_loh(af, bf, cf)), ex)
    e_st = rel_err(smaller(f_stable(af, bf, cf)), ex)
    rows.append((k, e_tb, e_lo, e_st))
    worst["textbook"] = max(worst["textbook"], e_tb)
    worst["loh"] = max(worst["loh"], e_lo)
    worst["stable"] = max(worst["stable"], e_st)
    print("     %-6d %-14.3e %-14.3e %-14.3e" % (k, float(e_tb), float(e_lo), float(e_st)))

check("E. Loh-as-written is no more accurate than the textbook formula on this sweep",
      worst["loh"] >= worst["textbook"] * Fr(999, 1000),
      "(worst rel err: Loh %.3e vs textbook %.3e)" % (float(worst["loh"]), float(worst["textbook"])))
check("E2. the cancellation-avoiding route beats BOTH by orders of magnitude",
      worst["stable"] * 1000 < worst["textbook"] and worst["stable"] * 1000 < worst["loh"],
      "(worst rel err: cancel-avoiding %.3e)" % float(worst["stable"]))

# E3: at which k does the textbook/Loh route lose ALL correct digits?
first_total_loss = None
for k, e_tb, e_lo, e_st in rows:
    if e_tb >= Fr(1, 1):
        first_total_loss = k
        break
print("     first k at which textbook relative error reaches 100%%: %s"
      % (first_total_loss if first_total_loss else "none in k<=10"))

print()
if FAILURES:
    print("FAILURES: " + ", ".join(FAILURES))
    raise SystemExit(1)
print("all checks passed")
