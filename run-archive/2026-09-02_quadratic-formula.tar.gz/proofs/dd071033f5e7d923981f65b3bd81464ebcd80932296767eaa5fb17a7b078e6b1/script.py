#!/usr/bin/env python3
"""P4 - the question nobody in the pedagogy debate asked: how ACCURATE is each
route in ordinary machine arithmetic?

Every route under discussion computes the smaller root as a difference of two
nearly equal quantities when b^2 is much larger than 4ac, and that is exactly
where binary floating point loses its significant digits.  Numerical analysis
has a standard cure: compute the root of larger magnitude by the ADDITION, and
get the other from the product relation c/(a*r1) -- which is Vieta's product
relation, the very step Loh's derivation already has in its hands.

Reference values are exact: coefficients are integers, the discriminant is an
exact integer, and its square root is taken in the `decimal` module at 60
significant digits, so the reference is right to far more digits than double
precision can hold.  No external library is used and no random numbers are
drawn, so the whole sweep re-runs identically.

Routes compared (all in IEEE double precision):
  F  textbook closed form,      (-b +/- sqrt(b^2-4ac)) / (2a)
  C  completing the square as a procedure (divide to monic first)
  L  Loh as written             (divide to monic first; -B/2 +/- z)
  S  the cancellation-avoiding form: larger-magnitude root by addition, other
     root from the product relation -- Loh's own Vieta step, used numerically
"""
from decimal import Decimal, getcontext
from math import sqrt

getcontext().prec = 60


def exact_roots(a, b, c):
    """Roots to 60 significant digits, for integer a,b,c with real roots."""
    A, Bc, C = Decimal(a), Decimal(b), Decimal(c)
    D = Bc * Bc - 4 * A * C
    s = D.sqrt()
    return ((-Bc + s) / (2 * A), (-Bc - s) / (2 * A))


def route_F(a, b, c):
    d = sqrt(b * b - 4.0 * a * c)
    return ((-b + d) / (2.0 * a), (-b - d) / (2.0 * a))


def route_C(a, b, c):
    B, C = b / a, c / a
    h = B / 2.0
    v = sqrt(h * h - C)
    return (-h + v, -h - v)


def route_L(a, b, c):
    B, C = b / a, c / a
    m = -(B / 2.0)
    z = sqrt(m * m - C)
    return (m + z, m - z)


def route_S(a, b, c):
    d = sqrt(b * b - 4.0 * a * c)
    q = -0.5 * (b + d) if b >= 0 else -0.5 * (b - d)
    r1 = q / a
    r2 = (c / q) if q != 0 else r1
    return (r1, r2)


ROUTES = [("F textbook closed form", route_F),
          ("C completing the square", route_C),
          ("L Loh as written", route_L),
          ("S product-relation (stable)", route_S)]


def relerr(approx, exact):
    e = Decimal(repr(approx)) - exact
    return abs(e) / abs(exact) if exact != 0 else abs(e)


def match(approx_pair, exact_pair):
    """pair up each computed root with the nearer exact root, return worst rel err"""
    p = sorted(approx_pair)
    q = sorted(exact_pair, key=lambda d: float(d))
    return max(relerr(p[0], q[0]), relerr(p[1], q[1]))


print("Sweep: a = 1, c = 1, b = 10^k for k = 1..8.")
print("Roots are then about -b and -1/b, so the small root is the cancellation case.")
print()
print("%-6s %-28s %-24s %-24s" % ("k", "route", "worst relative error", "small root computed"))
worst = {name: Decimal(0) for name, _ in ROUTES}
for k in range(1, 9):
    a, b, c = 1, 10 ** k, 1
    ex = exact_roots(a, b, c)
    small_exact = min(ex, key=lambda d: abs(d))
    for name, fn in ROUTES:
        got = fn(float(a), float(b), float(c))
        w = match(got, ex)
        worst[name] = max(worst[name], w)
        small_got = min(got, key=abs)
        print("%-6d %-28s %-24.3e %-24.17g" % (k, name, float(w), small_got))
    print("       (exact small root: %.17e)" % small_exact)
print()
print("worst relative error over the sweep, by route:")
for name, _ in ROUTES:
    print("   %-28s %.3e" % (name, float(worst[name])))

print()
print("Second sweep: overflow/underflow behaviour, a=1, b=10^k, c=1 with k large,")
print("plus a scaled family where b^2 overflows double precision but the roots do not.")
for (a, b, c) in [(1e-200, 1e200, 1e-200), (1.0, 1e200, 1.0), (1e200, 1e200, 1e200)]:
    line = "a=%-9g b=%-9g c=%-9g" % (a, b, c)
    for name, fn in ROUTES:
        try:
            r = fn(a, b, c)
            line += " | %s -> (%.6g, %.6g)" % (name.split()[0], r[0], r[1])
        except (OverflowError, ValueError, ZeroDivisionError) as ex:
            line += " | %s -> %s" % (name.split()[0], type(ex).__name__)
    print(line)

print("(reading of the overflow block: NONE of the four routes survives coefficients")
print(" whose squares leave double-precision range -- the library cure is to rescale")
print(" the coefficients first, which is a fifth thing none of the pedagogical")
print(" presentations mentions.)")
print()
print("READING:")
wl, ws = worst["L Loh as written"], worst["S product-relation (stable)"]
print(" - Loh as written is a cancellation-prone route, exactly like the textbook")
print("   formula and completing the square: worst relative error %.2e." % float(wl))
print(" - The product relation Loh's own derivation supplies (R*S = C) repairs it:")
print("   worst relative error %.2e over the same sweep." % float(ws))
if ws > 0:
    print(" - ratio of worst errors, prone/stable: %.3g" % float(wl / ws))
else:
    print(" - the stable route was exact to the printed precision on this sweep")
print(" - So the pedagogical debate and the numerical-analysis literature are")
print("   discussing two different objects, and the bridge between them is one")
print("   line long.")
raise SystemExit(0)
