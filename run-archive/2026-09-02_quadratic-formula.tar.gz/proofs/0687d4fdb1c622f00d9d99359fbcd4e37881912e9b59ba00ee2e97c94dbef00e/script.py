#!/usr/bin/env python3
"""R3-1, as a CLASS: every decisive absence this report asserts over a cached
document, counted twice — once under the report's stated transform, once over
the untransformed bytes — with the discrepancy printed rather than assumed away.

The Medium capture showed that a transform can delete the thing being searched
for. This program asks the same question of every other cached document whose
absence the report treats as decisive, and prints, per document:

  * the share of its bytes that live inside <script>/<style> bodies;
  * whether it carries an embedded client-side state blob (a strong hint that
    the page is rendered in the browser rather than on the server); and
  * per term, the count under the transform and over the raw bytes, with a
    FLAG wherever the transformed count is zero and the raw count is not —
    which is exactly the shape of the Medium error.

A positive control accompanies each absence, so a zero is distinguishable from
an empty fetch.  Needs cache/, which the run archive does not carry; it says
NOT MEASURED rather than printing zeros when the cache is absent.
"""

import html
import os
import re

DOCS = [
    # label, cache-sha prefix, prefer-text-layer, [(term, "absence"|"control")]
    ("poshenloh.com/quadraticrelated", "c75dc403", False,
     [("Brozinsky", "absence"), ("cut-the-knot", "absence"),
      ("Bogomolny", "absence"), ("Savage", "control"),
      ("zero-product", "control")]),
    ("Gustafsson 2026 systematic review", "3423fb6e", False,
     [("Loh", "absence"), ("Po-Shen", "absence"), ("quadratic", "control")]),
    ("arXiv 1910.06709v1 (text layer)", "a8cd0e04", True,
     [("Euclid", "absence"), ("zero-product", "absence"),
      ("Diophantus", "control")]),
    ("arXiv 1910.06709v2 (text layer)", "c08b0b35", True,
     [("Euclid", "absence"), ("zero-product", "absence"),
      ("Diophantus", "control"), ("Savage", "control"),
      ("Gowers", "control")]),
    ("poshenloh.com/quadratic (public)", "45eb9232", False,
     [("zero-product", "absence"), ("quadratic", "control")]),
    ("poshenloh.com/quadraticdetail", "f95c01cc", False,
     [("zero-product", "control")]),
    ("poshenloh.com/quadraticcompsqr", "2e3779d7", False,
     [("zero-product", "control")]),
    ("poshenloh.com/quadraticlogicexist", "2f77f416", False,
     [("zero-product", "control")]),
    ("cut-the-knot snapshot, 20 May 2019", "73ab119f", False,
     [("Brozinsky", "control"), ("Heaton", "control"), ("Cirul", "control")]),
    ("Medium capture, 10 April 2021", "ee90ea8d", False,
     [("Brozinsky", "absence"), ("cut-the-knot", "absence"),
      ("Bogomolny", "absence"), ("Savage", "absence"), ("Gowers", "absence")]),
]

STATE_MARKERS = ("__APOLLO_STATE__", "__NEXT_DATA__", "__INITIAL_STATE__",
                 "__NUXT__")


def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise SystemExit("no run directory found by walking upward")
        d = parent


RUN = find_run_dir()
CACHE = os.path.join(RUN, "cache")

print("== R3-1 as a class: every decisive absence, counted twice ==")
if not os.path.isdir(CACHE):
    raise SystemExit("NOT MEASURED: the run cache is not present beside this program.")


def resolve(prefix, prefer_text):
    hits = [n for n in sorted(os.listdir(CACHE)) if n.startswith(prefix)]
    texts = [n for n in hits if n.endswith(".txt")]
    blobs = [n for n in hits if not n.endswith(".txt")]
    chosen = (texts or blobs) if prefer_text else blobs
    if len(chosen) != 1:
        raise SystemExit("cache prefix %s resolves to %d files" % (prefix, len(chosen)))
    return os.path.join(CACHE, chosen[0])


def visible_text(doc):
    body = re.sub(r"<(script|style)\b.*?</\1>", " ", doc, flags=re.S | re.I)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]*>", " ", body))).strip()


flags = 0
client_rendered = []
for label, sha, prefer_text, terms in DOCS:
    path = resolve(sha, prefer_text)
    raw = open(path, "rb").read().decode("utf-8", "replace")
    vis = visible_text(raw)
    script_bytes = sum(len(m.group(0)) for m in
                       re.finditer(r"<(script|style)\b.*?</\1>", raw,
                                   flags=re.S | re.I))
    markers = [m for m in STATE_MARKERS if m in raw]
    share = 100.0 * script_bytes / max(1, len(raw))
    print()
    print("%s" % label)
    print("  cache %s...  chars=%d  visible=%d  script/style share=%.1f%%  state blob: %s"
          % (sha, len(raw), len(vis), share, ", ".join(markers) or "none"))
    for term, kind in terms:
        v = vis.lower().count(term.lower())
        r = raw.lower().count(term.lower())
        flag = ""
        if kind == "absence" and v == 0 and r > 0:
            flag = "  <<< FLAG: absent under the transform, present in the bytes"
            flags += 1
        if kind == "control" and v == 0 and r == 0:
            flag = "  <<< FLAG: control term absent — the fetch may be empty"
            flags += 1
        print("    %-13s %-8s transformed=%4d  raw bytes=%4d%s"
              % (term, kind, v, r, flag))
    # a page whose visible text is a small fraction of a script-heavy document
    # AND which carries a state blob is the shape that hid the Medium article
    if markers and len(vis) < 0.10 * len(raw):
        client_rendered.append(label)

print()
print("SUMMARY")
print("  documents swept                        :", len(DOCS))
print("  absence/control discrepancies flagged  :", flags)
print("  documents matching the client-rendered SHAPE (a state blob and visible")
print("  text under 10% of the document)        :", len(client_rendered))
for label in client_rendered:
    print("     -", label)
print()
print("READING, INCLUDING THE PART THAT GOES AGAINST THE HEURISTIC. Zero terms")
print("changed answer between the transform and the raw bytes anywhere in this")
print("sweep, so the Medium capture is the ONLY document in this run whose")
print("stated absence the transform could have falsified — and it did not even")
print("falsify that one, since the essay names none of the five terms; what it")
print("hid was the article, not a counterexample. Note the shape heuristic is")
print("weak: it fires on six documents here and only one of them actually")
print("carried text the transform deleted, because the five poshenloh.com pages")
print("are script-heavy Next.js pages whose prose is ALSO in the served HTML.")
print("A state blob is a hint to go and check; the count comparison is the test.")
