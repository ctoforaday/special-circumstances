#!/usr/bin/env python3
"""R2-2: every figure the report states must close from the route the report gives.

Four legs, each one of red's four counter-examples, recomputed here from the
primary bytes rather than from the earlier scripts' output.

Leg 1+2  the v1->v2 prose measurement: RAW unit counts against DISTINCT unit
         counts, and which denominator each printed figure actually used.
Leg 3    the Gustafsson term count under the recipe the report states, with and
         without case folding.
Leg 4    two counts over the run's OWN artifacts (the lines-of-inquiry
         projection and the rendered report), which the archive does not carry.
         Where the run tree is absent this prints NOT MEASURED rather than 0 —
         a miss must not be indistinguishable from an honest zero.

Run-directory resolution is an upward walk for a marker, so this runs the same
from blue/candidates/r2-proofs/ and from proofs/<sha>/.
"""

import json
import os
import re
import subprocess

GUSTAFSSON_SHA = "3423fb6e6a7cda121a5fbdfb46c16989994b68a4ca4fa1ee62db9c6724dbea31"


def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        p = os.path.dirname(d)
        if p == d:
            raise SystemExit("no run directory found by walking upward")
        d = p


RUN = find_run_dir()
CACHE = os.path.join(RUN, "cache")

print("== R2-2: recounting the four figures a checker could not reproduce ==")
print()

# ---------------------------------------------------------------- cache index
index = {}
idx_path = os.path.join(CACHE, "index")
have_cache = os.path.exists(idx_path)
if have_cache:
    for line in open(idx_path):
        rec = json.loads(line)
        index[rec["url"]] = rec


def cached_text(url):
    rec = index[url]
    if rec.get("text_sha"):
        p = os.path.join(CACHE, rec["sha"] + ".txt")
        if os.path.exists(p):
            return open(p, encoding="utf-8", errors="replace").read()
    return open(os.path.join(CACHE, rec["sha"]), encoding="utf-8", errors="replace").read()


# --------------------------------------------- legs 1 and 2: the v1->v2 diff
# The unit rule is q1_v1v2_diff.py's, restated here rather than imported so
# this program can be checked against that one: a prose unit is a sentence of
# >=40 characters carrying >=4 alphabetic words of >=2 letters.
def prose_units(text):
    flat = re.sub(r"\s+", " ", text)
    out = []
    for s in re.split(r"(?<=[.!?]) ", flat):
        s = s.strip()
        if len(s) >= 40 and len(re.findall(r"[A-Za-z]{2,}", s)) >= 4:
            out.append(s)
    return out


print("LEG 1+2 -- the v1 -> v2 prose measurement, raw units vs distinct units")
if not have_cache:
    print("  NOT MEASURED: the run cache is not present beside this program.")
else:
    p1 = prose_units(cached_text("https://arxiv.org/pdf/1910.06709v1"))
    p2 = prose_units(cached_text("https://arxiv.org/pdf/1910.06709v2"))
    s1, s2 = set(p1), set(p2)
    unchanged = len(s1 & s2)
    print("  v1 prose units, RAW (with repeats)      : %d" % len(p1))
    print("  v2 prose units, RAW (with repeats)      : %d" % len(p2))
    print("  v1 prose units, DISTINCT                : %d" % len(s1))
    print("  v2 prose units, DISTINCT                : %d" % len(s2))
    print("  distinct v1 units also in v2 (unchanged): %d" % unchanged)
    print("  distinct v1 units absent from v2        : %d" % len(s1 - s2))
    print()
    print("  survival over the DISTINCT denominator  : %d/%d = %.1f%%"
          % (unchanged, len(s1), 100.0 * unchanged / len(s1)))
    print("  survival over the RAW denominator       : %d/%d = %.1f%%"
          % (unchanged, len(p1), 100.0 * unchanged / len(p1)))
    print("  --> the 50.8% and the 62 the report prints are over the DISTINCT set,")
    print("      while the 127 it prints beside them is the RAW count; a reader")
    print("      dividing 64 by 127 gets %.1f%% and 127-64 = %d."
          % (100.0 * unchanged / len(p1), len(p1) - unchanged))

# ------------------------------------------- leg 3: the Gustafsson term count
print()
print("LEG 3 -- the Gustafsson count under the recipe the report states")
if not have_cache:
    print("  NOT MEASURED: the run cache is not present beside this program.")
else:
    raw = None
    for url, rec in index.items():
        if rec["sha"] == GUSTAFSSON_SHA:
            raw = cached_text(url)
    if raw is None:
        print("  NOT MEASURED: sha %s not in the cache index." % GUSTAFSSON_SHA[:8])
    else:
        drop_bodies = re.sub(
            r"<(script|style)\b.*?</\1>", " ", raw, flags=re.S | re.I
        )
        stripped_dropped = re.sub(r"<[^>]*>", " ", drop_bodies)
        stripped_kept = re.sub(r"<[^>]*>", " ", raw)
        rows = [
            ("bodies DROPPED, tags stripped, case-SENSITIVE", stripped_dropped.count("quadratic")),
            ("bodies DROPPED, tags stripped, case-FOLDED", stripped_dropped.lower().count("quadratic")),
            ("bodies KEPT, tags stripped, case-SENSITIVE", stripped_kept.count("quadratic")),
            ("bodies KEPT, tags stripped, case-FOLDED", stripped_kept.lower().count("quadratic")),
            ("raw bytes, case-SENSITIVE", raw.count("quadratic")),
            ("raw bytes, case-FOLDED", raw.lower().count("quadratic")),
        ]
        for label, n in rows:
            print("  %-46s %d" % (label, n))
        print("  --> the report prints 76 / 88 / 114: the case-FOLDED family.")
        print("      The stated recipe omits case folding and returns %d."
              % stripped_dropped.count("quadratic"))
        for term in ("Loh", "Po-Shen"):
            print("  zero check, %-8s bodies dropped, case-folded : %d"
                  % (term, stripped_dropped.lower().count(term.lower())))
        print("  zero check, whole-word 'loh', case-folded       : %d"
              % len(re.findall(r"\bloh\b", stripped_dropped.lower())))

# ----------------------- leg 4: two counts over the run's own record and report
print()
print("LEG 4 -- counts over the run's OWN artifacts (record and report)")
binp = os.path.join(RUN, ".bin", "feov-record")
if not os.path.exists(binp):
    print("  NOT MEASURED: %s is absent, so neither count can be taken here." % binp)
    print("  This is stated as NOT MEASURED and never as 0: a missing projection")
    print("  and an empty projection must not look the same.")
else:
    loi = subprocess.run(
        [binp, "show", "lines-of-inquiry"], capture_output=True, text=True,
        cwd=RUN,
    ).stdout
    qs = sorted({int(m) for m in re.findall(r"\bQ(\d+)\b", loi)})
    print("  distinct Q labels in the lines-of-inquiry projection: %d (Q%d..Q%d)"
          % (len(qs), min(qs), max(qs)))
    rep = subprocess.run(
        [binp, "show", "report"], capture_output=True, text=True, cwd=RUN,
    ).stdout
    n = rep.count("unreachable from this container")
    print("  literal 'unreachable from this container' in the report: %d" % n)
    # The honest unit is not the phrase but the SOURCE. These are the named
    # documents the report says this container could not reach; the check is
    # that each is named in the report, so a reader can count the list itself.
    unreached = ("Savage", "Heaton", "Cirul", "Andam", "Missa", "Burton",
                 "Medium essay")
    named = [n for n in unreached if rep.count(n) > 0]
    print("  named unreached sources present in the report: %d of %d"
          % (len(named), len(unreached)))
    for n in unreached:
        print("     %-10s occurrences in the report: %d" % (n, rep.count(n)))

# ------------------------------------------------------------------- leg 5
# Is the "81 author-level prose changes" figure an artefact of one
# segmentation?  The report says the robust claim is "an order of magnitude
# more than seven".  That was ASSERTED.  Here it is measured: the same
# pipeline re-run under three different unit rules.
print()
print("LEG 5 -- is the strict 81 an artefact of one segmentation?")
if not have_cache:
    print("  NOT MEASURED: the run cache is not present beside this program.")
else:
    import difflib

    def units(text, minlen, minwords):
        flat = re.sub(r"\s+", " ", text)
        return [
            s.strip()
            for s in re.split(r"(?<=[.!?]) ", flat)
            if len(s.strip()) >= minlen
            and len(re.findall(r"[A-Za-z]{2,}", s)) >= minwords
        ]

    v1 = cached_text("https://arxiv.org/pdf/1910.06709v1")
    v2 = cached_text("https://arxiv.org/pdf/1910.06709v2")
    print("  %-14s %6s %6s %6s %6s %6s %6s" %
          ("rule", "|v1|", "same", "edit", "del", "new", "STRICT"))
    for minlen, minwords in ((40, 4), (30, 3), (60, 5), (25, 2), (80, 6)):
        p1, p2 = units(v1, minlen, minwords), units(v2, minlen, minwords)
        s1, s2 = set(p1), set(p2)
        only1 = [p for p in p1 if p not in s2]
        only2 = [p for p in p2 if p not in s1]
        pool = list(only2)
        edited = substantive = 0
        for a in only1:
            best, bestr = None, 0.0
            for b in pool:
                r = difflib.SequenceMatcher(None, a, b).ratio()
                if r > bestr:
                    best, bestr = b, r
            if bestr >= 0.60:
                edited += 1
                if bestr < 0.95:
                    substantive += 1
                pool.remove(best)
        deleted = len(only1) - edited
        new = len(pool)
        strict = substantive + deleted + new
        print("  len>=%-2d w>=%-2d %6d %6d %6d %6d %6d %6d" %
              (minlen, minwords, len(s1), len(s1 & s2), edited, deleted, new, strict))
    print("  --> the strict count moves with the unit rule; what does not move")
    print("      is that it stays an order of magnitude above seven.")
