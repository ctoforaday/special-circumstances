#!/usr/bin/env python3
"""R3-5: the round-2 document probes, with the leg that could not fail given a
criterion, plus two new legs for this round's repairs.

Red's finding was exact: in r2_docchecks.py leg (b) printed seven hits and
stopped — no comparison, no RESULT line, no increment — so "legs failing: 0"
read identically whether it was clean or had never been evaluated, while the
report claimed all four passed. This successor adjudicates every leg it counts,
and its final line names how many legs are ADJUDICATED rather than how many
exist.

  (a) R2-6  quote parity, doubled terminators, empty pairs.
  (b) R2-7  every 'controll' form classified against a stated criterion that
            can fail, rather than printed for a human to judge.
  (c) R2-7  'sign choice' at the bridge sites, with the report's own
            description of this check EXCLUDED from the count — red noticed
            that the round-2 leg counted its own self-description toward the
            threshold and did not charge it; it is fixed here.
  (d) R2-3/R3-6  the Catechism 6 grading, keyed on a stable anchor and failing
            LOUDLY if the anchor is gone rather than passing on an empty
            clause — which is how the round-2 leg would have behaved after
            this round's edit to that sentence.
  (e) R3-1  no surviving sentence asserts of the Medium essay what the
            recovered article refutes, and the byte figure carries its unit.
  (f) R3-4  the report's TITLE line carries no citation anchor beyond the two
            known stranded ones, so a third accident is caught by a check
            rather than by the next auditor.

Needs the run tree (it reads the rendered report through the record tool).
Says NOT MEASURED, never 0, when the projection is unreachable.
"""

import os
import re
import subprocess


def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        p = os.path.dirname(d)
        if p == d:
            raise SystemExit("no run directory found by walking upward")
        d = p


RUN = find_run_dir()
binp = os.path.join(RUN, ".bin", "feov-record")
if not os.path.exists(binp):
    raise SystemExit(
        "NOT MEASURED: %s is absent, so the rendered report cannot be read "
        "here. This is an explicit refusal, not a pass." % binp
    )
rep = subprocess.run(
    [binp, "show", "report"], capture_output=True, text=True, cwd=RUN
).stdout
if not rep.strip():
    raise SystemExit("NOT MEASURED: the report projection came back empty.")

lines = rep.splitlines()
print("== document probes over the rendered report (%d lines) ==" % len(lines))
adjudicated = 0
fails = 0


def result(ok):
    global adjudicated, fails
    adjudicated += 1
    if not ok:
        fails += 1
    print("    RESULT: %s" % ("PASS" if ok else "FAIL"))


def ctx(pos, before=160, after=160):
    return re.sub(r"\s+", " ", rep[max(0, pos - before): pos + after])


# ---------------------------------------------------------------- (a) R2-6
print()
print("(a) R2-6 -- quotation-mark parity and terminator artefacts")
odd = [(i + 1, l) for i, l in enumerate(lines) if l.strip() and l.count('"') % 2]
print("    lines with an ODD number of double-quote characters: %d" % len(odd))
for n, l in odd:
    print("      line %d: ...%s..." % (n, l[:120]))
dbl = rep.count('."."')
empty = len(re.findall(r'""', rep))
print('    occurrences of the doubled terminator ."." : %d' % dbl)
print('    occurrences of an empty quote pair ""      : %d' % empty)
result(not odd and not dbl and not empty)

# ---------------------------------------------------------------- (b) R2-7
print()
print("(b) R2-7 -- every 'controll' form, CLASSIFIED against a stated criterion")
print("    criterion: each occurrence must satisfy one of")
print("      (1) an 'uncontroll...' form whose context names the uncontrolled")
print("          study (Andam, pre/post, pre-test, single-group, unread);")
print("      (2) an explicit refusal to characterise Boadu & Bannor, i.e. the")
print("          context carries 'does not call' together with 'Boadu';")
print("      (3) this report's own description of this check, marked by one of")
print("          'document probes', 'form being about the uncontrolled',")
print("          'adjudicat', 'probe leg', 'controll leg', 'legs failing' — a")
print("          list that is STATED rather than assumed because this leg fired")
print("          on the paragraph describing it during this round's own repairs.")
print("    anything else is this report characterising a study as controlled")
print("    in its own voice, and FAILS.")
unclassified = []
counts = {1: 0, 2: 0, 3: 0}
for m in re.finditer(r"controll", rep, re.I):
    c = ctx(m.start())
    word_start = rep[max(0, m.start() - 3): m.start()].lower().endswith("un")
    if word_start and any(k in c for k in
                          ("Andam", "pre/post", "pre-test", "single-group",
                           "unread uncontrolled")):
        klass = 1
    elif "does not call" in c and "Boadu" in c:
        klass = 2
    elif any(k in c for k in ("document probes", "form being about the uncontrolled",
                              "adjudicat", "probe leg", "controll leg",
                              "legs failing")):
        klass = 3
    else:
        klass = 0
    if klass:
        counts[klass] += 1
    else:
        unclassified.append(c)
    print("      [%s] ...%s..." % (klass or "UNCLASSIFIED", c[:150]))
print("    classified: (1) about the uncontrolled study %d, (2) explicit refusal"
      " %d, (3) self-description %d, unclassified %d"
      % (counts[1], counts[2], counts[3], len(unclassified)))
result(not unclassified)

# ---------------------------------------------------------------- (c) R2-7
print()
print("(c) R2-7 -- 'sign choice' at the bridge sites, self-description excluded")
sc = [m.start() for m in re.finditer(r"sign choice", rep)]
selfdesc = [h for h in sc if "document probes" in ctx(h) or "present at all four"
            in ctx(h)]
real = [h for h in sc if h not in selfdesc]
print("    occurrences total: %d, of which self-description: %d, bridge sites: %d"
      " (red requires 4 bridge sites)" % (len(sc), len(selfdesc), len(real)))
for h in real:
    print("      ...%s..." % ctx(h, 70, 40))
result(len(real) >= 4)

# ------------------------------------------------------------ (d) R2-3/R3-6
print()
print("(d) R2-3 and R3-6 -- the Catechism 6 grading")
nr = len(re.findall(r"not a rate", rep))
print("    occurrences of 'not a rate': %d" % nr)
i = rep.find("Graded on the consequence axis at the point of the")
print("    grading clause anchor found:", i >= 0)
if i < 0:
    print("    the anchor this leg keys on is GONE from the report; this leg")
    print("    cannot be evaluated and is recorded as a failure rather than")
    print("    passing on an empty string, which is what its predecessor did.")
    result(False)
else:
    clause = rep[i: i + 2000]
    tests = [
        ("likelihood is NOT stated as a bare grade word",
         not re.search(r"\*likelihood\* — (low|medium|high|medium_high|low_medium)\b",
                       clause)),
        ("likelihood is stated as unquantified / under ignorance",
         "unquantified" in clause),
        ("no clause says the existence-assuming form carries the warrant",
         "existence-assuming form whose logic is the warrant" not in clause),
        ("the second cost channel is named",
         "requires fewer computations" in clause),
        ("R3-6: the grading says WHICH recommendation it covers",
         "FIRST of this answer's two recommendations" in clause),
        ("R3-6: the bridge is pointed at Analysis D's grade instead",
         "graded separately in Analysis D" in clause),
    ]
    ok = True
    for label, passed in tests:
        print("    %-58s %s" % (label, "PASS" if passed else "FAIL"))
        ok = ok and passed
    result(ok)

# ---------------------------------------------------------------- (e) R3-1
print()
print("(e) R3-1 -- the Medium-essay claims the recovered article refutes")
forbidden = ["no article body", "single Internet Archive capture",
             "the CDX index shows no other capture", "79,219 bytes"]
bad = [(f, rep.count(f)) for f in forbidden if rep.count(f)]
for f, n in bad:
    print("    FORBIDDEN still present: %-40s %d" % (f, n))
required = ["prefix-matched CDX", "79,300 bytes", "__APOLLO_STATE__"]
missing = [r for r in required if r not in rep]
for r in required:
    print("    required present: %-24s %s" % (r, r in rep))
result(not bad and not missing)

# ---------------------------------------------------------------- (f) R3-4
print()
print("(f) R3-4 -- citation anchors stranded in the report's TITLE line")
title = lines[0] if lines else ""
in_title = re.findall(r"<!--cite:(c-[0-9a-f]+)-->", title)
KNOWN = {"c-95969800", "c-e606dcbe"}
print("    citation anchors in the title line:", in_title or "none")
print("    known stranded set                :", sorted(KNOWN))
extra = [a for a in in_title if a not in KNOWN]
print("    anchors beyond the known set      :", extra or "none")
print("    (both known anchors resolve to the 2026 systematic review and were")
print("    spliced there by a locator that mishandles a quote containing")
print("    double-quote characters; neither seat has a verb that moves one.)")
result(not extra)

print()
print("legs adjudicated: %d; legs failing: %d" % (adjudicated, fails))
print("every leg above increments the failure counter on its own criterion, so")
print("this number is a verdict over all %d and not over a subset." % adjudicated)
