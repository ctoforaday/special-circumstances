#!/usr/bin/env python3
"""R2-6 and the document-probe legs of R2-3 and R2-7, run rather than read.

Red set four acceptance checks that are commands over the shipped report.
Running them here means the report ships the checks that audit it, and means a
failure is visible to blue before red re-runs it rather than after.

  (a) R2-6  per-line double-quote parity, plus the doubled-terminator and
            empty-quote-pair greps.  Passes at zero odd lines and zero hits.
  (b) R2-7  every 'controll' form is about Andam et al. or is not this
            report's own characterisation of Boadu & Bannor's design.
  (c) R2-7  'sign choice' appears inside each of the four bridge sites.
  (d) R2-3  the Catechism 6 grading does not warrant a likelihood with the
            three-adopter count the report twice calls "not a rate".

Needs the run tree (it reads the rendered report).  Says NOT MEASURED, never 0,
when the projection is unreachable.
"""

import os
import re
import subprocess

def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        p = os.path.dirname(d)
        if p == d:
            raise SystemExit("no run directory found by walking upward")
        d = p


RUN = find_run_dir()
binp = os.path.join(RUN, ".bin", "feov-record")
if not os.path.exists(binp):
    raise SystemExit(
        "NOT MEASURED: %s is absent, so the rendered report cannot be read "
        "here. This is an explicit refusal, not a pass." % binp
    )
rep = subprocess.run(
    [binp, "show", "report"], capture_output=True, text=True, cwd=RUN
).stdout
if not rep.strip():
    raise SystemExit("NOT MEASURED: the report projection came back empty.")

lines = rep.splitlines()
print("== document probes over the rendered report (%d lines) ==" % len(lines))
fails = 0

# ---------------------------------------------------------------- (a) R2-6
print()
print("(a) R2-6 -- quotation-mark parity and terminator artefacts")
odd = [(i + 1, l) for i, l in enumerate(lines) if l.strip() and l.count('"') % 2]
print("    lines with an ODD number of double-quote characters: %d" % len(odd))
for n, l in odd:
    print("      line %d: ...%s..." % (n, l[:120]))
dbl = rep.count('."."')
empty = len(re.findall(r'""', rep))
print('    occurrences of the doubled terminator ."." : %d' % dbl)
print('    occurrences of an empty quote pair ""      : %d' % empty)
if odd or dbl or empty:
    fails += 1
    print("    RESULT: FAIL")
else:
    print("    RESULT: PASS")

# ---------------------------------------------------------------- (b) R2-7
print()
print("(b) R2-7 site 1 -- every 'controll' form in the report")
hits = [m.start() for m in re.finditer(r"controll", rep, re.I)]
print("    hits: %d" % len(hits))
for h in hits:
    frag = re.sub(r"\s+", " ", rep[max(0, h - 90): h + 90])
    print("      ...%s..." % frag)

# ---------------------------------------------------------------- (c) R2-7
print()
print("(c) R2-7 site 2 -- 'sign choice' across the four bridge sites")
sc = [m.start() for m in re.finditer(r"sign choice", rep)]
print("    occurrences of 'sign choice': %d (red requires 4)" % len(sc))
for h in sc:
    frag = re.sub(r"\s+", " ", rep[max(0, h - 70): h + 40])
    print("      ...%s..." % frag)
if len(sc) < 4:
    fails += 1
    print("    RESULT: FAIL")
else:
    print("    RESULT: PASS")

# ---------------------------------------------------------------- (d) R2-3
print()
print("(d) R2-3 -- the Catechism 6 grading against the report's own rulings")
nr = len(re.findall(r"not a rate", rep))
print("    occurrences of 'not a rate': %d" % nr)
i = rep.find("Graded on the consequence axis at the point of recommendation")
clause = rep[i: i + 1400] if i >= 0 else ""
print("    grading clause found:", i >= 0)
tests = [
    ("likelihood is NOT stated as a bare grade word",
     not re.search(r"\*likelihood\* — (low|medium|high|medium_high|low_medium)\b",
                   clause)),
    ("likelihood is stated as unquantified / under ignorance",
     "unquantified" in clause),
    ("no clause says the existence-assuming form carries the warrant",
     "existence-assuming form whose logic is the warrant" not in clause),
    ("the second cost channel is named",
     "requires fewer computations" in clause),
]
for label, ok in tests:
    print("    %-58s %s" % (label, "PASS" if ok else "FAIL"))
    if not ok:
        fails += 1

print()
print("legs failing: %d" % fails)
