#!/usr/bin/env python3
"""R2-1: does the proof store actually re-run?

The report claims the record's proof store is what carries a program out of
this container. This program tests that claim the only way it can be tested:
by executing every stored script FROM ITS OWN STORE DIRECTORY and diffing the
output against the output the store holds beside it.

It resolves the run directory by WALKING UPWARD for a marker (a directory that
contains both `records/` and `proofs/`) rather than by a fixed parent depth, so
this program itself runs identically from blue/candidates/r2-proofs/ and from
proofs/<sha>/.  That is the shape of the resolution the four crashing scripts
lack, and it is demonstrated here rather than asserted.

The sha list is FROZEN to the fourteen entries the store held at the start of
round 2, so the output does not move as this round deposits more proofs.
"""

import hashlib
import os
import subprocess
import sys

FROZEN = [
    ("04d068984e23373c67cefe722defd72f439886b846b5393ad00c7843f192688a", "r1_recount.py"),
    ("37e49e620191506ec3a64b35ea42ac4089fdd85bb71db2983f3ce7f7bdf3c86c", "r1_dates.py"),
    ("3ff38c328be8c6fc6aff40abe64c4e76e60247ee57aef462b6eab6d030142731", "lane-2-verify.py"),
    ("638ca51e9ea088d4e71e9f14fe2190e6d530361a2fe6bf725dbd59d3cdd33e1e", "p1_identity.py"),
    ("8b1fbc831541995259550c69a18e6e3a71280df135cd8f742f474b7b2d113102", "s2_factorability_fast.py"),
    ("8f1e2b6d8b3356d1e0356f3eed3896e00f46fddf03999ff2c45e5d2297696265", "q2_field_invariant.py"),
    ("a040d8c5dd7eed10ab9035d9812c8bec2513f042266c4f9219f3451ae0a8f0a1", "q4_artifact_absences.py"),
    ("a77c4880915bda91cb1c85571ff00e69c02db730188187b1b63b7676c4eeb61d", "p3_opcount.py"),
    ("ab43acb2f30683e71486134cffa61a240f1c1c86d13ab27ebcf94b476ee148fa", "q1_v1v2_diff.py"),
    ("b6808556c293ce9a10cf6d336c9e7fc2959e4622456834edbcb950618309870d", "r1_bridge.py"),
    ("b8851493c6d58c88a0d77f0348e526d8aae7d86e5ffb7c66dc1db8e4c9e43e68", "r1_persistence.py"),
    ("c5a119dc355d12801995d50c6938472a12c8e03d6675a646aef7684e07ee0202", "s1_assumption_fast.py"),
    ("db8ee37b797d8be3ddbf23570ce9ae6024a001f100668c467a1fc5230d0245c2", "r1_lane_tags.py"),
    ("dd071033f5e7d923981f65b3bd81464ebcd80932296767eaa5fb17a7b078e6b1", "p4_numerics.py"),
]


def find_run_dir():
    """Walk upward for a directory holding both records/ and proofs/."""
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise SystemExit("no run directory found by walking upward")
        d = parent


RUN = find_run_dir()
STORE = os.path.join(RUN, "proofs")

print("== R2-1: replaying the proof store from the store ==")
print("run directory resolved by upward marker walk:", os.path.basename(RUN))
print("frozen store entries audited:", len(FROZEN))
print()

ok, crash, silent_wrong = [], [], []
reads_run_tree = []

for sha, origin in FROZEN:
    d = os.path.join(STORE, sha)
    names = [n for n in sorted(os.listdir(d)) if n != "output"]
    script = names[0]
    stored = open(os.path.join(d, "output"), "rb").read()
    raw = open(os.path.join(d, script), "rb").read()
    # the store directory name is the sha256 of the script it holds; checking
    # that here is what licenses the origin-name column below
    assert hashlib.sha256(raw).hexdigest() == sha, sha
    src = raw.decode("utf-8", "replace")
    # which stored scripts reach for inputs the run archive does not carry
    needs = sorted(
        {
            token
            for token in ("cache", "blue")
            if ('"%s"' % token) in src
            or ("'%s'" % token) in src
            or ("/%s/" % token) in src
        }
    )
    r = subprocess.run(
        [sys.executable, script], cwd=d, capture_output=True, timeout=120
    )
    same = r.stdout == stored
    if r.returncode != 0:
        status = "CRASH exit=%d" % r.returncode
        crash.append((sha[:8], origin))
    elif same:
        status = "reproduces byte-identical"
        ok.append((sha[:8], origin))
    else:
        status = "EXIT 0 BUT OUTPUT DIFFERS"
        silent_wrong.append((sha[:8], origin))
    if needs:
        reads_run_tree.append((sha[:8], origin, needs))
    print("%s  %-24s %-28s needs=%s" % (sha[:8], origin, status, ",".join(needs) or "-"))

print()
print("reproduce byte-identical .......... %d" % len(ok))
print("exit non-zero (crash) ............. %d" % len(crash))
print("exit 0 with DIFFERENT output ...... %d" % len(silent_wrong))
for sha, origin in silent_wrong:
    print("    silent divergence:", sha, origin)
print("stored scripts naming cache/ or blue/ ... %d" % len(reads_run_tree))
for sha, origin, needs in reads_run_tree:
    print("    needs run tree:", sha, origin, needs)
print()
print("SELF-CONTAINED AND REPRODUCING FROM THE STORE ALONE:")
for sha, origin in ok:
    print("   ", origin)
print("NOT RE-RUNNABLE FROM THE STORE:")
for sha, origin in crash:
    print("    crash:", origin)
for sha, origin in silent_wrong:
    print("    exit 0, wrong answers:", origin)

# What the run archive actually carries, checked rather than recalled.
repo = os.path.dirname(os.path.dirname(RUN))
arc = os.path.join(repo, "run-archive")
print()
if os.path.isdir(arc):
    tars = sorted(n for n in os.listdir(arc) if n.endswith(".tar.gz"))
    print("run-archive tarballs found: %d" % len(tars))
    tops = set()
    for t in tars:
        out = subprocess.run(
            ["tar", "tzf", os.path.join(arc, t)], capture_output=True, text=True
        ).stdout
        for line in out.splitlines():
            parts = [p for p in line.split("/") if p]
            if parts:
                tops.add(parts[0])
    print("top-level entries across all tarballs:", sorted(tops))
    print("archive carries cache/:", "cache" in tops)
    print("archive carries blue/:", "blue" in tops)
else:
    print("run-archive not present at", arc)
