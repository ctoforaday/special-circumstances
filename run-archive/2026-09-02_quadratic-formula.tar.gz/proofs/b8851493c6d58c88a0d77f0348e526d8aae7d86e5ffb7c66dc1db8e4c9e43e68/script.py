#!/usr/bin/env python3
"""
r1_persistence.py  --  blue-respond-r1, answering gap R1-6.

WHAT THIS SETTLES.  The report said the eleven programs were "committed under the
run directory".  Red ran two git commands and found they are not tracked.  This
program runs the same two commands plus three more, so the REPLACEMENT sentence
is written from what the commands return rather than from what anyone believes.

WHAT IS ACTUALLY BEING ASKED.  Not "do the files exist" -- they plainly do -- but
"by what mechanism does a reader outside this container obtain them".  There are
three candidate mechanisms and the program checks each:

  1. git tracking      -- `git ls-files` on the run directory
  2. git ignore status -- `git check-ignore -v` on one script
  3. the run archive   -- does run-archive/ exist, and do archived tarballs of
                          EARLIER runs actually contain .py files?  This is the
                          mechanism the repository's own guide names as the only
                          part of a run that outlives its container.

Mechanism 3 is the one the corrected sentence will rest on, so it is checked
rather than assumed: an archive that carries no scripts would make the corrected
sentence as wrong as the original.

EXIT STATUS.  0 always -- this program REPORTS state; there is no pass/fail, and
recording "the files are gitignored" as a failure would misdescribe it.
"""

import os
import subprocess
import sys
import tarfile

RUN = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
REPO = os.path.abspath(os.path.join(RUN, "..", ".."))
RUNREL = os.path.relpath(RUN, REPO)


def sh(args, cwd=REPO):
    p = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    return p.returncode, p.stdout.strip(), p.stderr.strip()


def main():
    print("=" * 72)
    print("R1-6: by what mechanism do this run's programs leave this container?")
    print(f"repo: {REPO}")
    print(f"run : {RUNREL}")
    print("=" * 72)

    script = os.path.join(RUNREL, "blue/candidates/lane1-proofs/p1_identity.py")
    print(f"\n[1] the file exists on disk: "
          f"{os.path.exists(os.path.join(REPO, script))}")

    rc, out, _ = sh(["git", "check-ignore", "-v", script])
    print(f"\n[2] git check-ignore -v {script}")
    print(f"    exit {rc}  ->  {out or '(no output: not ignored)'}")

    rc, out, _ = sh(["git", "ls-files", RUNREL])
    n = len([l for l in out.splitlines() if l.strip()])
    print(f"\n[3] git ls-files {RUNREL}")
    print(f"    exit {rc}  ->  {n} tracked file(s) under the run directory")

    rc, out, _ = sh(["git", "status", "--porcelain", RUNREL])
    print(f"\n[4] git status --porcelain {RUNREL}")
    print(f"    exit {rc}  ->  {len(out.splitlines())} line(s) "
          f"({'silent, because the path is ignored' if not out else 'see above'})")

    # [5] the archive mechanism, checked rather than assumed
    arch = os.path.join(REPO, "run-archive")
    print(f"\n[5] run-archive/ present: {os.path.isdir(arch)}")
    if os.path.isdir(arch):
        rc, out, _ = sh(["git", "ls-files", "run-archive"])
        tracked = [l for l in out.splitlines() if l.strip()]
        print(f"    tracked entries in run-archive/: {len(tracked)}")
        tarballs = [t for t in tracked if t.endswith((".tar.gz", ".tgz"))]
        print(f"    of which gzipped tarballs: {len(tarballs)}")
        checked = 0
        for t in tarballs[:4]:
            path = os.path.join(REPO, t)
            if not os.path.exists(path):
                continue
            try:
                with tarfile.open(path, "r:gz") as tf:
                    names = tf.getnames()
            except Exception as exc:                      # noqa: BLE001
                print(f"      {t}: unreadable ({exc})")
                continue
            py = [nm for nm in names if nm.endswith(".py")]
            print(f"      {os.path.basename(t)}: {len(names)} entries, "
                  f"{len(py)} .py file(s)")
            if py:
                print(f"        e.g. {py[0]}")
            checked += 1
        if not checked:
            print("      NO archived tarball could be opened here -- so the "
                  "archive mechanism is NOT confirmed from this container")
        # WHICH directories the archive carries. This is the question the
        # original sentence and red's proposed replacement BOTH skip.
        for t in tarballs[:4]:
            path = os.path.join(REPO, t)
            try:
                with tarfile.open(path, "r:gz") as tf:
                    names = tf.getnames()
            except Exception:                              # noqa: BLE001
                continue
            tops = sorted({nm.split("/")[0] for nm in names})
            has_cand = any(nm.startswith("blue/") for nm in names)
            print(f"      {os.path.basename(t)}: top-level dirs {tops}; "
                  f"carries blue/candidates: {has_cand}")

    # [5b] what the record-tool's own proof store holds, in THIS run
    proofs = os.path.join(RUN, "proofs")
    print(f"\n[5b] this run's proofs/ store: {os.path.isdir(proofs)}")
    if os.path.isdir(proofs):
        shas = sorted(os.listdir(proofs))
        # The raw count is NOT printed: recording this very proof changes it,
        # which would make the program's own output move between its two runs
        # and turn a reproducible proof into a mere observation.  What is
        # printed below is membership for the OTHER programs, which is stable.
        print("     store present; each entry holds script.py + its output")
        import hashlib
        def digest(p):
            with open(p, "rb") as fh:
                return hashlib.sha256(fh.read()).hexdigest()
        stored = {}
        for s in shas:
            sp = os.path.join(proofs, s, "script.py")
            if os.path.exists(sp):
                stored.setdefault(digest(sp), []).append(s[:8])
        # SELF-EXCLUSION, printed rather than silent.  This program cannot
        # report its own membership stably: the act of proving it puts it in
        # the store, so the answer would depend on when the question is asked.
        # It is excluded by name and the exclusion is stated.
        SELF = "r1_persistence.py"
        matched, unmatched, skipped = [], [], []
        for sub in ("lane1-proofs", "lane3-proofs", "synth-proofs", "r1-proofs", ""):
            d = os.path.join(RUN, "blue", "candidates", sub)
            if not os.path.isdir(d):
                continue
            for f in sorted(os.listdir(d)):
                if not f.endswith(".py"):
                    continue
                rel = os.path.join("blue/candidates", sub, f).replace("//", "/")
                if f == SELF:
                    skipped.append(rel)
                    continue
                dg = digest(os.path.join(d, f))
                (matched if dg in stored else unmatched).append(rel)
        print(f"     EXCLUDED from the membership tally (cannot report itself "
              f"stably): {skipped}")
        print(f"     programs whose bytes ARE in the proof store  : {len(matched)}")
        for m in matched:
            print(f"       {m}")
        print(f"     programs whose bytes are NOT in the proof store: {len(unmatched)}")
        for u in unmatched:
            print(f"       {u}")

    # [6] what a reader would actually have to be given
    print("\n[6] the programs, as they stand:")
    for sub in ("lane1-proofs", "lane3-proofs", "synth-proofs", "r1-proofs", ""):
        d = os.path.join(RUN, "blue", "candidates", sub)
        if not os.path.isdir(d):
            continue
        pys = sorted(f for f in os.listdir(d) if f.endswith(".py"))
        for f in pys:
            rel = os.path.join("blue/candidates", sub, f).replace("//", "/")
            print(f"    {rel}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
