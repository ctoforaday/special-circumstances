#!/usr/bin/env python3
"""
r1_lane_tags.py  --  blue-respond-r1, answering gap R1-8(a).

WHAT THIS SETTLES.  A line of inquiry was declined on the promise that provenance
would be preserved by TAGGING every report claim that appears in exactly one
lane's draft with that lane's marker.  Red probed three tokens (Forsythe, Kahan,
"1,173"), found all three single-lane and all three in untagged paragraphs, and
said correctly that the enumeration was open: two instances found by probing is
not a measurement of the promise.

So measure it.  This program runs the whole set-difference the tag was supposed to
replace, and prints a COVERAGE RATE rather than anecdotes -- which is what tells
a reader whether the promise was substantially kept, partly kept, or not kept.

METHOD, stated before the numbers because the method is where a flattering
count would hide.
  1. Split blue/report.md into paragraphs; record each paragraph's lane tag
     ("[minority: lane-N/...]" or "[minority: synthesis]") if it has one.
  2. From each paragraph extract DISTINCTIVE TOKENS: capitalised proper names of
     4+ letters, and numeric literals of 3+ characters.  Stop-words that are
     structural rather than evidential (section words, the subject's own name)
     are excluded by an explicit list printed below, so the exclusion is visible
     rather than tuned.
  3. Count each token in lane-1.md, lane-2.md, lane-3.md.
  4. A token found in EXACTLY ONE draft is single-lane by the decline's own
     definition.  Its paragraph should carry that lane's tag.
  5. Report: covered (right tag), untagged, and mis-tagged (a different lane's
     tag), with every miss named so the reader can check any row.

WHAT WOULD FALSIFY THE REPORT'S NEW, NARROWER SENTENCE.  Nothing -- the narrowed
sentence says tags mark claims a lane ORIGINATED and that untagged does not imply
multi-lane.  That is why the number matters anyway: it says how far from total
the tagging actually is, which is the fact a reader needs in order to know how
much to discount an untagged paragraph.

EXIT STATUS.  0.  This program measures; there is no threshold to pass.
"""

import os
import re
import sys
from collections import defaultdict

RUN = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
REPORT = os.path.join(RUN, "blue", "report.md")
DRAFTS = {
    "lane-1": os.path.join(RUN, "blue", "candidates", "lane-1.md"),
    "lane-2": os.path.join(RUN, "blue", "candidates", "lane-2.md"),
    "lane-3": os.path.join(RUN, "blue", "candidates", "lane-3.md"),
}

ANCHOR = re.compile(r"<!--(?:fx|cite|proof):[^>]*-->")
TAGRE = re.compile(r"\[minority:\s*([a-z0-9\-]+)(?:/[^\]]*)?\]")

# Excluded because they are structural or ubiquitous, not evidential.
STOP = {
    "This", "That", "The", "There", "These", "Those", "What", "When", "Where",
    "Which", "While", "With", "Both", "Section", "Analysis", "Verdict", "Loh",
    "Catechism", "Technical", "Computed", "Measured", "Result", "Design",
    "Stated", "Read", "Over", "Work", "Seek", "Their", "Neither", "Every",
    "From", "Against", "Then", "They", "Here", "Even", "Only", "Since",
    "Nothing", "Nobody", "Two", "Three", "Four", "Five", "Six", "Seven",
    "Eleven", "One", "Its", "Under", "Above", "Below", "After", "Before",
    "Loh's", "Quadratic", "Exact", "Coded", "Enumerated", "Widening", "Sharpest",
    "Adoption", "Separate", "Logically", "Absence", "Reflexively", "Doing",
    "Press", "Note", "Findings", "Participants", "Method", "Same", "Half",
}


def paragraphs(text):
    out, cur = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if cur:
                out.append("\n".join(cur))
                cur = []
        else:
            cur.append(line)
    if cur:
        out.append("\n".join(cur))
    return out


def tokens(par):
    names = {w for w in re.findall(r"\b[A-Z][A-Za-zÀ-ɏ']{3,}\b", par)
             if w not in STOP}
    nums = {n for n in re.findall(r"\b\d[\d,\.]{2,}\b", par)}
    return names | nums


def main():
    with open(REPORT, encoding="utf-8") as fh:
        report = ANCHOR.sub("", fh.read())
    drafts = {}
    for k, p in DRAFTS.items():
        with open(p, encoding="utf-8") as fh:
            drafts[k] = fh.read()

    print("=" * 72)
    print("R1-8(a): how total is the single-lane tagging, measured over the whole")
    print("report rather than probed at three tokens?")
    print("=" * 72)
    print(f"excluded stop-words ({len(STOP)}): {' '.join(sorted(STOP))}")

    # SELF-EXCLUSION, declared rather than silent.  The report sentence that
    # STATES this measurement is itself a paragraph of the report, and counting
    # it would make the number depend on the act of reporting it.  The paragraph
    # is identified by the phrase it must contain and is skipped; the count of
    # skipped paragraphs is printed, so a silent zero is impossible.
    SELF = "single-lane distinctive tokens"

    allpars = paragraphs(report)
    pars = [p for p in allpars if SELF not in p]
    print(f"\nself-excluded paragraphs (containing {SELF!r}): "
          f"{len(allpars) - len(pars)}")
    tagcount = defaultdict(int)
    covered, untagged, mistagged = [], [], []
    parcov = {"tagged-right": 0, "untagged": 0, "mistagged": 0}
    seen = set()

    for par in pars:
        m = TAGRE.search(par)
        tag = m.group(1) if m else None
        if tag:
            tagcount[tag] += 1
        for tok in sorted(tokens(par)):
            where = [k for k, body in drafts.items() if tok in body]
            if len(where) != 1:
                continue
            lane = where[0]
            key = (tok, lane)
            if key in seen:
                continue
            seen.add(key)
            row = (tok, lane, tag, par[:70].replace("\n", " "))
            if tag == lane:
                covered.append(row)
            elif tag is None:
                untagged.append(row)
            else:
                mistagged.append(row)

    # PARAGRAPH-LEVEL COVERAGE.  The token rate above is token-weighted: one
    # paragraph carrying nine single-lane numbers counts nine times, so a single
    # untagged data paragraph can dominate the percentage.  The unit a reader
    # actually cares about is the PARAGRAPH -- can I tell which lane originated
    # the claim I am reading -- so both units are printed and the difference
    # between them is part of the finding rather than a choice hidden in a
    # denominator.
    for par in pars:
        m = TAGRE.search(par)
        tag = m.group(1) if m else None
        lanes = set()
        for tok in tokens(par):
            where = [k for k, body in drafts.items() if tok in body]
            if len(where) == 1:
                lanes.add(where[0])
        if not lanes:
            continue
        if tag is None:
            parcov["untagged"] += 1
        elif tag in lanes:
            parcov["tagged-right"] += 1
        else:
            parcov["mistagged"] += 1

    total = len(covered) + len(untagged) + len(mistagged)
    print(f"\nparagraphs in the report: {len(pars)}")
    print(f"lane tags present: {dict(sorted(tagcount.items()))}")
    print(f"\nsingle-lane distinctive tokens found: {total}")
    if total:
        print(f"  in a paragraph carrying THAT lane's tag : {len(covered)} "
              f"({100.0*len(covered)/total:.1f}%)")
        print(f"  in an UNTAGGED paragraph               : {len(untagged)} "
              f"({100.0*len(untagged)/total:.1f}%)")
        print(f"  in a paragraph tagged to ANOTHER lane   : {len(mistagged)} "
              f"({100.0*len(mistagged)/total:.1f}%)")

    for label, rows in (("UNTAGGED", untagged), ("TAGGED TO ANOTHER LANE", mistagged)):
        print(f"\n-- {label} ({len(rows)}) --")
        for tok, lane, tag, ctx in sorted(rows):
            print(f"  {tok:24s} only in {lane}  (paragraph tag: {tag})")
            print(f"      {ctx}...")

    parstot = sum(parcov.values())
    print(f"\nPARAGRAPH-LEVEL (the unit a reader reads): {parstot} paragraph(s) "
          f"carry at least one single-lane token")
    if parstot:
        for k in ("tagged-right", "untagged", "mistagged"):
            print(f"  {k:14s}: {parcov[k]:3d} ({100.0*parcov[k]/parstot:.1f}%)")

    print("\n-- RED'S THREE PROBED TOKENS, RE-RUN --")
    for tok in ("Forsythe", "Kahan", "1,173"):
        where = {k: drafts[k].count(tok) for k in drafts}
        print(f"  {tok:12s} {where}")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
