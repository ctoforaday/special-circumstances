#!/usr/bin/env python3
"""
r1_bridge.py  --  blue-respond-r1, answering gap R1-1.

WHAT THIS SETTLES.  Red minted R1-1 by RUNNING the report's one prescriptive
sentence and finding its sign rule inverted.  This program does the same thing to
the sentence as it now stands, so the fix is checked the same way the defect was
found.  Nothing here is read off the prose by eye: the bridge is transcribed into
`bridge_as_written` as a function of (B, C) with no correction, and the numbers
below are what that function returns.

THE SENTENCE, TRANSCRIBED.  "having found z and hence the root of larger
magnitude r = -B/2 + z (choosing the sign of z to match -B/2), get the other root
as C/r rather than as -B/2 - z."

  z0   = sqrt(B**2/4 - C)                     (the non-negative branch)
  z    = z0 with its sign set to match -B/2   ("choosing the sign of z ...")
  r    = -B/2 + z                             (claimed: larger magnitude)
  other= C / r                                (the product relation)

REFERENCE.  Exact, at 60 significant decimal digits, via `decimal`.  The
discriminant is formed in exact integer arithmetic first (B, C are integers on
this sweep), so the reference is not itself a floating-point computation.

WHAT WOULD FALSIFY THE REPAIRED SENTENCE.  A worst relative error above 1e-15 on
either root at any k, or a division by zero.  Both are what red measured for the
sentence as it stood BEFORE this round; the program prints the old pairing beside
the new one so the difference is visible rather than asserted.

EXIT STATUS.  Non-zero if the repaired sentence fails its own check.  A failing
check is a result, not an error.
"""

import decimal
import math
import sys

decimal.getcontext().prec = 60
D = decimal.Decimal


def bridge_as_written(B, C):
    """The report's sentence, transcribed literally. Double precision."""
    z0 = math.sqrt(B * B / 4.0 - C)
    half = -B / 2.0
    # "choosing the sign of z to match -B/2"
    z = z0 if half >= 0 else -z0
    r = half + z          # "the root of larger magnitude"
    other = C / r         # "get the other root as C/r"
    return r, other


def bridge_old_pairing(B, C):
    """The sentence as it stood before this round: r = -B/2 - z, same sign rule."""
    z0 = math.sqrt(B * B / 4.0 - C)
    half = -B / 2.0
    z = z0 if half >= 0 else -z0
    r = half - z
    other = C / r
    return r, other


def exact_roots(B, C):
    """Exact roots of x^2 + Bx + C at 60 significant digits. B, C integers."""
    disc = D(B) * D(B) - 4 * D(C)
    s = disc.sqrt()
    return ((D(-B) + s) / 2, (D(-B) - s) / 2)


def relerr(approx, exact):
    if exact == 0:
        return abs(D(approx))
    return abs((D(approx) - exact) / exact)


def worst_over(fn, cases):
    """Worst relative error of fn over cases, matching each returned root to its
    nearest exact partner so a route is never charged for root ORDER."""
    worst = D(0)
    rows = []
    for (B, C) in cases:
        try:
            got = fn(B, C)
        except ZeroDivisionError:
            rows.append((B, C, "ZeroDivisionError", None))
            return D(1), rows, True
        ex = exact_roots(B, C)
        # pair each computed root with the exact root it is closest to
        e0, e1 = (ex[0], ex[1]) if abs(D(got[0]) - ex[0]) <= abs(D(got[0]) - ex[1]) else (ex[1], ex[0])
        w = max(relerr(got[0], e0), relerr(got[1], e1))
        rows.append((B, C, got, w))
        if w > worst:
            worst = w
    return worst, rows, False


def main():
    sweep = [(10 ** k, 1) for k in range(1, 11)]
    sweep_neg = [(-(10 ** k), 1) for k in (4, 8)]
    cases = sweep + sweep_neg

    print("=" * 72)
    print("R1-1 acceptance check: the bridge sentence, executed as written")
    print("sweep: a = c = 1, b = 10^k for k = 1..10, plus b = -10^k for k = 4, 8")
    print("=" * 72)

    w_new, rows_new, div_new = worst_over(bridge_as_written, cases)
    print("\n-- THE SENTENCE AS IT NOW STANDS (r = -B/2 + z, sign(z) = sign(-B/2)) --")
    for (B, C, got, w) in rows_new:
        if got == "ZeroDivisionError":
            print(f"  B=1e{int(math.log10(abs(B)))}  DIVISION BY ZERO")
        else:
            print(f"  B={B:>22}  r={got[0]:< 26.17g} other={got[1]:< 26.17g} relerr={w:.3e}")
    print(f"  WORST over all rows: {w_new:.3e}   division-by-zero: {div_new}")

    w_old, rows_old, div_old = worst_over(bridge_old_pairing, cases)
    print("\n-- THE PAIRING RED FOUND AND REJECTED (r = -B/2 - z, same sign rule) --")
    for (B, C, got, w) in rows_old:
        if got == "ZeroDivisionError":
            print(f"  B={B:>22}  DIVISION BY ZERO")
            break
        print(f"  B={B:>22}  r={got[0]:< 26.17g} other={got[1]:< 26.17g} relerr={w:.3e}")
    print(f"  WORST over rows reached: {w_old:.3e}   division-by-zero: {div_old}")

    # Boundary cases the sweep does not reach, asked explicitly.
    print("\n-- BOUNDARY CASES OF THE REPAIRED SENTENCE --")
    boundaries = [
        ("B = 0 (no sign to match; roots are +/-z)", 0, -9),
        ("double root, z = 0 (B^2/4 = C)", 6, 9),
        ("B and C both zero -> r = 0, C/r undefined", 0, 0),
        ("small b, no cancellation regime", 5, 6),
    ]
    boundary_ok = True
    for (label, B, C) in boundaries:
        try:
            got = bridge_as_written(B, C)
            ex = exact_roots(B, C)
            e0, e1 = (ex[0], ex[1]) if abs(D(got[0]) - ex[0]) <= abs(D(got[0]) - ex[1]) else (ex[1], ex[0])
            w = max(relerr(got[0], e0), relerr(got[1], e1))
            print(f"  {label:48s} B={B:<4} C={C:<4} roots={got} relerr={w:.3e}")
        except ZeroDivisionError:
            print(f"  {label:48s} B={B:<4} C={C:<4} ZeroDivisionError "
                  f"(x^2 = 0; the product relation has no content here)")
            if B == 0 and C == 0:
                continue  # declared in the report, not a failure of the sweep
            boundary_ok = False

    ok = (w_new <= D("1e-15")) and not div_new and boundary_ok
    print("\n" + "=" * 72)
    print(f"RESULT: repaired sentence worst relative error {w_new:.3e} "
          f"(threshold 1e-15) -> {'PASS' if ok else 'FAIL'}")
    print(f"        old pairing worst relative error       {w_old:.3e}")
    print("=" * 72)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
