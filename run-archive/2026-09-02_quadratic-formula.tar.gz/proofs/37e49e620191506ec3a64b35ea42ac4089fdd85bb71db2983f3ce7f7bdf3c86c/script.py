#!/usr/bin/env python3
"""
r1_dates.py  --  blue-respond-r1, supporting gap R1-3(b).

WHAT THIS SETTLES.  The report reads meaning into a systematic review's silence
about the method, and frames that silence as "seven years after publication".
The review's instrument could not see seven years: its database searches closed
in May 2025.  Two different intervals are in play and the report was printing
only the longer one.  Both are computed here rather than subtracted in prose,
because a report that says "an instrument saw 5.5 years, not 7" and gets the 5.5
from its author's head is doing the thing it criticises.

INPUTS, each traceable to a document this run holds:
  v1 posted            2019-10-13  (arXiv listing)
  v2 posted            2019-12-16  (arXiv listing)
  review searches ran  2025-05-01  (the review's own Method section: "searches
                                    conducted in May 2025"; the day is not
                                    stated, so the FIRST of the month is used and
                                    the choice is stated here -- it moves the
                                    figure by at most 0.09 years)
  this run             2026-09-03

EXIT STATUS.  0.
"""

import datetime
import sys

V1 = datetime.date(2019, 10, 13)
V2 = datetime.date(2019, 12, 16)
SEARCH_CLOSE = datetime.date(2025, 5, 1)
SEARCH_CLOSE_LATE = datetime.date(2025, 5, 31)
TODAY = datetime.date(2026, 9, 3)
YEAR = 365.2425


def yrs(a, b):
    return (b - a).days / YEAR


def main():
    rows = [
        ("v1 posted -> this run", V1, TODAY),
        ("v2 posted -> this run", V2, TODAY),
        ("v1 posted -> review search close (1 May 2025)", V1, SEARCH_CLOSE),
        ("v1 posted -> review search close (31 May 2025)", V1, SEARCH_CLOSE_LATE),
        ("v2 posted -> review search close (1 May 2025)", V2, SEARCH_CLOSE),
        ("v2 posted -> review search close (31 May 2025)", V2, SEARCH_CLOSE_LATE),
    ]
    print("=" * 72)
    print("R1-3(b): how long could the systematic review's instrument actually see?")
    print("=" * 72)
    for label, a, b in rows:
        print(f"  {label:48s} {(b - a).days:>5} days = {yrs(a, b):.2f} years")
    print()
    lo, hi = yrs(V1, SEARCH_CLOSE), yrs(V1, SEARCH_CLOSE_LATE)
    print(f"  THE FIGURE THE REPORT MUST CARRY: the review's searches could see "
          f"{lo:.1f}-{hi:.1f} years")
    print(f"  of post-v1 literature, not the {yrs(V1, TODAY):.1f} years that have "
          f"now elapsed.")
    print()
    # the specimen the venue explanation cannot cover
    accepted = datetime.date(2026, 5, 26)
    received = datetime.date(2025, 9, 24)
    print(f"  Sen Zeytun 2026: received {received}, accepted {accepted}.")
    print(f"    received is {(received - SEARCH_CLOSE_LATE).days} days AFTER the "
          f"latest possible search close;")
    print(f"    so no database could have indexed it at search time, whatever the "
          f"venue.")
    print("  The two other venues the sentence names carry papers dated 2023 and "
          "2024,")
    print("  both inside the instrument's window, so for those two the venue "
          "explanation")
    print("  is live and is not disturbed by this correction.")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
