#!/usr/bin/env python3
"""R2-5: the named candidate refuter, and what three routes to it returned.

Line of inquiry Q19 was abandoned on a 403 with no URL recorded.  Round 2
located the document, tried the Internet Archive, and this program prints what
came back — so that "unread" is a measured state and not a shrug.

Everything here reads the run cache, so it needs the run tree; where the cache
is absent it says NOT MEASURED rather than printing zeros.
"""

import html
import json
import os
import re

AVAIL = "b2a837a2c33d49e71a151d6c87f19ddad3970960dbef5a5262dda9bee0762e32"
CDX = "9617111fa430cb3194705e40d78d706d7e52cf053a6eb71f959c7cc555a7182a"
SNAP = "ee90ea8d3dce2a9bd63882cfbedc30b8409da9fa89e44f1b853c98b667ee1410"
AVAIL2 = "da867dbccdb45b2b0ebecc020b16f25ba6e72d83bb098fd216a487f6b6a21c67"


def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        p = os.path.dirname(d)
        if p == d:
            raise SystemExit("no run directory found by walking upward")
        d = p


RUN = find_run_dir()
CACHE = os.path.join(RUN, "cache")

print("== R2-5: the Q19 candidate refuter, probed three ways ==")
if not os.path.isdir(CACHE):
    raise SystemExit("NOT MEASURED: the run cache is not present beside this program.")


def rd(sha):
    return open(os.path.join(CACHE, sha), encoding="utf-8", errors="replace").read()


print()
print("ROUTE 1 -- the live document.")
print("  Recorded outside this program: the record tool's fetch of")
print("  medium.com/age-of-awareness/po-shen-lohs-quadratic-method-isn-t-")
print("  groundbreaking-but-that-s-not-the-point-1c3f558e1440 returned HTTP 403,")
print("  which on this egress path is indistinguishable from an origin refusal.")

print()
print("ROUTE 2 -- does the Internet Archive hold it at all?")
a = json.loads(rd(AVAIL))
snap = a["archived_snapshots"]["closest"]
print("  archived_snapshots.closest.status   :", snap["status"])
print("  archived_snapshots.closest.timestamp:", snap["timestamp"])
cdx = json.loads(rd(CDX))
rows = cdx[1:]
print("  CDX captures of this URL, all time  :", len(rows))
for r in rows:
    print("     timestamp %s  status %s  length %s" % (r[1], r[4], r[6]))
a2 = json.loads(rd(AVAIL2))
print("  second candidate essay (jacob-tan-en) snapshots:",
      len(a2.get("archived_snapshots", {})))

print()
print("ROUTE 3 -- what is actually IN the one capture?")
raw = rd(SNAP)
body = re.sub(r"<(script|style)\b.*?</\1>", " ", raw, flags=re.S | re.I)
text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]*>", " ", body))).strip()
print("  bytes of HTML fetched from the capture:", len(raw))
print("  characters of extracted visible text  :", len(text))
print("  the whole of that extracted text:")
print("   ", text)
print()
for term in ("Brozinsky", "cut-the-knot", "Bogomolny", "Savage", "quadratic",
             "Loh"):
    print("  occurrences of %-13s in the capture's text: %d"
          % (term, text.lower().count(term.lower())))
print()
print("READING: the capture is Medium's JavaScript shell plus Wayback chrome.")
print("The article body is not in it, so the essay remains UNREAD from here —")
print("located, named, and blocked, which is a different state from not found.")
