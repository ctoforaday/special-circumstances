#!/usr/bin/env python3
"""R3-2: the apparatus, counted by a program instead of by hand.

Three rounds running, a hand-authored program count shipped wrong, and each
round's repair described a re-derivation that was already stale against a file
sitting in the directory it listed. This is the durable fix available from this
seat: the total comes from the filesystem, the sub-counts come from the
directory layout, and the membership arithmetic the apparatus section asserts is
CHECKED here rather than asserted there.

Cheap by construction — it walks two directories and hashes nothing — so it fits
inside the proof harness's 60-second cap. The re-runnability replay it used to
carry lives in r3_store_replay.py, which does not fit and says so.
"""

import os

OVER_CAP = ("p2_assumption.py", "q3_factorability.py", "r3_store_replay.py")


def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        p = os.path.dirname(d)
        if p == d:
            raise SystemExit("no run directory found by walking upward")
        d = p


RUN = find_run_dir()
CAND = os.path.join(RUN, "blue", "candidates")
STORE = os.path.join(RUN, "proofs")

print("== R3-2: the apparatus census ==")
if not os.path.isdir(CAND):
    raise SystemExit(
        "NOT MEASURED: blue/candidates/ is not present beside this program, so "
        "the file census cannot be taken. This is a refusal, not a zero.")

# ------------------------------------------------------------ (1) the files
groups = {}
for root, _dirs, files in os.walk(CAND):
    for f in sorted(files):
        if f.endswith(".py"):
            rel = os.path.relpath(root, CAND)
            groups.setdefault(rel if rel != "." else "(top level)", []).append(f)
total = sum(len(v) for v in groups.values())
print()
print("(1) PROGRAMS ON DISK UNDER blue/candidates/")
for g in sorted(groups):
    print("  %-16s %2d  %s" % (g, len(groups[g]), ", ".join(sorted(groups[g]))))
print("  %-16s %2d" % ("TOTAL", total))

LANES = sum(len(v) for g, v in groups.items()
            if g.startswith("lane") or g == "(top level)")
subs = [("from the lanes", LANES)]
for g, label in (("synth-proofs", "written at synthesis"),
                 ("r1-proofs", "written in round 1"),
                 ("r2-proofs", "written in round 2"),
                 ("r3-proofs", "written in round 3")):
    subs.append((label, len(groups.get(g, []))))
print()
print("  the sub-counts the report states, computed here rather than recalled:")
for label, n in subs:
    print("    %-24s %d" % (label + ":", n))
print("    %-24s %d" % ("sum of the sub-counts:", sum(n for _, n in subs)))
print("    %-24s %s" % ("sum == total:", sum(n for _, n in subs) == total))

# ------------------------------------------------- (2) the store, and the sum
import hashlib

entries = sorted(os.listdir(STORE)) if os.path.isdir(STORE) else []
on_disk = {}
for root, _dirs, files in os.walk(CAND):
    for f in files:
        if f.endswith(".py"):
            fp = os.path.join(root, f)
            on_disk[hashlib.sha256(open(fp, "rb").read()).hexdigest()] = f
matched, superseded = [], []
for sha in entries:
    d = os.path.join(STORE, sha)
    names = [n for n in sorted(os.listdir(d)) if n != "output"]
    if not names:
        continue
    h = hashlib.sha256(open(os.path.join(d, names[0]), "rb").read()).hexdigest()
    (matched if h in on_disk else superseded).append(on_disk.get(h, sha[:8]))
print()
print("(2) THE PROOF STORE, AND THE MEMBERSHIP ARITHMETIC THE APPARATUS ASSERTS")
print("  programs that CANNOT be deposited, because they exceed the proof")
print("  harness's 60-second cap on a single run:")
for name in OVER_CAP:
    print("    -", name)
print("  programs on disk %d, minus %d over the cap, leaves %d eligible for the"
      % (total, len(OVER_CAP), total - len(OVER_CAP)))
print("  store.")
print()
print("  store entries                                     :", len(entries))
print("  entries whose script matches a program on disk now:", len(matched))
print("  entries with no on-disk counterpart (SUPERSEDED   :", len(superseded))
print("    versions left behind by a re-deposit)             ", sorted(superseded))
print()
print("  TWO STEPS OF THIS ROUTE CHANGE THE ANSWER AND ARE THEREFORE STATED.")
print("  First, this program is deposited AFTER it runs, so its own entry is not")
print("  in the matched count above. Second, a program re-deposited after a")
print("  repair leaves its earlier version in the store, so the ENTRY count is")
print("  not the PROGRAM count and the reconciliation runs on the latter.")
print("    matched + 1 (this program) == on disk - over cap  ->  %d == %d  ->  %s"
      % (len(matched) + 1, total - len(OVER_CAP),
         len(matched) + 1 == total - len(OVER_CAP)))

# ------------------------------------------------------- (3) the fetch count
idx = os.path.join(RUN, "cache", "index")
print()
print("(3) DOCUMENTS FETCHED INTO THE RUN CACHE")
if not os.path.exists(idx):
    print("  NOT MEASURED: cache/index is absent beside this program, which the")
    print("  run archive does not carry. This is a refusal, not a zero.")
else:
    import json
    urls, files = set(), set()
    for line in open(idx, encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        rec = json.loads(line)
        urls.add(rec["url"])
        files.add(rec["sha"])
    print("  distinct URLs recorded in cache/index :", len(urls))
    print("  distinct cached artifacts (by sha)    :", len(files))
    print("  the two differ because two URLs can return identical bytes — the")
    print("  JSTOR bot-challenge page is the report's own example — so the URL")
    print("  count is the number of FETCHES the run committed to the cache and")
    print("  the sha count is the number of distinct documents it holds.")
    print("  NOTE: web SEARCHES leave no cache entry, so neither number counts")
    print("  them, and the report's figure for searches is not derivable here.")
