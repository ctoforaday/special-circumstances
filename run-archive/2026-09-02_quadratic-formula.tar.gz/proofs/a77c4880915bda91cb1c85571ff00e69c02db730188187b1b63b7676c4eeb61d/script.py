#!/usr/bin/env python3
"""P3 - "computationally light" as a number instead of an adjective.

Counting convention, stated before counting (the convention is where a
dishonest comparison would hide, so it is code, not prose):

  * every arithmetic operation actually executed on a NUMBER is counted, by
    instrumenting the number type itself: add, sub, mul, div, neg, sqrt;
  * a literal times a variable (4*a) is one multiplication;
  * squaring is one multiplication;
  * one square-root extraction is counted separately, since it dominates cost;
  * operations on the COEFFICIENTS supplied by the problem are counted; nothing
    is counted for writing a symbol down.

Each route is written out as the procedure a student would actually execute,
and the count is whatever the instrumented type observes.  The three routes are
run on the same instances, and their outputs are checked to agree, so a route
cannot look cheap by computing something else.
"""
from math import sqrt

COUNT = {}


def reset():
    COUNT.clear()
    for k in ("add", "sub", "mul", "div", "neg", "sqrt"):
        COUNT[k] = 0


class N:
    __slots__ = ("v",)

    def __init__(self, v):
        self.v = float(v)

    def _t(self, k):
        COUNT[k] += 1

    def __add__(self, o):
        self._t("add")
        return N(self.v + _v(o))

    def __sub__(self, o):
        self._t("sub")
        return N(self.v - _v(o))

    def __mul__(self, o):
        self._t("mul")
        return N(self.v * _v(o))

    def __rmul__(self, o):
        self._t("mul")
        return N(_v(o) * self.v)

    def __truediv__(self, o):
        self._t("div")
        return N(self.v / _v(o))

    def __rtruediv__(self, o):
        self._t("div")
        return N(_v(o) / self.v)

    def __neg__(self):
        self._t("neg")
        return N(-self.v)

    def __repr__(self):
        return "N(%r)" % self.v


def _v(o):
    return o.v if isinstance(o, N) else float(o)


def rt(x):
    COUNT["sqrt"] += 1
    return N(sqrt(_v(x)))


def total():
    return sum(COUNT.values())


# ---------------- the three routes, as executed procedures ----------------

def route_formula(a, b, c):
    """Textbook closed form: x = (-b +/- sqrt(b^2-4ac)) / (2a)."""
    D = b * b - 4 * a * c
    s = rt(D)
    den = 2 * a
    return ((-b + s) / den, (-b - s) / den)


def route_completing_square(a, b, c):
    """Completing the square executed as a procedure (not as a memorised formula):
    divide to monic, halve the linear coefficient, square it, take the root."""
    B = b / a
    C = c / a
    h = B / 2
    E = h * h - C
    v = rt(E)
    return (-h + v, -h - v)


def route_loh(a, b, c):
    """Loh: divide to monic; roots are -B/2 +/- z where z^2 = B^2/4 - C."""
    B = b / a
    C = c / a
    m = -(B / 2)          # the average of the two roots
    z = rt(m * m - C)     # product condition, rearranged
    return (m + z, m - z)


def route_completing_square_hoisted(a, b, c):
    """Completing the square written with the negation hoisted, exactly as Loh's
    route writes it. Included to show that the one-operation gap between the two
    rows above is a transcription choice, not a property of either method."""
    B = b / a
    C = c / a
    m = -(B / 2)
    v = rt(m * m - C)
    return (m + v, m - v)


ROUTES = [("textbook closed formula", route_formula),
          ("completing the square, as a procedure", route_completing_square),
          ("completing the square, negation hoisted", route_completing_square_hoisted),
          ("Loh (average of roots, then product)", route_loh)]

INSTANCES = [(1.0, -7.0, 12.0), (2.0, -4.0, -6.0), (0.5, -1.0, -12.0), (3.0, 5.0, 1.0)]

print("operation counts, general quadratic a*x^2 + b*x + c = 0")
print("%-40s %5s %5s %5s %5s %5s %6s %7s" %
      ("route", "add", "sub", "mul", "div", "neg", "sqrt", "TOTAL"))
counts = {}
for name, fn in ROUTES:
    reset()
    fn(N(1.0), N(-7.0), N(12.0))
    counts[name] = (dict(COUNT), total())
    print("%-40s %5d %5d %5d %5d %5d %6d %7d" %
          (name, COUNT["add"], COUNT["sub"], COUNT["mul"], COUNT["div"],
           COUNT["neg"], COUNT["sqrt"], total()))

print()
print("same three routes on an ALREADY MONIC quadratic x^2 + Bx + C = 0")
print("(a = 1, so the two divisions by a are still executed by the monic routes;")
print(" the row below re-counts them with the division-by-a step skipped)")


def route_cs_monic(B, C):
    h = B / 2
    v = rt(h * h - C)
    return (-h + v, -h - v)


def route_loh_monic(B, C):
    m = -(B / 2)
    z = rt(m * m - C)
    return (m + z, m - z)


def route_formula_monic(B, C):
    D = B * B - 4 * 1 * C
    s = rt(D)
    return ((-B + s) / 2, (-B - s) / 2)


for name, fn in [("textbook closed formula (a=1)", route_formula_monic),
                 ("completing the square (a=1)", route_cs_monic),
                 ("Loh (a=1)", route_loh_monic)]:
    reset()
    fn(N(-7.0), N(12.0))
    print("%-40s %5d %5d %5d %5d %5d %6d %7d" %
          (name, COUNT["add"], COUNT["sub"], COUNT["mul"], COUNT["div"],
           COUNT["neg"], COUNT["sqrt"], total()))

print()
agree = True
for (a, b, c) in INSTANCES:
    outs = []
    for name, fn in ROUTES:
        reset()
        r = fn(N(a), N(b), N(c))
        outs.append(sorted(_v(t) for t in r))
    for o in outs[1:]:
        if max(abs(o[i] - outs[0][i]) for i in (0, 1)) > 1e-9 * max(1.0, abs(outs[0][0])):
            agree = False
print("all three routes returned the same roots on %d instances: %s"
      % (len(INSTANCES), agree))

f_total = counts["textbook closed formula"][1]
cs_total = counts["completing the square, as a procedure"][1]
cs_h_total = counts["completing the square, negation hoisted"][1]
loh_total = counts["Loh (average of roots, then product)"][1]
print()
print("READING (general a): Loh %d operations, completing the square %d as usually "
      "written and %d with the negation hoisted the way Loh writes it, textbook "
      "closed formula %d." % (loh_total, cs_total, cs_h_total, f_total))
print("Loh vs completing the square as usually written: %d operation(s) apart. "
      "Loh vs completing the square written the same way: %d apart -- i.e. the gap "
      "between the two derivations is a transcription choice."
      % (abs(loh_total - cs_total), abs(loh_total - cs_h_total)))
print("Loh vs the textbook closed formula: %d operations apart, and that gap is "
      "real: the closed formula recomputes b^2-4ac and 2a instead of reusing the "
      "monic coefficients." % abs(loh_total - f_total))
raise SystemExit(0 if agree else 1)
