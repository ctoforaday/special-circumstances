#!/usr/bin/env python3
"""
r1_recount.py  --  blue-respond-r1, answering gap R1-2.

WHAT THIS SETTLES.  Three counts the report states over its own fetch cache.  Red
found two of them wrong and named a third as no longer re-derivable.  This
program re-derives all three from the cached bytes, by a method it names, and
prints the enumeration rather than a bare total -- so a reader can see WHICH
entries were counted, not just how many.

WHY THE OLD NUMBERS WERE WRONG (the mechanism, tested rather than assumed).  The
PDF text extractor glues a page number onto the reference entry that starts a
page: v1 carries the line "6[8] Descartes".  A count anchored to line start
(`^\\[[0-9]+\\]`) therefore drops exactly one entry per page break and returns a
plausible, wrong number.  Leg (a) prints BOTH counts so the size of that bias is
visible instead of asserted.

WHAT IT READS.  Only files already in this run's fetch cache, located through
<run>/cache/index by URL.  Nothing is re-fetched.  If a URL is absent from the
index the program fails loudly rather than reporting a silent zero -- a regex
that matches nothing and a file that was never fetched produce the same integer,
and only one of them is evidence.

EXIT STATUS.  Non-zero if any source is missing from the cache.
"""

import json
import os
import re
import sys

RUN = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
CACHE = os.path.join(RUN, "cache")
INDEX = os.path.join(CACHE, "index")


def load_index():
    m = {}
    with open(INDEX) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rec = json.loads(line)
                m[rec["url"]] = rec["sha"]
    return m


def read_cached(idx, url, prefer_text=True):
    if url not in idx:
        print(f"  !! NOT IN CACHE: {url}")
        return None, None
    sha = idx[url]
    txt = os.path.join(CACHE, sha + ".txt")
    raw = os.path.join(CACHE, sha)
    path = txt if (prefer_text and os.path.exists(txt)) else raw
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read(), sha


TAG = re.compile(r"<[^>]+>")
SCRIPT = re.compile(r"<(script|style)\b.*?</\1>", re.S | re.I)


def strip_tags(s):
    return TAG.sub(" ", SCRIPT.sub(" ", s))


def leg_a(idx):
    print("=" * 72)
    print("LEG (a)  numbered reference entries in each cached arXiv text layer")
    print("METHOD: scan for '[N]' ANYWHERE on a line (not anchored to line start),")
    print("        collect the integers, and report the set and its size.")
    print("=" * 72)
    ok = True
    results = {}
    for label, url in (("v1", "https://arxiv.org/pdf/1910.06709v1"),
                       ("v2", "https://arxiv.org/pdf/1910.06709v2")):
        body, sha = read_cached(idx, url)
        if body is None:
            ok = False
            continue
        # the References section only: everything from the last 'References' heading
        m = list(re.finditer(r"^\s*References\s*$", body, re.M | re.I))
        section = body[m[-1].end():] if m else body
        anywhere = sorted({int(n) for n in re.findall(r"\[(\d+)\]", section)})
        anchored = len(re.findall(r"^\[\d+\]", section, re.M))
        gaps = [n for n in range(1, max(anywhere) + 1) if n not in anywhere] if anywhere else []
        glued = re.findall(r"^\d+\[\d+\][^\n]{0,32}", section, re.M)
        print(f"\n  {label}  sha {sha[:8]}")
        print(f"    entries found by the stated method : {len(anywhere)}  "
              f"({min(anywhere)}..{max(anywhere)}, gaps: {gaps or 'none'})")
        print(f"    entries found by a line-anchored count: {anchored}   <- the biased method")
        print(f"    page-number-glued lines that explain the difference: {len(glued)}")
        for g in glued:
            print(f"      {g!r}")
        results[label] = len(anywhere)
    print(f"\n  REPORT MUST SAY: v1 {results.get('v1')} entries, v2 {results.get('v2')} entries")
    return ok, results


def leg_b(idx):
    print("\n" + "=" * 72)
    print("LEG (b)  the phrase 'zero-product' across the five cached poshenloh.com pages")
    print("METHOD: strip HTML tags, lowercase, count the literal string.")
    print("=" * 72)
    pages = [
        "https://www.poshenloh.com/quadratic/",
        "https://poshenloh.com/quadraticdetail",
        "https://poshenloh.com/quadraticrelated",
        "https://poshenloh.com/quadraticcompsqr",
        "https://poshenloh.com/quadraticlogicexist",
    ]
    ok = True
    nonzero = []
    for url in pages:
        body, sha = read_cached(idx, url, prefer_text=False)
        if body is None:
            ok = False
            continue
        n = strip_tags(body).lower().count("zero-product")
        print(f"  {url:44s} sha {sha[:8]}  count {n}")
        if n:
            nonzero.append(url)
    # and the two preprint versions, for the contrasting zero
    for label, url in (("v1", "https://arxiv.org/pdf/1910.06709v1"),
                       ("v2", "https://arxiv.org/pdf/1910.06709v2")):
        body, sha = read_cached(idx, url)
        if body is None:
            ok = False
            continue
        low = body.lower()
        print(f"  preprint {label:38s} sha {sha[:8]}  count "
              f"{low.count('zero-product')} (hyphenated) / "
              f"{low.count('zero product')} (spaced)")
    print(f"\n  REPORT MUST SAY: {len(nonzero)} of the 5 companion pages carry the phrase")
    for u in nonzero:
        print(f"      {u}")
    return ok, len(nonzero)


def leg_c(idx):
    print("\n" + "=" * 72)
    print("LEG (c)  term counts in the cached Gustafsson 2026 systematic review")
    print("METHOD: strip HTML tags, lowercase, count the literal substring.")
    print("        Substring, not word: 'quadratics' and 'quadratic equations'")
    print("        both contain 'quadratic', and the figure's job is to show the")
    print("        fetch was not empty, so the wider count is the honest one.")
    print("=" * 72)
    url = "https://link.springer.com/article/10.1007/s10649-026-10493-6"
    body, sha = read_cached(idx, url, prefer_text=False)
    if body is None:
        print("  !! the review is not in the cache under any known URL")
        return False, None
    prose = strip_tags(body).lower()                 # script/style DROPPED first
    naive = TAG.sub(" ", body).lower()               # tags removed, script BODIES kept
    raw = body.lower()                               # nothing removed at all
    counts = {t: prose.count(t) for t in ("quadratic", "loh", "po-shen", "may 2025")}
    print(f"  {url}\n  sha {sha[:8]}")
    print("  THE FIGURE IS METHOD-DEPENDENT AND HERE ARE THE THREE METHODS:")
    print(f"    'quadratic', script/style bodies DROPPED   : {prose.count('quadratic')}")
    print(f"    'quadratic', tags stripped, scripts KEPT   : {naive.count('quadratic')}")
    print(f"    'quadratic', raw bytes, nothing stripped   : {raw.count('quadratic')}")
    inscript = sum(m.group(0).lower().count("quadratic")
                   for m in SCRIPT.finditer(body))
    print(f"    occurrences INSIDE <script>/<style> blocks : {inscript}")
    for t in ("loh", "po-shen"):
        print(f"    {t!r:14s} prose {prose.count(t)} / scripts-kept {naive.count(t)} "
              f"/ raw {raw.count(t)}")
    words = re.findall(r"[a-z\-]+", prose)
    print(f"    'loh' as a whole word in prose: {sum(1 for w in words if w == 'loh')}")
    print(f"    'po-shen' as a whole word in prose: {sum(1 for w in words if w == 'po-shen')}")
    print(f"    'may 2025' in prose: {prose.count('may 2025')}")
    return True, counts


def main():
    idx = load_index()
    ok_a, ref = leg_a(idx)
    ok_b, pages = leg_b(idx)
    ok_c, gust = leg_c(idx)
    print("\n" + "=" * 72)
    print("SUMMARY OF THE THREE FIGURES THE REPORT MUST CARRY")
    print(f"  reference entries per version : {ref}")
    print(f"  companion pages with 'zero-product' : {pages} of 5")
    print(f"  'quadratic' in the review : {gust['quadratic'] if gust else 'n/a'}, "
          f"'loh' {gust['loh'] if gust else 'n/a'}")
    print("=" * 72)
    return 0 if (ok_a and ok_b and ok_c) else 1


if __name__ == "__main__":
    sys.exit(main())
