#!/usr/bin/env python3
"""S1 - the hypothesis-coincidence enumeration, on a range that finishes inside the
proof harness's 60-second cap.

This is a REDUCED-RANGE companion to blue/candidates/lane1-proofs/p2_assumption.py,
which enumerates odd n from 3 to 121 (60 rings) and takes about two minutes on this
container.  The logic here is the same and is written out independently; only the
bound changes.  Everything is exhaustive: every element, every coefficient pair, no
sampling.

Three properties, over a commutative ring R = Z/n:

  SQRTC  every square has exactly the square roots {w, -w}
         (the fact completing the square states out loud, per arXiv:1910.06709v2 fn.3)
  ZPD    xy = 0 implies x = 0 or y = 0
         (the zero-product property, the fact the Loh route uses silently)
  LOHC   for every monic quadratic and every admissible z, the two numbers -B/2 +/- z
         with the right sum and product are ALL the roots
         (the step 'a factorisation exhibits all the roots')

Exits non-zero if any two of them disagree on any ring, so a future failure is loud.
"""
import sys


def divisors_ok(n):
    """-B/2 must exist for every B, i.e. 2 must be invertible mod n."""
    return n % 2 == 1


def sqrtc(n):
    for w in range(n):
        sq = (w * w) % n
        roots = {v for v in range(n) if (v * v) % n == sq}
        if roots != {w % n, (-w) % n}:
            return False
    return True


def zpd(n):
    for a in range(1, n):
        for b in range(1, n):
            if (a * b) % n == 0:
                return False
    return True


def lohc(n):
    """For every monic x^2 + Bx + C over Z/n and every z with z^2 = B^2/4 - C,
    the pair {-B/2 + z, -B/2 - z} must be exactly the root set."""
    inv2 = pow(2, -1, n)
    for B in range(n):
        for C in range(n):
            truth = {x for x in range(n) if (x * x + B * x + C) % n == 0}
            half = (-B * inv2) % n
            target = (half * half - C) % n
            for z in range(n):
                if (z * z) % n != target:
                    continue
                got = {(half + z) % n, (half - z) % n}
                if got != truth:
                    return False, (B, C, z, got, truth)
    return True, None


def is_prime(n):
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True


def main():
    NMAX = 41
    odd = [n for n in range(3, NMAX + 1) if divisors_ok(n)]
    print("S1 PART 1: odd rings Z/n, n = 3 .. %d  (%d rings)" % (NMAX, len(odd)))
    print("  odd because both derivations form -B/2, so 2 must be invertible")
    print()
    print("    n   prime   ZPD  SQRTC   LOHC")
    rows = []
    for n in odd:
        p, z, s = is_prime(n), zpd(n), sqrtc(n)
        l, witness = lohc(n)
        rows.append((n, p, z, s, l, witness))
        print("  %3d   %5s %5s  %5s  %5s%s" % (
            n, p, z, s, l,
            "" if witness is None else
            "   first failure B=%d C=%d z=%d gives %s, truth %s" % witness))

    n_z = sum(1 for r in rows if r[2])
    n_s = sum(1 for r in rows if r[3])
    n_l = sum(1 for r in rows if r[4])
    dis_zs = [r[0] for r in rows if r[2] != r[3]]
    dis_zl = [r[0] for r in rows if r[2] != r[4]]
    dis_sl = [r[0] for r in rows if r[3] != r[4]]
    dis_pz = [r[0] for r in rows if r[1] != r[2]]
    print()
    print("  ZPD holds in %d of %d; SQRTC in %d; LOHC in %d" % (n_z, len(rows), n_s, n_l))
    print("  disagreements ZPD/SQRTC: %d %s" % (len(dis_zs), dis_zs))
    print("  disagreements ZPD/LOHC : %d %s" % (len(dis_zl), dis_zl))
    print("  disagreements SQRTC/LOHC: %d %s" % (len(dis_sl), dis_sl))
    print("  disagreements with primality of n: %d %s" % (len(dis_pz), dis_pz))

    print()
    print("S1 PART 2: the even case, where 2 is NOT invertible and NEITHER route runs")
    even_sep = []
    for n in range(4, 61, 2):
        if sqrtc(n) and not zpd(n):
            even_sep.append(n)
    print("  even n <= 60 where SQRTC holds but the zero-product property fails: %d %s"
          % (len(even_sep), even_sep))
    all_2p = all(m % 2 == 0 and is_prime(m // 2) and m // 2 % 2 == 1 for m in even_sep)
    print("  every one of them is n = 2p with p an odd prime: %s" % all_2p)
    print("  there -B/2 does not exist for odd B, so neither completing the square nor")
    print("  the Loh route is writable, and the separation is an artefact of the ring.")

    print()
    print("CHECKS")
    ok = True
    for label, cond in [
        ("S1a. the three properties coincide on every odd ring tested",
         not dis_zs and not dis_zl and not dis_sl),
        ("S1b. and each coincides with primality of the modulus", not dis_pz),
        ("S1c. the even separation is real and is confined to n = 2p", bool(even_sep) and all_2p),
    ]:
        print("  %s %s" % ("PASS" if cond else "FAIL", label))
        ok = ok and cond
    print()
    print("all checks passed" if ok else "CHECKS FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
