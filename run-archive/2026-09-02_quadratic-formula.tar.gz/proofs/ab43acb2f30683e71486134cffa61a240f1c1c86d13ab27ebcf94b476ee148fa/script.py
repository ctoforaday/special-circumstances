#!/usr/bin/env python3
"""
q1_v1v2_diff.py  --  blue-lane-3

WHAT THIS SETTLES.  Blue lane 2's draft characterises the arXiv v1 -> v2 revision
of Loh, "A Simple Proof of the Quadratic Formula" (arXiv:1910.06709) with a
seven-row table.  Seven is a COUNT, and a curated count is not the same object as
a measured one: a reader cannot tell from the table whether seven is the whole
revision or the seven the drafter found interesting.  This program measures the
revision mechanically and prints the numbers, so the report can say how much of
the change the seven rows cover.

INPUTS.  The two PDFs were fetched into this run's cache by an earlier seat and
their text layers extracted by the record tool's fetcher
(github.com/klippa-app/go-pdfium).  This script reads those extracted text files
by their cache SHA-256, which is how the run identifies a fetched artifact; the
mapping from URL to SHA is in <run>/cache/index.  Nothing here re-fetches, so the
bytes are the same bytes every other seat read.

  https://arxiv.org/pdf/1910.06709v1 -> a8cd0e04...b6940c2 (wrong; see index)
Actual SHAs are read from cache/index at run time, so a re-fetch that changes a
SHA makes this script fail loudly rather than silently read the wrong file.

METHOD, and its limits, stated before the numbers.
  * The comparison is on PDF-EXTRACTED TEXT, not on LaTeX source.  Extraction
    breaks displayed mathematics into fragments ("x", "2 + Bx + C ..."), so a
    line-level diff over-reports change in the mathematical displays.  To keep
    that out of the headline, the script reports TWO measurements:
      (a) a raw line-level diff, which is an upper bound on real change; and
      (b) a diff restricted to PROSE SENTENCES -- units of >= 40 characters that
          contain at least four alphabetic words -- which is where the claims
          live and where extraction is stable.
  * The reference lists are compared as SETS of bracketed entries, which is
    exact: reference entries survive extraction intact.
No claim in the report should rest on (a) alone.
"""

import difflib
import json
import os
import re
import sys

RUN = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
CACHE = os.path.join(RUN, "cache")
INDEX = os.path.join(CACHE, "index")

WANT = {
    "v1": "https://arxiv.org/pdf/1910.06709v1",
    "v2": "https://arxiv.org/pdf/1910.06709v2",
}


def load_texts():
    sha = {}
    with open(INDEX, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            for tag, url in WANT.items():
                if rec.get("url") == url:
                    sha[tag] = rec["sha"]
    missing = [t for t in WANT if t not in sha]
    if missing:
        sys.exit("cache/index has no entry for: %s" % missing)
    out = {}
    for tag, s in sha.items():
        path = os.path.join(CACHE, s + ".txt")
        if not os.path.exists(path):
            sys.exit("extracted text missing for %s at %s" % (tag, path))
        out[tag] = open(path, encoding="utf-8", errors="replace").read()
        print("  %s  cache sha %s  %d chars of extracted text" % (tag, s[:12], len(out[tag])))
    return out


WORDY = re.compile(r"[A-Za-z]{2,}")


def prose_units(text):
    """Sentence-ish prose units: join the extraction's hard-wrapped lines into a
    single stream, split on sentence enders, keep units that look like prose."""
    flat = re.sub(r"\s+", " ", text)
    parts = re.split(r"(?<=[.!?]) ", flat)
    keep = []
    for p in parts:
        p = p.strip()
        if len(p) >= 40 and len(WORDY.findall(p)) >= 4:
            keep.append(p)
    return keep


REF = re.compile(r"\[(\d{1,2})\]\s+([^\[]{10,400})")


def refs(text):
    """Reference-list entries, keyed by the surname-ish head of the entry so a
    renumbering between versions does not read as a change of content."""
    tail = text[text.rfind("References"):] if "References" in text else text
    out = {}
    for num, body in REF.findall(tail):
        body = re.sub(r"\s+", " ", body).strip()
        head = body.split(".")[0].strip()
        out[head] = (int(num), body[:120])
    return out


def main():
    print("=" * 72)
    print("Q1. arXiv:1910.06709 v1 -> v2, measured rather than characterised")
    print("=" * 72)
    t = load_texts()
    v1, v2 = t["v1"], t["v2"]

    # ---- (a) raw line-level diff: UPPER BOUND, includes math-extraction noise
    l1 = [l.rstrip() for l in v1.splitlines() if l.strip()]
    l2 = [l.rstrip() for l in v2.splitlines() if l.strip()]
    sm = difflib.SequenceMatcher(None, l1, l2, autojunk=False)
    ops = [o for o in sm.get_opcodes() if o[0] != "equal"]
    print("\n(a) RAW LINE DIFF  -- upper bound; includes broken-up mathematics")
    print("    v1 non-blank lines: %d" % len(l1))
    print("    v2 non-blank lines: %d" % len(l2))
    print("    changed regions   : %d" % len(ops))
    print("    similarity ratio  : %.4f" % sm.ratio())

    # ---- (b) prose-sentence diff: the units in which claims are made
    p1, p2 = prose_units(v1), prose_units(v2)
    s1, s2 = set(p1), set(p2)
    only1 = [p for p in p1 if p not in s2]
    only2 = [p for p in p2 if p not in s1]
    print("\n(b) PROSE-SENTENCE DIFF  -- units >=40 chars with >=4 alphabetic words")
    print("    v1 prose units            : %d" % len(p1))
    print("    v2 prose units            : %d" % len(p2))
    print("    present in v1, absent v2  : %d" % len(only1))
    print("    present in v2, absent v1  : %d" % len(only2))
    print("    unchanged prose units     : %d" % len(s1 & s2))
    pct = 100.0 * len(s1 & s2) / len(s1) if s1 else 0.0
    print("    %% of v1 prose carried over: %.1f%%" % pct)

    # near-matches: v1 sentences that were EDITED rather than deleted
    edited, deleted = [], []
    pool = list(only2)
    for a in only1:
        best, bestr = None, 0.0
        for b in pool:
            r = difflib.SequenceMatcher(None, a, b).ratio()
            if r > bestr:
                best, bestr = b, r
        if bestr >= 0.60:
            edited.append((a, best, bestr))
            pool.remove(best)
        else:
            deleted.append(a)
    print("    of those v1 units: %d EDITED (>=0.60 similar to a v2 unit), %d DELETED outright"
          % (len(edited), len(deleted)))
    print("    v2 units with no v1 counterpart (NEW prose): %d" % len(pool))

    # Stratify the edits.  PDF text extraction glues page numbers onto the next
    # word and re-hyphenates across line breaks, so a "change" at similarity
    # 0.98 is usually the extractor, not the author.  Anything the report says
    # about the SIZE of the revision must be quoted from the strict stratum.
    typo = [e for e in edited if e[2] >= 0.95]
    subst = [e for e in edited if e[2] < 0.95]
    print("    edit stratification: %d at similarity >=0.95 (typographic or"
          " extraction noise), %d below 0.95 (substantive candidates)"
          % (len(typo), len(subst)))
    print("    STRICT COUNT of author-level prose changes"
          " = substantive edits + deletions + new = %d + %d + %d = %d"
          % (len(subst), len(deleted), len(pool),
             len(subst) + len(deleted) + len(pool)))

    print("\n    --- EDITED sentences, in full (v1 then v2) ---")
    for i, (a, b, r) in enumerate(sorted(edited, key=lambda e: -e[2]), 1):
        print("    [E%02d] sim=%.2f" % (i, r))
        print("      v1: %s" % a[:300])
        print("      v2: %s" % b[:300])

    print("\n    --- DELETED sentences (in v1, no close v2 counterpart) ---")
    for i, a in enumerate(deleted, 1):
        print("    [D%02d] %s" % (i, a[:300]))

    print("\n    --- NEW sentences (in v2, no close v1 counterpart) ---")
    for i, b in enumerate(pool, 1):
        print("    [N%02d] %s" % (i, b[:300]))

    # ---- (c) reference lists, compared as sets
    r1, r2 = refs(v1), refs(v2)
    added = [k for k in r2 if k not in r1]
    removed = [k for k in r1 if k not in r2]
    print("\n(c) REFERENCE LISTS, compared as sets of entries")
    print("    v1 entries: %d" % len(r1))
    print("    v2 entries: %d" % len(r2))
    print("    added in v2 (%d):" % len(added))
    for k in added:
        print("      + [%d] %s" % (r2[k][0], r2[k][1]))
    print("    removed in v2 (%d):" % len(removed))
    for k in removed:
        print("      - [%d] %s" % (r1[k][0], r1[k][1]))

    # ---- (d) targeted word counts on the originality vocabulary
    print("\n(d) ORIGINALITY VOCABULARY, counted (case-insensitive, whole word)")
    for w in ["new", "novel", "independently", "surprising", "surprisingly",
              "Savage", "Gowers", "converse", "no evidence"]:
        pat = re.compile(r"(?i)\b" + re.escape(w) + r"\b")
        print("    %-14s v1=%2d  v2=%2d" % (w, len(pat.findall(v1)), len(pat.findall(v2))))

    # ---- assertions the report will lean on
    print("\nCHECKS")
    ok = True

    def check(name, cond, detail=""):
        nonlocal ok
        print("  %-6s %s %s" % ("PASS" if cond else "FAIL", name, detail))
        ok = ok and cond

    check("R1. v2 adds Savage to the reference list, v1 has none",
          any("Savage" in k for k in added) and not any("Savage" in k for k in r1),
          "(added=%s)" % [k for k in added if "Savage" in k])
    check("R2. the word 'new' is less frequent in v2 than in v1",
          len(re.findall(r"(?i)\bnew\b", v2)) < len(re.findall(r"(?i)\bnew\b", v1)),
          "(v1=%d v2=%d)" % (len(re.findall(r"(?i)\bnew\b", v1)),
                             len(re.findall(r"(?i)\bnew\b", v2))))
    check("R3. 'no evidence of it in English sources' is in v1 and gone from v2",
          "no evidence of it in English" in re.sub(r"\s+", " ", v1)
          and "no evidence of it in English" not in re.sub(r"\s+", " ", v2))
    check("R4. footnote-1 converse language is in v2 and absent from v1",
          "does not rely on the theorem that two roots" in re.sub(r"\s+", " ", v2)
          and "does not rely on the theorem that two roots" not in re.sub(r"\s+", " ", v1))
    check("R5. the revision touches MORE than seven prose sentences",
          len(edited) + len(deleted) + len(pool) > 7,
          "(edited %d + deleted %d + new %d = %d)"
          % (len(edited), len(deleted), len(pool), len(edited) + len(deleted) + len(pool)))
    print("\n%s" % ("all checks passed" if ok else "SOME CHECKS FAILED -- read them above"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
