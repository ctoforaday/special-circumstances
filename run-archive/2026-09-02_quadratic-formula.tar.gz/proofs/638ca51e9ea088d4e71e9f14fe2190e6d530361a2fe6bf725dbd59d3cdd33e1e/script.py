#!/usr/bin/env python3
"""P1 - Exact symbolic check that the Loh derivation and completing the square
reduce to the SAME scalar equation, via the substitution x = -B/2 + z.

No computer algebra system is installed in this container, so a minimal exact
multivariate polynomial arithmetic over the rationals is implemented here.
Variables: x, B, C, z, a, b, c, s  (s is a formal square root of b^2-4ac).
Every check below is an exact identity test (all coefficients zero), not a
numerical spot check.
"""
from fractions import Fraction as F
from itertools import product

VARS = ("x", "B", "C", "z", "a", "b", "c", "s")
IDX = {v: i for i, v in enumerate(VARS)}
N = len(VARS)
ZERO_E = (0,) * N


def poly(d=None):
    return dict(d or {})


def const(k):
    k = F(k)
    return {} if k == 0 else {ZERO_E: k}


def var(name):
    e = [0] * N
    e[IDX[name]] = 1
    return {tuple(e): F(1)}


def add(*ps):
    out = {}
    for p in ps:
        for e, c in p.items():
            out[e] = out.get(e, F(0)) + c
            if out[e] == 0:
                del out[e]
    return out


def neg(p):
    return {e: -c for e, c in p.items()}


def sub(p, q):
    return add(p, neg(q))


def mul(*ps):
    out = const(1)
    for p in ps:
        new = {}
        for e1, c1 in out.items():
            for e2, c2 in p.items():
                e = tuple(x + y for x, y in zip(e1, e2))
                new[e] = new.get(e, F(0)) + c1 * c2
                if new[e] == 0:
                    del new[e]
        out = new
    return out


def smul(k, p):
    k = F(k)
    return {} if k == 0 else {e: c * k for e, c in p.items()}


def is_zero(p):
    return len(p) == 0


def reduce_s(p):
    """Rewrite s^2 -> b^2 - 4ac repeatedly (s is a formal square root)."""
    rel = sub(mul(var("b"), var("b")), smul(4, mul(var("a"), var("c"))))
    changed = True
    while changed:
        changed = False
        for e, coeff in list(p.items()):
            k = e[IDX["s"]]
            if k >= 2:
                rest = list(e)
                rest[IDX["s"]] = k - 2
                term = {tuple(rest): coeff}
                p = add(sub(p, {e: coeff}), mul(term, rel))
                changed = True
                break
    return p


x, B, C, z = var("x"), var("B"), var("C"), var("z")
a, b, c, s = var("a"), var("b"), var("c"), var("s")
half = F(1, 2)
quarter = F(1, 4)

results = []


def check(name, p, note=""):
    ok = is_zero(p)
    results.append((name, ok, note))
    print(("PASS " if ok else "FAIL ") + name + ((" | " + note) if note else ""))
    return ok


# --- 1. Completing the square is an identity of polynomials in x, B, C.
lhs = add(mul(x, x), mul(B, x), C)
cts = sub(mul(add(x, smul(half, B)), add(x, smul(half, B))),
          sub(smul(quarter, mul(B, B)), C))
check("CTS-identity: x^2+Bx+C == (x+B/2)^2 - (B^2/4 - C)", sub(lhs, cts))

# --- 2. Loh's trial factorisation expands to a monic quadratic whose linear
#        coefficient is B for EVERY z (the sum condition is automatic) and whose
#        constant term is B^2/4 - z^2.
R = add(smul(-half, B), z)          # -B/2 + z
S = sub(smul(-half, B), z)          # -B/2 - z
loh = mul(sub(x, R), sub(x, S))
target = add(mul(x, x), mul(B, x), sub(smul(quarter, mul(B, B)), mul(z, z)))
check("LOH-identity: (x-(-B/2+z))(x-(-B/2-z)) == x^2+Bx+(B^2/4 - z^2)",
      sub(loh, target))

# --- 3. The two routes' scalar conditions are the SAME equation.
#        CTS (after u := x+B/2):  u^2 - (B^2/4 - C) = 0
#        Loh (product condition): (B^2/4 - z^2) - C = 0  ->  z^2 - (B^2/4 - C) = 0
u = var("z")  # rename: the same single unknown
cts_cond = sub(mul(u, u), sub(smul(quarter, mul(B, B)), C))
loh_cond = neg(sub(sub(smul(quarter, mul(B, B)), mul(z, z)), C))
check("SAME-EQUATION: CTS condition u^2-(B^2/4-C) == Loh condition z^2-(B^2/4-C)",
      sub(cts_cond, loh_cond),
      "identical as polynomials; the substitution x = -B/2 + z carries one to the other")

# --- 4. The substitution really is x = -B/2 + z: substituting into x^2+Bx+C
#        gives exactly z^2 - (B^2/4 - C).
def subst_x(p, repl):
    out = {}
    for e, coeff in p.items():
        k = e[IDX["x"]]
        rest = list(e)
        rest[IDX["x"]] = 0
        term = mul({tuple(rest): coeff}, *([repl] * k)) if k else {tuple(rest): coeff}
        out = add(out, term)
    return out

depressed = subst_x(lhs, add(smul(-half, B), z))
check("DEPRESSION: (x^2+Bx+C)|_{x=-B/2+z} == z^2 - (B^2/4 - C)",
      sub(depressed, sub(mul(z, z), sub(smul(quarter, mul(B, B)), C))))

# --- 5. The general-a formula: (-b + s)/(2a) with s^2 = b^2-4ac is a root of
#        ax^2+bx+c.  Cleared of denominators: 4a*(a x^2+bx+c) with x=(-b+s)/(2a)
#        equals (-b+s)^2 + 2b(-b+s) + 4ac, which must reduce to 0.
for sign, label in ((1, "+"), (-1, "-")):
    t = add(neg(b), smul(sign, s))          # -b (+/-) s
    expr = add(mul(t, t), smul(2, mul(b, t)), smul(4, mul(a, c)))
    check("ROOT-CHECK: x=(-b%ss)/(2a) satisfies ax^2+bx+c=0" % label,
          reduce_s(expr), "verified modulo s^2 = b^2-4ac")

# --- 6. Loh's monic route (divide by a first) and the textbook formula have the
#        same radicand.  Stated without division: if b = aB and c = aC, then
#        b^2 - 4ac  must equal  4a^2 * (B^2/4 - C).
#        Verified by substituting b -> a*B and c -> a*C into b^2-4ac.
def subst(p, name, repl):
    out = {}
    for e, coeff in p.items():
        k = e[IDX[name]]
        rest = list(e)
        rest[IDX[name]] = 0
        term = {tuple(rest): coeff}
        if k:
            term = mul(term, *([repl] * k))
        out = add(out, term)
    return out

textbook_rad = sub(mul(b, b), smul(4, mul(a, c)))          # b^2 - 4ac
textbook_rad_sub = subst(subst(textbook_rad, "b", mul(a, B)), "c", mul(a, C))
loh_rad_scaled = smul(4, mul(a, a, sub(smul(quarter, mul(B, B)), C)))  # 4a^2(B^2/4 - C)
check("RADICAND: (b^2-4ac)|_{b=aB, c=aC} == 4a^2*(B^2/4 - C)",
      sub(textbook_rad_sub, loh_rad_scaled),
      "so the two routes take the square root of the same quantity, up to the factor (2a)^2")

# --- 7. End-to-end exact run of both routes, as PROCEDURES, on every monic
#        instance with integer B,C in [-20,20] whose radicand is a rational
#        square (so exact arithmetic can finish without radicals).  Each route
#        is coded separately, and both the agreement of the two root SETS and
#        the exact vanishing of the polynomial at each root are checked.
def exact_sqrt(q):
    """exact square root of a non-negative Fraction, or None."""
    if q < 0:
        return None
    from math import isqrt
    n, d = q.numerator, q.denominator
    rn, rd = isqrt(n), isqrt(d)
    return F(rn, rd) if rn * rn == n and rd * rd == d else None

def route_cts(Bv, Cv):
    """completing the square: (x+B/2)^2 = B^2/4 - C, then x = -B/2 +/- sqrt."""
    E = Bv * Bv / 4 - Cv
    r = exact_sqrt(E)
    return None if r is None else {-Bv / 2 + r, -Bv / 2 - r}

def route_loh(Bv, Cv):
    """Loh: seek z with (-B/2+z)(-B/2-z) = C, i.e. z^2 = B^2/4 - C; roots -B/2 +/- z."""
    zsq = Bv * Bv / 4 - Cv
    zz = exact_sqrt(zsq)
    if zz is None:
        return None
    R_, S_ = -Bv / 2 + zz, -Bv / 2 - zz
    assert R_ + S_ == -Bv and R_ * S_ == Cv      # sum/product actually verified
    return {R_, S_}

tested = agreed = 0
for bb in range(-20, 21):
    for cc in range(-20, 21):
        Bv, Cv = F(bb), F(cc)
        A_, L_ = route_cts(Bv, Cv), route_loh(Bv, Cv)
        if A_ is None or L_ is None:
            continue
        tested += 1
        vanish = all(rt * rt + Bv * rt + Cv == 0 for rt in A_ | L_)
        if A_ == L_ and vanish:
            agreed += 1
grid_ok = (tested > 0 and agreed == tested)
note7 = "%d rational-square instances run through both procedures; %d agreed" % (tested, agreed)
results.append(("END-TO-END: both routes return identical exact root sets", grid_ok, note7))
print(("PASS " if grid_ok else "FAIL ") +
      "END-TO-END: both routes return identical exact root sets | " + note7)

n_pass = sum(1 for _, ok, _ in results if ok)
print("\nSUMMARY: %d/%d checks passed" % (n_pass, len(results)))
raise SystemExit(0 if n_pass == len(results) else 1)
