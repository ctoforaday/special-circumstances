#!/usr/bin/env python3
"""
q2_field_invariant.py  --  blue-lane-3

WHAT THIS SETTLES, and how it differs from blue lane 1's p2_assumption.py.

Loh's footnote 3 (arXiv:1910.06709v2) claims an asymmetry between the two
derivations:

  "this step of completing the square uses the fact that the complete set of
   solutions to x^2 = K is {+-sqrt(K)} ... In contrast, our approach only
   requires that there exists an explicit choice of x which satisfies x^2 = K."

Lane 1 tested that over the rings Z/n and concluded the two facts "hold in
exactly the same rings, and both are exactly primality of the modulus."  That is
a true statement about Z/n and it is NOT yet the general statement, because Z/n
is a thin family: every non-field Z/n with n odd fails for one of two different
reasons (a zero divisor from two prime factors, or a nilpotent from a repeated
prime factor) and the family cannot distinguish "is a field" from "n is prime".

This program widens the family to four constructions -- Z/n, the finite fields
GF(p^k), the split ring GF(p) x GF(p) (zero divisors, no nilpotents), and the
dual-number ring GF(p)[t]/(t^2) (a nilpotent, no idempotents) -- and tests, on
every monic quadratic over every ring in the family, three properties:

  ZPD           the zero-product property: uv = 0 implies u = 0 or v = 0.
                This is the fact Loh's route uses, and he names it himself in
                the companion page (poshenloh.com/quadraticdetail): "The formal
                justification of this zero-product property uses the basic axiom
                that you can divide by any nonzero number".
  SQRTCOMPLETE  for every element K that is a square, the set {x : x^2 = K} is
                exactly {w, -w} for some w.  This is the fact footnote 3 says
                completing the square uses.
  LOHSOUND      the Loh procedure -- pick any z with z^2 = B^2/4 - C, return
                {-B/2 + z, -B/2 - z}, or "no roots" if no such z exists --
                returns exactly the true root set, for EVERY monic quadratic
                over the ring.

The hypothesis under test: the three coincide, and coincide with "the ring is a
field", across all four constructions.  If they do, Loh's asymmetry is a
difference in which step STATES the hypothesis, not in which hypothesis is
needed -- a real pedagogical claim and not a logical one.

A finite commutative ring in which 2 is invertible either is a field, or fails
both facts, and the argument is short enough to check by hand: if R is not a
field it has a nonzero non-unit, so (being finite) it has either two coprime
idempotent factors -- and then 1 has at least four square roots (+-1, +-e-(1-e))
-- or a nonzero nilpotent n with n^2 = 0, and then 0 has square roots 0 and n
while {+-sqrt(0)} = {0}.  The enumeration below is what makes that checkable
rather than asserted; the two constructions GF(p) x GF(p) and GF(p)[t]/(t^2) are
in the family precisely because they are the two cases of that argument.
"""

import itertools
import sys


# ---------- ring interface: elements are opaque hashables; ops are callbacks


class Ring:
    def __init__(self, name, elements, add, mul, neg, zero, one):
        self.name = name
        self.elements = list(elements)
        self.add = add
        self.mul = mul
        self.neg = neg
        self.zero = zero
        self.one = one

    def sub(self, a, b):
        return self.add(a, self.neg(b))

    def units(self):
        us = {}
        for a in self.elements:
            for b in self.elements:
                if self.mul(a, b) == self.one:
                    us[a] = b
                    break
        return us

    def half(self):
        """the inverse of 2, if it exists"""
        two = self.add(self.one, self.one)
        return self.units().get(two)

    def is_field(self):
        us = self.units()
        return len(us) == len(self.elements) - 1 and self.zero not in us


def Zn(n):
    els = list(range(n))
    return Ring("Z/%d" % n, els, lambda a, b: (a + b) % n, lambda a, b: (a * b) % n,
                lambda a: (-a) % n, 0, 1)


def GF(p, k, modpoly):
    """GF(p^k) as GF(p)[x]/(modpoly); modpoly is a list of coefficients, monic,
    length k+1, low degree first.  Elements are k-tuples."""
    els = [tuple(t) for t in itertools.product(range(p), repeat=k)]

    def add(a, b):
        return tuple((x + y) % p for x, y in zip(a, b))

    def neg(a):
        return tuple((-x) % p for x in a)

    def mul(a, b):
        prod = [0] * (2 * k - 1)
        for i, x in enumerate(a):
            for j, y in enumerate(b):
                prod[i + j] = (prod[i + j] + x * y) % p
        for d in range(len(prod) - 1, k - 1, -1):
            c = prod[d]
            if c:
                prod[d] = 0
                for i in range(k):
                    prod[d - k + i] = (prod[d - k + i] - c * modpoly[i]) % p
        return tuple(prod[:k])

    zero = tuple([0] * k)
    one = tuple([1] + [0] * (k - 1))
    return Ring("GF(%d^%d)" % (p, k), els, add, mul, neg, zero, one)


def Split(p):
    """GF(p) x GF(p): zero divisors, no nonzero nilpotents"""
    els = [(a, b) for a in range(p) for b in range(p)]
    return Ring("GF(%d)xGF(%d)" % (p, p), els,
                lambda a, b: ((a[0] + b[0]) % p, (a[1] + b[1]) % p),
                lambda a, b: ((a[0] * b[0]) % p, (a[1] * b[1]) % p),
                lambda a: ((-a[0]) % p, (-a[1]) % p), (0, 0), (1, 1))


def Dual(p):
    """GF(p)[t]/(t^2): a nonzero nilpotent, no nontrivial idempotents"""
    els = [(a, b) for a in range(p) for b in range(p)]
    return Ring("GF(%d)[t]/(t^2)" % p, els,
                lambda a, b: ((a[0] + b[0]) % p, (a[1] + b[1]) % p),
                lambda a, b: ((a[0] * b[0]) % p, (a[0] * b[1] + a[1] * b[0]) % p),
                lambda a: ((-a[0]) % p, (-a[1]) % p), (0, 0), (1, 0))


# ---------- the three properties


def zpd(R):
    for a in R.elements:
        if a == R.zero:
            continue
        for b in R.elements:
            if b != R.zero and R.mul(a, b) == R.zero:
                return False
    return True


def sqrt_complete(R):
    roots = {}
    for x in R.elements:
        roots.setdefault(R.mul(x, x), []).append(x)
    for K, rs in roots.items():
        w = rs[0]
        if set(rs) != {w, R.neg(w)}:
            return False
    return True


def true_roots(R, B, C):
    out = []
    for x in R.elements:
        if R.add(R.add(R.mul(x, x), R.mul(B, x)), C) == R.zero:
            out.append(x)
    return set(out)


def loh_roots(R, B, C, half):
    """pick ANY z with z^2 = B^2/4 - C; return {-B/2+z, -B/2-z} or None"""
    m = R.neg(R.mul(half, B))                 # -B/2
    D = R.sub(R.mul(R.mul(half, B), R.mul(half, B)), C)   # B^2/4 - C
    for z in R.elements:
        if R.mul(z, z) == D:
            return {R.add(m, z), R.sub(m, z)}
    return set()                              # procedure reports: no roots


def loh_sound(R, half):
    """true for the ring iff the procedure is right on EVERY monic quadratic,
    for EVERY admissible choice of z (not just the first one found)"""
    for B in R.elements:
        for C in R.elements:
            truth = true_roots(R, B, C)
            m = R.neg(R.mul(half, B))
            D = R.sub(R.mul(R.mul(half, B), R.mul(half, B)), C)
            zs = [z for z in R.elements if R.mul(z, z) == D]
            if not zs:
                if truth:
                    return False, (B, C, "procedure says no roots; truth has %d" % len(truth))
                continue
            for z in zs:
                got = {R.add(m, z), R.sub(m, z)}
                if got != truth:
                    return False, (B, C, "z=%r gives %r, truth %r" % (z, got, truth))
    return True, None


def main():
    print("=" * 74)
    print("Q2. Which hypothesis does each derivation actually need?")
    print("    (the family is widened past Z/n so that 'is a field' and")
    print("     'the modulus is prime' can be told apart)")
    print("=" * 74)

    rings = []
    for n in range(3, 40, 2):          # odd moduli only: 2 must be invertible
        rings.append(Zn(n))
    rings += [GF(3, 2, [1, 0]),        # x^2+1 irreducible over GF(3) -> GF(9)
              GF(5, 2, [2, 0]),        # x^2+2 irreducible over GF(5) -> GF(25)
              GF(3, 3, [1, 2, 0])]     # x^3+2x+1 over GF(3) -> GF(27)
    rings += [Split(p) for p in (3, 5, 7)]
    rings += [Dual(p) for p in (3, 5, 7)]

    print("\n%-18s %5s %6s %6s %6s %6s  %s" %
          ("ring", "|R|", "field", "ZPD", "SQRTC", "LOH", "note"))
    rows = []
    for R in rings:
        h = R.half()
        if h is None:
            print("%-18s  2 is not invertible -- neither derivation is writable" % R.name)
            continue
        f = R.is_field()
        z = zpd(R)
        s = sqrt_complete(R)
        ls, why = loh_sound(R, h)
        note = "" if (f == z == s == ls) else "*** DISAGREEMENT ***"
        if why and not ls:
            note += "  first failure B=%r C=%r %s" % why
        rows.append((R.name, len(R.elements), f, z, s, ls, note))
        print("%-18s %5d %6s %6s %6s %6s  %s" %
              (R.name, len(R.elements), f, z, s, ls, note))

    print("\nCHECKS")
    ok = True

    def check(name, cond, detail=""):
        nonlocal ok
        print("  %-4s %s %s" % ("PASS" if cond else "FAIL", name, detail))
        ok = ok and cond

    disagree = [r for r in rows if not (r[2] == r[3] == r[4] == r[5])]
    check("F1. on every ring tested, is-a-field == zero-product == sqrt-complete == Loh-sound",
          not disagree, "(%d rings tested, %d disagreements)" % (len(rows), len(disagree)))

    split_rows = [r for r in rows if "x" in r[0]]
    dual_rows = [r for r in rows if "t^2" in r[0]]
    check("F2. the split rings (zero divisors, no nilpotents) fail all three",
          all((not r[2]) and (not r[3]) and (not r[4]) and (not r[5]) for r in split_rows),
          "(%d rings)" % len(split_rows))
    check("F3. the dual-number rings (a nilpotent, no idempotents) fail all three",
          all((not r[2]) and (not r[3]) and (not r[4]) and (not r[5]) for r in dual_rows),
          "(%d rings)" % len(dual_rows))
    gf_rows = [r for r in rows if r[0].startswith("GF(") and "x" not in r[0] and "t^2" not in r[0]]
    check("F4. the non-prime-order finite fields GF(p^k) pass all three",
          all(r[2] and r[3] and r[4] and r[5] for r in gf_rows),
          "(%d rings: %s)" % (len(gf_rows), ", ".join(r[0] for r in gf_rows)))
    check("F5. so the invariant is 'the ring is a field', not 'the modulus is prime'",
          all(r[2] and r[5] for r in gf_rows) and len(gf_rows) >= 2)

    # the existence-free half of footnote 1, checked where it actually bites:
    # over a field that is NOT algebraically closed, the procedure must return
    # the empty set exactly when the quadratic is irreducible.
    print("\nFOOTNOTE-1 CHECK: over GF(p), 'no z exists' must mean 'no roots exist',")
    print("and the count of rootless monic quadratics must be p(p-1)/2.")
    for p in (3, 5, 7, 11, 13, 17, 19, 23):
        R = Zn(p)
        h = R.half()
        rootless_truth = sum(1 for B in R.elements for C in R.elements
                             if not true_roots(R, B, C))
        rootless_proc = sum(1 for B in R.elements for C in R.elements
                            if not loh_roots(R, B, C, h))
        want = p * (p - 1) // 2
        good = rootless_truth == rootless_proc == want
        print("  GF(%2d): rootless by enumeration %4d, by the procedure %4d, p(p-1)/2 = %4d  %s"
              % (p, rootless_truth, rootless_proc, want, "PASS" if good else "FAIL"))
        ok = ok and good

    print("\n%s" % ("all checks passed" if ok else "SOME CHECKS FAILED -- read them above"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
