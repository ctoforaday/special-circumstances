#!/usr/bin/env python3
"""S2 - the guess-and-check factorability density, on a range that finishes inside the
proof harness's 60-second cap.

This is a REDUCED-RANGE companion to blue/candidates/lane3-proofs/q3_factorability.py,
which runs the same enumeration out to N = 1600 (10,246,401 coefficient pairs) and takes
about five minutes on this container.  The logic here is written out independently; only
the largest box changes.

A monic quadratic x^2 + Bx + C with integer coefficients has rational roots exactly when
its discriminant B^2 - 4C is a non-negative perfect square.  That criterion is CHECKED
against brute-force rational-root search before it is used, because a criterion asserted
is a criterion that can be wrong.
"""
import math
import sys


def is_square(m):
    if m < 0:
        return False
    r = math.isqrt(m)
    return r * r == m


def factorable_by_criterion(B, C):
    return is_square(B * B - 4 * C)


def factorable_by_search(B, C):
    """Rational root theorem: any rational root of a monic integer polynomial is an
    integer dividing C.  C = 0 is handled separately (x = 0 is a root)."""
    if C == 0:
        return True
    m = abs(C)
    for d in range(1, m + 1):
        if m % d:
            continue
        for cand in (d, -d):
            if cand * cand + B * cand + C == 0:
                return True
    return False


def main():
    print("S2 PART 0: validate the criterion against brute-force search, |B|,|C| <= 12")
    bad = []
    for B in range(-12, 13):
        for C in range(-12, 13):
            if factorable_by_criterion(B, C) != factorable_by_search(B, C):
                bad.append((B, C))
    print("  disagreements: %d %s" % (len(bad), bad[:5]))

    print()
    print("S2 PART 1: monic x^2 + Bx + C, B and C uniform on [-N, N]")
    print("       N   factorable         total     density")
    rows = []
    for N in (5, 20, 100, 200):
        cnt = 0
        for B in range(-N, N + 1):
            bb = B * B
            for C in range(-N, N + 1):
                if is_square(bb - 4 * C):
                    cnt += 1
        total = (2 * N + 1) ** 2
        rows.append((N, cnt, total, cnt / total))
        print("  %6d   %10d   %11d   %9.5f" % (N, cnt, total, cnt / total))

    print()
    print("S2 PART 2: the corrected model, density = (ln N + c) / (2N)")
    print("  (a first version of the sibling script PREDICTED a power law N^-1/2 and the")
    print("   data REFUTED it; the model below is what the data actually fit)")
    for N, cnt, total, dens in rows:
        implied = 2 * N * dens - math.log(N)
        print("  N = %5d  density = %.5f  implied c = %.4f" % (N, dens, implied))
    implied_big = [2 * N * d - math.log(N) for N, _, _, d in rows if N >= 100]
    spread = max(implied_big) - min(implied_big)
    print("  spread of implied c over N >= 100: %.4f" % spread)

    print()
    print("CHECKS")
    ok = True
    d100 = [r for r in rows if r[0] == 100][0]
    d200 = [r for r in rows if r[0] == 200][0]
    for label, cond in [
        ("S2a. the perfect-square criterion agrees with brute-force search everywhere tested",
         not bad),
        ("S2b. fewer than 10%% of monic integer quadratics with |B|,|C| <= 100 factor over Q (%.5f)"
         % d100[3], d100[3] < 0.10),
        ("S2c. the density is still falling at N = 200 (%.5f < %.5f)" % (d200[3], d100[3]),
         d200[3] < d100[3]),
        ("S2d. the implied c of the ln(N)/N model is stable over N >= 100 (spread %.4f)" % spread,
         spread < 0.05),
    ]:
        print("  %s %s" % ("PASS" if cond else "FAIL", label))
        ok = ok and cond
    print()
    print("all checks passed" if ok else "CHECKS FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
