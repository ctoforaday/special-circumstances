#!/usr/bin/env python3
"""R3-1: the Medium essay was in this run's cache all along — recover it.

Round 2 reported the Internet Archive capture of Matthew Yuan's essay as a
JavaScript shell with "no article body", and the report said so at five sites.
That reading was produced by a recipe that deletes <script> BODIES before
searching, and this document is a client-rendered Medium page: the article text
travels inside window.__APOLLO_STATE__, i.e. inside exactly what the recipe
deletes.  This program:

  (1) reproduces round 2's figure, so the two readings can be compared;
  (2) recovers the article from the same cached bytes and prints it whole;
  (3) counts the report's five decisive absence terms over BOTH the
      transformed text and the untransformed bytes;
  (4) re-derives the capture count under an exact-match CDX query and under a
      prefix-matched one, for both Medium URLs, from the cached CDX answers;
  (5) cross-checks the recovery against a SECOND cached capture; and
  (6) executes the essay's own statement of the method, which as written
      solves a different quadratic from the one it names.

Run directory is resolved by walking UPWARD for a directory holding both
records/ and proofs/, so this runs identically from blue/candidates/r3-proofs/
and from proofs/<sha>/ — though it needs cache/, which the run archive does not
carry, and it says NOT MEASURED rather than printing zeros when that is absent.
"""

import html
import json
import os
import re
from fractions import Fraction
from math import isqrt

SNAP1 = "ee90ea8d3dce2a9bd63882cfbedc30b8409da9fa89e44f1b853c98b667ee1410"
SNAP2 = "a6451c614873efdd"
CDX_EXACT = "9617111fa430cb3194705e40d78d706d7e52cf053a6eb71f959c7cc555a7182a"
CDX_PREFIX = "8ca59110daae8532c6c9df3b061d73816ea3d748cd8b10cd67674eb36ee7e545"
CDX_PREFIX_2 = "37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570"

TERMS = ("Brozinsky", "cut-the-knot", "Bogomolny", "Savage", "Gowers")


def find_run_dir():
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.isdir(os.path.join(d, "records")) and os.path.isdir(
            os.path.join(d, "proofs")
        ):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise SystemExit("no run directory found by walking upward")
        d = parent


RUN = find_run_dir()
CACHE = os.path.join(RUN, "cache")

print("== R3-1: recovering the article body from the capture this run holds ==")
if not os.path.isdir(CACHE):
    raise SystemExit("NOT MEASURED: the run cache is not present beside this program.")


def resolve(prefix):
    """The cache is keyed by full sha256; accept a prefix and resolve it."""
    hits = [n for n in sorted(os.listdir(CACHE)) if n.startswith(prefix)]
    hits = [n for n in hits if not n.endswith(".txt")]
    if len(hits) != 1:
        raise SystemExit("cache prefix %s resolves to %d files" % (prefix, len(hits)))
    return os.path.join(CACHE, hits[0])


def raw_bytes(prefix):
    return open(resolve(prefix), "rb").read()


def visible_text(doc):
    """Round 2's recipe, reproduced exactly: drop script/style BODIES, strip
    tags, unescape entities, collapse whitespace."""
    body = re.sub(r"<(script|style)\b.*?</\1>", " ", doc, flags=re.S | re.I)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]*>", " ", body))).strip()


def apollo_paragraphs(doc):
    """Every Paragraph record in the embedded Apollo store, in document order.

    The records are values of keys of the form "Paragraph:<id>", so this finds
    the key, then brace-matches the object with a string-aware scanner rather
    than a regex, and parses each with json.loads.
    """
    out = []
    for m in re.finditer(r'"Paragraph:[^"]+":\{', doc):
        start = m.end() - 1
        depth, i, in_str, esc = 0, start, False, False
        while i < len(doc):
            ch = doc[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        out.append(json.loads(doc[start:i + 1]))
                        break
            i += 1
    return out


# ---------------------------------------------------------------- (1) counts
blob = raw_bytes(SNAP1)
decoded = blob.decode("utf-8", "replace")
text_mode = open(resolve(SNAP1), encoding="utf-8", errors="replace").read()

print()
print("(1) THREE COUNTS OF ONE FILE, WHICH IS WHERE THE 79,219 CAME FROM")
print("  len(bytes) on disk                          :", len(blob))
print("  len(decoded str), utf-8 with replacement     :", len(decoded))
print("  len(str) read in TEXT mode (newlines folded) :", len(text_mode))
print("  CRLF pairs in the file                       :", blob.count(b"\r\n"))
print("  bytes - decoded chars (multibyte sequences)  :", len(blob) - len(decoded))
print("  decoded - text mode (== CRLF pairs folded)   :", len(decoded) - len(text_mode))
print("  READING: 79,219 is neither the byte count nor the decoded character")
print("  count; it is the character count after universal-newline translation.")

# ------------------------------------------------------- (2) round 2's recipe
vis = visible_text(decoded)
print()
print("(2) ROUND 2's RECIPE, REPRODUCED")
print("  characters of visible text after dropping script/style bodies:", len(vis))
print("  first 120 characters:", vis[:120])

# ------------------------------------------------------------ (3) the article
paras = apollo_paragraphs(decoded)
recovered = "\n".join(p.get("text") or "" for p in paras)
print()
print("(3) THE ARTICLE, RECOVERED FROM THE SAME BYTES")
print("  offset of window.__APOLLO_STATE__ in the decoded document:",
      decoded.find("__APOLLO_STATE__"))
print("  Paragraph records found:", len(paras))
print("  characters of article text in those records:",
      sum(len(p.get("text") or "") for p in paras))
print("  characters of the joined article (one newline per record):",
      len(recovered))
print("  by record type:", json.dumps(
    {t: sum(1 for p in paras if p.get("type") == t)
     for t in sorted({p.get("type") for p in paras})}, sort_keys=True))
print()
for p in paras:
    print("  [%s] %s" % (p.get("type"), p.get("text")))

# ----------------------------------------------------- (4) the absence counts
print()
print("(4) THE REPORT'S DECISIVE ABSENCE TERMS, COUNTED THREE WAYS")
print("  %-14s %10s %10s %10s" % ("term", "visible", "article", "raw"))
for term in TERMS:
    print("  %-14s %10d %10d %10d" % (
        term,
        vis.lower().count(term.lower()),
        recovered.lower().count(term.lower()),
        decoded.lower().count(term.lower()),
    ))
print("  READING: the essay names none of the five. It is not a counterexample")
print("  to the report's lowest-confidence claim; the claim is now CHECKED at")
print("  this candidate rather than merely bounded away from it.")

# ------------------------------------------------------------------ (5) CDX
print()
print("(5) HOW MANY CAPTURES EXIST, UNDER TWO ROUTES")
exact = json.loads(open(resolve(CDX_EXACT), encoding="utf-8").read())
prefix = json.loads(open(resolve(CDX_PREFIX), encoding="utf-8").read())
prefix2 = json.loads(open(resolve(CDX_PREFIX_2), encoding="utf-8").read())
print("  essay 1, CDX default (exact string) : %d capture(s)" % (len(exact) - 1))
print("  essay 1, CDX matchType=prefix       : %d capture(s)" % (len(prefix) - 1))
for row in prefix[1:]:
    print("     %s status %s length %s  %s" % (row[1], row[4], row[6], row[2][:96]))
print("  essay 2 (jacob-tan-en), matchType=prefix: %d capture(s)"
      % max(0, len(prefix2) - 1))
print("  READING: the CDX API matches the URL string exactly unless matchType")
print("  is given, and Medium URLs carry tracking query strings. 'One capture'")
print("  was a property of the query, not of the archive. The second essay is")
print("  genuinely uncaptured, and that survives the corrected route.")

# ----------------------------------------------- (6) second capture agreement
print()
print("(6) THE SAME RECOVERY AGAINST A SECOND, INDEPENDENT CAPTURE")
try:
    other = raw_bytes(SNAP2).decode("utf-8", "replace")
except SystemExit:
    other = None
if other is None:
    print("  the 9 April 2021 capture is not in this cache: NOT MEASURED")
else:
    paras2 = apollo_paragraphs(other)
    rec2 = "\n".join(p.get("text") or "" for p in paras2)
    print("  capture 20210409015757 bytes                :", len(other))
    print("  Paragraph records found                     :", len(paras2))
    print("  characters recovered                        :", len(rec2))
    print("  body text identical to the 10 April capture :", rec2 == recovered)

# --------------------------------------------- (7) the essay's own arithmetic
print()
print("(7) THE ESSAY'S OWN STATEMENT OF THE METHOD, EXECUTED")
print("  The essay writes: 'to find the roots of x^2 + bx + c, you want to find")
print("  two numbers that sum to b and multiply to c', then writes them as")
print("  b/2 + u and b/2 - u and solves (b/2 + u)(b/2 - u) = c for u.")
print("  Vieta gives sum = -b, so the recipe as written produces the roots of")
print("  x^2 - bx + c. Executed on two instances:")
for b, c in ((5, 6), (-3, 2)):
    disc = Fraction(b * b, 4) - c
    # exact rational square root, computed rather than asserted by hand
    u = Fraction(isqrt(disc.numerator), isqrt(disc.denominator))
    assert u * u == disc, (b, c, disc)
    r1, r2 = Fraction(b, 2) + u, Fraction(b, 2) - u
    named = [r * r + b * r + c for r in (r1, r2)]
    other_poly = [r * r - b * r + c for r in (r1, r2)]
    print("   b=%3d c=%3d -> pair (%s, %s): sum=%s product=%s" %
          (b, c, r1, r2, r1 + r2, r1 * r2))
    print("      evaluated in x^2 + bx + c (the polynomial the essay names): %s" %
          [str(v) for v in named])
    print("      evaluated in x^2 - bx + c (the one the recipe solves)    : %s" %
          [str(v) for v in other_poly])
print("  READING: a sign slip in a four-paragraph commentary, recorded because")
print("  the report measures exactly this — what survives transmission — and")
print("  because it is a fourth reachable presentation, not a fourth ADOPTER.")
