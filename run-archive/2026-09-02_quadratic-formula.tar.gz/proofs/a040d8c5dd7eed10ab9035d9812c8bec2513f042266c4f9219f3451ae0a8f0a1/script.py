#!/usr/bin/env python3
"""
q4_artifact_absences.py  --  blue-lane-3

WHAT THIS SETTLES.  This lane's method is to audit the subject artifacts
directly, and several of its findings are ABSENCES -- "the related-work page does
not list cut-the-knot", "neither version of the preprint cites Euclid", "a 2026
systematic review of the empirical literature never mentions Loh".  An absence
asserted from memory is exactly the failure mode this run is built to avoid: a
reader cannot tell a checked absence from an unchecked one, and neither can the
author afterwards.  So every absence the draft states is produced here, by
searching the cached bytes, and printed with the counts beside it.

WHAT IT READS.  Only files already in this run's fetch cache, located through
<run>/cache/index by URL.  Nothing is re-fetched, so every other seat can read
the same bytes; if a URL is missing from the index the program says so and fails
rather than reporting a silent zero.  That distinction is the whole point: a
regex that matches nothing and a file that was never fetched produce the same
number, and only one of them is evidence.

HTML is stripped with a crude tag remover before searching, so a term that occurs
only inside a tag attribute (a href, say) is still found -- the strip removes
tags but the search also runs on the RAW bytes, and both counts are printed.  A
term present in the raw bytes and absent from the stripped text is flagged rather
than swallowed.
"""

import datetime
import html
import json
import os
import re
import sys

RUN = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
CACHE = os.path.join(RUN, "cache")
INDEX = os.path.join(CACHE, "index")

SOURCES = {
    "preprint v1 (PDF text)": "https://arxiv.org/pdf/1910.06709v1",
    "preprint v2 (PDF text)": "https://arxiv.org/pdf/1910.06709v2",
    "poshenloh.com/quadraticrelated": "https://poshenloh.com/quadraticrelated",
    "poshenloh.com/quadraticdetail": "https://poshenloh.com/quadraticdetail",
    "poshenloh.com/quadraticcompsqr": "https://poshenloh.com/quadraticcompsqr",
    "poshenloh.com/quadratic": "https://www.poshenloh.com/quadratic/",
    "ESM 2026 systematic review": "https://link.springer.com/article/10.1007/s10649-026-10493-6",
    "cut-the-knot (2019-05-20 snapshot)":
        "http://web.archive.org/web/20190520014411/http://www.cut-the-knot.org:80/arithmetic/algebra/QuadraticFormula.shtml",
}


def load():
    idx = {}
    with open(INDEX, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                rec = json.loads(line)
                idx[rec["url"]] = rec
    out = {}
    for label, url in SOURCES.items():
        rec = idx.get(url)
        if rec is None:
            sys.exit("NOT IN CACHE: %s (%s) -- an absence measured against a file "
                     "that was never fetched is not an absence" % (label, url))
        sha = rec["sha"]
        txtpath = os.path.join(CACHE, sha + ".txt")
        path = txtpath if os.path.exists(txtpath) else os.path.join(CACHE, sha)
        raw = open(path, encoding="utf-8", errors="replace").read()
        stripped = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", raw)
        stripped = html.unescape(re.sub(r"(?s)<[^>]+>", " ", stripped))
        out[label] = (url, sha, raw, re.sub(r"\s+", " ", stripped))
    return out


def count(hay, term):
    return len(re.findall(re.escape(term), hay, flags=re.I))


def main():
    print("=" * 78)
    print("Q4. Absences, produced by search rather than by recollection")
    print("=" * 78)
    docs = load()
    print("\nsources read from the run cache:")
    for label, (url, sha, raw, txt) in docs.items():
        print("  %-36s sha %s  %7d raw bytes  %7d stripped chars"
              % (label, sha[:12], len(raw), len(txt)))

    terms = ["cut-the-knot", "cut the knot", "Brozinsky", "Bogomolny", "Euclid",
             "Elements", "Loh", "Po-Shen", "Savage", "Gowers", "Girard",
             "Funkhouser", "Diophantus", "zero-product", "zero product"]

    print("\nterm x source occurrence matrix (case-insensitive; stripped text)")
    hdr = "  %-14s" % "term" + "".join("%8s" % l.split()[0][:7] for l in docs)
    print(hdr)
    print("  " + "-" * (len(hdr) - 2))
    table = {}
    for t in terms:
        row = {}
        for label, (url, sha, raw, txt) in docs.items():
            row[label] = count(txt, t)
        table[t] = row
        print("  %-14s" % t + "".join("%8d" % row[l] for l in docs))

    print("\nRAW-BYTE cross-check (a term hiding in a tag attribute would show here)")
    for t in ["cut-the-knot", "Brozinsky", "Loh", "Euclid"]:
        for label, (url, sha, raw, txt) in docs.items():
            r, s = count(raw, t), count(txt, t)
            if r != s:
                print("  NOTE %-36s %-12s raw=%d stripped=%d" % (label, t, r, s))
    print("  (no NOTE lines above means raw and stripped agree on these terms)")

    print("\nCHECKS")
    ok = True

    def check(name, cond, detail=""):
        nonlocal ok
        print("  %-4s %s %s" % ("PASS" if cond else "FAIL", name, detail))
        ok = ok and cond

    rel = "poshenloh.com/quadraticrelated"
    check("A1. Loh's own related-work page never names cut-the-knot, Brozinsky or Bogomolny",
          table["cut-the-knot"][rel] == 0 and table["Brozinsky"][rel] == 0
          and table["Bogomolny"][rel] == 0,
          "(counts %d/%d/%d)" % (table["cut-the-knot"][rel], table["Brozinsky"][rel],
                                 table["Bogomolny"][rel]))
    check("A2. and the 2019 snapshot of that page DOES contain the Brozinsky derivation,"
          " so the absence is not an artefact of an empty fetch",
          table["Brozinsky"]["cut-the-knot (2019-05-20 snapshot)"] > 0,
          "(count %d)" % table["Brozinsky"]["cut-the-knot (2019-05-20 snapshot)"])
    v1, v2 = "preprint v1 (PDF text)", "preprint v2 (PDF text)"
    check("A3. neither version of the preprint mentions Euclid",
          table["Euclid"][v1] == 0 and table["Euclid"][v2] == 0)
    check("A4. and both versions DO mention Diophantus, so the fetch is not empty",
          table["Diophantus"][v1] > 0 and table["Diophantus"][v2] > 0,
          "(v1 %d, v2 %d)" % (table["Diophantus"][v1], table["Diophantus"][v2]))
    check("A5. v1 names neither Savage nor Gowers; v2 names both",
          table["Savage"][v1] == 0 and table["Gowers"][v1] == 0
          and table["Savage"][v2] > 0 and table["Gowers"][v2] > 0,
          "(v1 %d/%d, v2 %d/%d)" % (table["Savage"][v1], table["Gowers"][v1],
                                    table["Savage"][v2], table["Gowers"][v2]))
    check("A6. v1 cites Girard and Funkhouser; v2 cites neither",
          table["Girard"][v1] > 0 and table["Funkhouser"][v1] > 0
          and table["Girard"][v2] == 0 and table["Funkhouser"][v2] == 0,
          "(Girard v1 %d v2 %d; Funkhouser v1 %d v2 %d)"
          % (table["Girard"][v1], table["Girard"][v2],
             table["Funkhouser"][v1], table["Funkhouser"][v2]))
    esm = "ESM 2026 systematic review"
    check("A7. the 2026 ESM systematic review never mentions Loh",
          table["Loh"][esm] == 0 and table["Po-Shen"][esm] == 0,
          "(Loh %d, Po-Shen %d)" % (table["Loh"][esm], table["Po-Shen"][esm]))
    check("A8. and that review IS about this topic, so the zero is informative",
          count(docs[esm][3], "quadratic") > 50,
          "('quadratic' occurs %d times)" % count(docs[esm][3], "quadratic"))
    cs = "poshenloh.com/quadraticcompsqr"
    check("A9. the companion page on completing the square DOES invoke the"
          " zero-product property (the concession the preprint's footnote 3 omits)",
          table["zero-product"][cs] + table["zero product"][cs] > 0,
          "(count %d)" % (table["zero-product"][cs] + table["zero product"][cs]))
    check("A10. and the preprint's own text never uses the phrase 'zero-product'",
          table["zero-product"][v2] + table["zero product"][v2] == 0)

    # ---- artifact age arithmetic, so no date subtraction is done in prose
    print("\nARTIFACT AGE (computed, not asserted)")
    v2date = datetime.date(2019, 12, 16)     # arXiv submission history, v2
    v1date = datetime.date(2019, 10, 13)     # arXiv submission history, v1
    today = datetime.date.today()
    print("  v1 submitted            : %s" % v1date.isoformat())
    print("  v2 submitted            : %s" % v2date.isoformat())
    print("  today (container clock) : %s" % today.isoformat())
    print("  v1 -> v2                : %d days" % (v2date - v1date).days)
    print("  v2 -> today             : %d days (%.2f years)"
          % ((today - v2date).days, (today - v2date).days / 365.2425))
    ctk = datetime.date(2019, 5, 20)
    print("  cut-the-knot snapshot -> v1: %d days" % (v1date - ctk).days)

    print("\n%s" % ("all checks passed" if ok else "SOME CHECKS FAILED -- read them above"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
