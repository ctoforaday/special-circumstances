# Computes only the claim that base 3 passes the Fermat test for n = 91:
# 3^90 is congruent to 1 modulo 91.
n = 91
r3 = pow(3, 90, n)
print("3^90 mod 91 =", r3)
assert r3 == 1
print("base 3 passes the Fermat test for 91")
