# Computes only the claim that 13 is prime: if 13 were composite it would have a divisor
# d with 2 <= d <= sqrt(13), so it is enough to test every integer d from 2 through 3.
import math
m = 13
bound = math.isqrt(m)
print("floor(sqrt(13)) =", bound)
assert bound == 3
divisors = [d for d in range(2, bound + 1) if m % d == 0]
print("divisors of 13 in 2..", bound, ":", divisors)
assert divisors == []
print("13 is prime")
