import math

n = 91

# Square-root bound: a composite n has a prime factor at most sqrt(n).
root = math.sqrt(n)
print("sqrt(91) = %.2f" % root)
assert 9.5 < root < 9.6

# Trial division by every integer from 2 through 9.
divisors = [d for d in range(2, 10) if n % d == 0]
print("divisors of 91 from 2 through 9:", divisors)
assert divisors == [7]

# Cofactor and primality of 13 by trial division up to sqrt(13).
q = n // 7
print("91 / 7 =", q)
assert q == 13 and 7 * 13 == 91
assert all(13 % d for d in range(2, 4))

# Fermat test, base 3 passes; bases 2 and 5 fail.
for a in (2, 3, 5):
    r = pow(a, 90, n)
    print("Fermat base %d: %d^90 mod 91 = %d" % (a, a, r))
assert pow(3, 90, n) == 1
assert pow(2, 90, n) != 1
assert pow(5, 90, n) != 1

# Strong (Miller-Rabin style) test with n - 1 = 2 * 45.
def strong(a):
    x = pow(a, 45, n)
    if x in (1, n - 1):
        return "pass", x
    return ("pass" if pow(x, 2, n) == n - 1 else "fail"), x

r3, x3 = strong(3)
r10, x10 = strong(10)
print("strong base 3: %s (3^45 mod 91 = %d)" % (r3, x3))
print("strong base 10: %s (10^45 mod 91 = %d)" % (r10, x10))
assert r3 == "fail" and x3 != 1 and x3 != n - 1
assert r10 == "pass" and x10 == n - 1
print("factorisation and tests: all assertions hold")
