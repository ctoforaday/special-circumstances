# Z[1/7]: 7 is a unit, so 91 = 7 * 13 is associate to 13.
# 13 is prime there because Z[1/7]/(13) is Z/13, a field, since 7 has an inverse mod 13.
inv7 = next(x for x in range(1, 13) if (7 * x) % 13 == 1)
print("inverse of 7 mod 13 =", inv7)
assert inv7 == 2

# Gaussian integers: norm is a^2 + b^2. 7 is not a sum of two squares; 13 = 3^2 + 2^2 = (3+2i)(3-2i).
sums = {a * a + b * b for a in range(0, 8) for b in range(0, 8)}
print("7 is a sum of two squares (0..7 search):", 7 in sums)
assert 7 not in sums
assert 3 * 3 + 2 * 2 == 13

# Eisenstein integers: norm is a^2 - ab + b^2.
N = lambda a, b: a * a - a * b + b * b
print("Eisenstein norms: N(3,1) =", N(3, 1), " N(4,1) =", N(4, 1))
assert N(3, 1) == 7 and N(4, 1) == 13

# A unit has norm 1; 7 and 13 have norms 49 and 169 in both rings, so neither is a unit.
assert 7 * 7 != 1 and 13 * 13 != 1
print("ring checks: all assertions hold")
