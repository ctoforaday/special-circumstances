# Computes only the factorisation claim: trial division of 91 by each integer 2..9
# finds exactly one divisor, 7; 91 / 7 = 13; and 13 has no divisor in 2..3, so 13 is prime
# (3 is the largest integer whose square is at most 13).
n = 91
divisors = [d for d in range(2, 10) if n % d == 0]
print("divisors of 91 in 2..9:", divisors)
assert divisors == [7]
q = n // 7
print("91 / 7 =", q)
assert q == 13 and 7 * q == n
small = [d for d in range(2, 4) if 13 % d == 0]
print("divisors of 13 in 2..3:", small)
assert small == []
print("factorisation claim holds: 91 = 7 * 13, and 13 has no divisor in 2..3")
