# Checks the position of 91 in the composite-number sequence (OEIS A002808, b-file)
# and that 91 is absent from the prime sequence (OEIS A000040, b-file).
import sys

COMPOSITE_B = "/home/gblock_ctoforaday_com/.claude/scratch/universe-m19/src/research/2026-10-10_is-91-prime/cache/19961e3913c76c67e4800571ba202dc4dc61cb624a954cf34e67df713ae6eabb"
PRIME_B = "/home/gblock_ctoforaday_com/.claude/scratch/universe-m19/src/research/2026-10-10_is-91-prime/cache/ef3beecd3bca4a02ca5053e5a3afc3e0d69e43b49b9aaa91073fc4fb9e4d50de"

def is_prime(m):
    if m < 2:
        return False
    d = 2
    while d * d <= m:
        if m % d == 0:
            return False
        d += 1
    return True

def read_pairs(path):
    out = {}
    with open(path) as fh:
        for line in fh:
            p = line.split()
            if len(p) == 2 and not line.startswith("#"):
                out[int(p[0])] = int(p[1])
    return out

ok = True
b = read_pairs(COMPOSITE_B)
composites_upto_91 = [m for m in range(2, 92) if not is_prime(m)]
print("composites in 2..91 by trial division:", len(composites_upto_91))
print("b-file a(66) =", b[66], "; 91 is composite:", not is_prime(91))
if len(composites_upto_91) != 66 or b[66] != 91 or composites_upto_91[65] != 91:
    ok = False
    print("FAIL: 91 is not the 66th composite")
# the b-file's first 66 terms must equal the composites up to 91, in order
first66 = [b[i] for i in range(1, 67)]
if first66 != composites_upto_91:
    ok = False
    print("FAIL: first 66 b-file terms differ from trial-division composites")
else:
    print("first 66 b-file terms equal the composites up to 91 in order: True")
print("b-file terms present: n=1..%d, largest value %d" % (max(b), b[max(b)]))

p = read_pairs(PRIME_B)
primes = set(p.values())
print("prime b-file terms:", len(p), "largest prime", max(primes))
print("91 in prime b-file:", 91 in primes)
if 91 in primes:
    ok = False
    print("FAIL: 91 listed as prime")
primes_check = [m for m in range(2, 105000) if is_prime(m)]
print("primes below 105000 by trial division agree with prime b-file on 2..max:",
      primes_check[:len(p)] == [p[i] for i in range(1, len(p) + 1)])
print("RESULT:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
