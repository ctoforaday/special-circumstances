# Computes only the strong-test claim for base 3 and n = 91. Here n - 1 = 2 * 45 with 45 odd,
# so s = 1 and the only strong probable-prime condition is a^45 congruent to +1 or -1 modulo n.
n = 91
d = 45
x = pow(3, d, n)
print("3^45 mod 91 =", x)
passes = (x == 1 or x == n - 1)
print("strong test in base 3 passes:", passes)
assert not passes
print("base 3 gives a failed strong test, so 91 is reported composite")
