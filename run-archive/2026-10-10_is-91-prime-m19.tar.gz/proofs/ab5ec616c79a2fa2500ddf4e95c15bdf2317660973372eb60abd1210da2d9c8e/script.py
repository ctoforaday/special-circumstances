# Computes only the strong-test claim for base 10 and n = 91. Here n - 1 = 2 * 45 with 45 odd,
# so s = 1 and the only strong probable-prime condition is a^45 congruent to +1 or -1 modulo n.
n = 91
d = 45
x = pow(10, d, n)
print("10^45 mod 91 =", x)
passes = (x == 1 or x == n - 1)
print("strong test in base 10 passes:", passes)
assert passes and x == n - 1
print("base 10 gives a passed strong test, since 10^45 is congruent to 90 = -1 modulo 91")
