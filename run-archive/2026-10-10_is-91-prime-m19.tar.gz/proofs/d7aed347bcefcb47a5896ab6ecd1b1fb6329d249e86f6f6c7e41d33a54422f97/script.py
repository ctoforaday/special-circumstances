# Computes only the claim that bases 2 and 5 fail the Fermat test for n = 91:
# 2^90 and 5^90 are each not congruent to 1 modulo 91 (both are 64).
n = 91
r2 = pow(2, 90, n)
r5 = pow(5, 90, n)
print("2^90 mod 91 =", r2)
print("5^90 mod 91 =", r5)
assert r2 == 64 and r5 == 64
assert r2 != 1 and r5 != 1
print("bases 2 and 5 fail the Fermat test for 91")
