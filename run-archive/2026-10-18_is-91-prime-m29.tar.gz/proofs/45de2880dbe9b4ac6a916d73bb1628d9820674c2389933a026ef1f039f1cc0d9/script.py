"""Recompute every modular-arithmetic and divisibility figure the report states about n = 91.

Prints each figure on its own line so a reader can compare it with the report.
Uses only the Python standard library; no network access.
"""

N = 91


def trial_divisors(n):
    """Integers d with 2 <= d <= floor(sqrt(n)) that divide n."""
    limit = int(n ** 0.5)
    return [d for d in range(2, limit + 1) if n % d == 0], limit


def strong_test_passes(n, base):
    """Miller-Rabin strong probable-prime test for odd n, one base."""
    s, d = 0, n - 1
    while d % 2 == 0:
        s += 1
        d //= 2
    x = pow(base, d, n)
    if x in (1, n - 1):
        return True, x
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True, x
    return False, x


def is_prime_trial(n):
    if n < 2:
        return False
    return all(n % d for d in range(2, int(n ** 0.5) + 1))


def main():
    n = N
    print(f"n = {n}, n-1 = {n-1}")

    divs, limit = trial_divisors(n)
    print(f"trial divisors 2..{limit}: {divs}; cofactor {n // divs[0]}")

    for b in (2, 3, 5, 7, 9):
        from math import gcd
        if gcd(b, n) != 1:
            print(f"Fermat base {b}: shares factor with n, not usable (gcd {gcd(b, n)})")
            continue
        print(f"Fermat base {b}: {b}^{n-1} mod {n} = {pow(b, n-1, n)}")

    for b in (2, 3, 5, 9):
        print(f"{b}^45 mod {n} = {pow(b, 45, n)}")

    for b in (2, 3, 5, 9):
        ok, x = strong_test_passes(n, b)
        print(f"strong test base {b}: {'passes' if ok else 'rejects'} (final residue {x})")

    pseudo3 = [m for m in range(4, 1000) if not is_prime_trial(m) and pow(3, m - 1, m) == 1]
    print(f"composites m < 1000 with 3^(m-1) = 1 mod m: {pseudo3[:6]}")
    print(f"smallest composite passing Fermat base 3 is {pseudo3[0]}")

    primes_near = [m for m in range(80, 106) if is_prime_trial(m)]
    print(f"primes 80..105: {primes_near}; 91 prime? {is_prime_trial(91)}")

    # Carmichael / Korselt: squarefree and (p-1) | (n-1) for every prime p | n
    p_factors = [7, 13]
    korselt = all((n - 1) % (p - 1) == 0 for p in p_factors)
    print(f"Korselt criterion holds for 91? {korselt}; 12 divides 90? {90 % 12 == 0}; 90 mod 12 = {90 % 12}")

    # Gaussian integers: 13 = (3+2i)(3-2i)
    print("13 = (3+2i)(3-2i)?", (3 + 2j) * (3 - 2j) == 13)
    print("7 mod 4 =", 7 % 4, "; 13 mod 4 =", 13 % 4)


if __name__ == "__main__":
    main()
