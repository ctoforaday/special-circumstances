"""Recompute the modular powers, trial divisors, Korselt residue, base-3 Fermat pseudoprimes and Gaussian checks stated for n = 91, using only the Python standard library."""
N = 91


def is_prime(m):
    return m >= 2 and all(m % d for d in range(2, int(m ** 0.5) + 1))


def main():
    n = N
    divs = [d for d in range(2, 10) if n % d == 0]
    print(f"trial divisors of {n} in 2..9: {divs}; cofactor {n // divs[0]}")
    for b in (2, 3, 5, 9):
        print(f"{b}^90 mod {n} = {pow(b, n - 1, n)}")
    for b in (2, 3, 5, 9):
        print(f"{b}^45 mod {n} = {pow(b, 45, n)}")
    pseudo = [m for m in range(4, 100) if not is_prime(m) and pow(3, m - 1, m) == 1]
    print(f"composites below 100 passing the base-3 Fermat test: {pseudo}")
    print(f"Korselt: 90 mod 12 = {90 % 12}")
    print(f"Gaussian: (3+2i)(3-2i) == 13: {(3 + 2j) * (3 - 2j) == 13}; 7 mod 4 = {7 % 4}; 13 mod 4 = {13 % 4}")


if __name__ == "__main__":
    main()
