# Computations behind the figures on the number 91: trial division, Fermat tests,
# the strong probable-prime test, the Carmichael condition, the Korselt check and
# the Gaussian-integer factorisation. Every figure is asserted, so a clean exit
# means each stated value holds. Needs no network access.
from math import gcd, isqrt

N = 91

# Trial division over 2 .. floor(sqrt(91)).
assert isqrt(N) == 9
divisors = [d for d in range(2, isqrt(N) + 1) if N % d == 0]
assert divisors == [7] and N // 7 == 13
print("trial divisors of 91 in [2, 9]:", divisors, "; cofactor:", N // 7)

# Plain Fermat tests: b^90 mod 91.
assert pow(2, 90, N) == 64
assert pow(3, 90, N) == 1
assert pow(5, 90, N) == 64
assert pow(9, 90, N) == 1
assert gcd(7, N) == 7
print("2^90 mod 91 =", pow(2, 90, N), "; 3^90 mod 91 =", pow(3, 90, N),
      "; 5^90 mod 91 =", pow(5, 90, N), "; 9^90 mod 91 =", pow(9, 90, N))

# Smallest base-3 Fermat pseudoprime: composites n <= 91 with 3^(n-1) = 1 mod n.
def is_prime(n):
    return n > 1 and all(n % d for d in range(2, isqrt(n) + 1))

base3_pseudoprimes = [n for n in range(4, N + 1) if not is_prime(n) and pow(3, n - 1, n) == 1]
assert base3_pseudoprimes == [91]
print("composites <= 91 passing the base-3 Fermat test:", base3_pseudoprimes)

# Strong probable-prime test: n - 1 = 2^s * d with d odd; base b passes if
# b^d = 1 mod n, or b^(2^r d) = -1 mod n for some 0 <= r < s.
def strong_pass(n, b):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(b, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False

assert 90 == 2 * 45
assert pow(3, 45, N) == 27 and not strong_pass(N, 3)
assert pow(2, 45, N) == 57 and not strong_pass(N, 2)
assert pow(5, 45, N) == 83 and not strong_pass(N, 5)
print("3^45 mod 91 =", pow(3, 45, N), "; 2^45 mod 91 =", pow(2, 45, N),
      "; 5^45 mod 91 =", pow(5, 45, N))

# Carmichael condition: a Fermat pseudoprime to every base coprime to n.
# Base 2 is coprime to 91 and fails, so 91 is not a Carmichael number.
assert gcd(2, N) == 1 and pow(2, 90, N) != 1

# Korselt check: squarefree, and p - 1 divides 90 for each prime p dividing 91.
assert 90 % 12 == 6  # p = 13, p - 1 = 12, remainder 6, so 12 does not divide 90
assert 90 % 6 == 0   # p = 7, p - 1 = 6 divides 90
print("Korselt: 90 mod 12 =", 90 % 12, "; 90 mod 6 =", 90 % 6)

# Gaussian integers: 13 = (3 + 2i)(3 - 2i), and 91 = 7 (3 + 2i)(3 - 2i).
assert (3 + 2j) * (3 - 2j) == 13 + 0j
assert 7 * (3 + 2j) * (3 - 2j) == 91 + 0j
assert 7 % 4 == 3 and 13 % 4 == 1

print("all stated figures hold")
