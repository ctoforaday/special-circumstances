N = 2**31 - 1
BOUND = 4759123141


def strong_witness(a, n):
    # True when base a shows odd n > 2 composite under the strong probable-prime test.
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return False
    for _ in range(r - 1):
        x = x * x % n
        if x == n - 1:
            return False
    return True


def smallest_factor(n):
    f = 2
    while f * f <= n:
        if n % f == 0:
            return f
        f += 1
    return n


print("cited deterministic bound =", BOUND)
print("2^31 - 1 is below the bound:", N < BOUND)
print("bases 2, 7, 61 that witness compositeness of 2^31 - 1:",
      [a for a in (2, 7, 61) if strong_witness(a, N)])
print("the three-base set passes 2^31 - 1 with no witness:",
      not any(strong_witness(a, N) for a in (2, 7, 61)))
for a in (2, 7, 61):
    # Smallest odd composite that base a flags; the factor is found by trial division, so the composite is named.
    n = next(m for m in range(3, 10**6, 2)
             if smallest_factor(m) != m and strong_witness(a, m))
    f = smallest_factor(n)
    print(f"base {a} flags the composite {n} = {f} x {n // f} as composite")
