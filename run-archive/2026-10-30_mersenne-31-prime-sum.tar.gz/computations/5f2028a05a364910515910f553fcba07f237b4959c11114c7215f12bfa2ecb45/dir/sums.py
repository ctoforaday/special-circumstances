import math

N = 10**6

def sieve(n):
    flags = bytearray([1]) * (n + 1)
    flags[0] = 0
    flags[1] = 0
    for i in range(2, int(n ** 0.5) + 1):
        if flags[i]:
            flags[i*i::i] = bytearray(len(flags[i*i::i]))
    return [i for i in range(n + 1) if flags[i]]

primes = sieve(N)
strict_sum = sum(q for q in primes if q < N)
inclusive_sum = sum(q for q in primes if q <= N)
print("primes below 10^6, sieve:", sum(1 for q in primes if q < N))
print("sum of primes below 10^6, sieve:", strict_sum)
print("sum of primes at most 10^6, sieve:", inclusive_sum)
print("10^6 is prime:", N in set(primes))

# Independent method: trial division of each integer, no sieve array.
def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    r = math.isqrt(n)
    for d in range(3, r + 1, 2):
        if n % d == 0:
            return False
    return True

td_sum = 0
td_count = 0
for n in range(2, N):
    if is_prime(n):
        td_sum += n
        td_count += 1
print("primes below 10^6, trial division:", td_count)
print("sum of primes below 10^6, trial division:", td_sum)
print("methods agree:", td_sum == strict_sum)
