import collections
import json
import pathlib

here = pathlib.Path(__file__).resolve().parent
rows = json.loads((here / "evidence.json").read_text(encoding="utf-8"))

by_sha = collections.defaultdict(lambda: {"programs": set(), "anchors": []})
for row in rows:
    by_sha[row["sha256"]]["programs"].add(row["program"])
    by_sha[row["sha256"]]["anchors"].append(row["anchor"])

names = {row["program"] for row in rows}

print("computations on the record:", len(rows))
print("distinct program versions (distinct sha256):", len(by_sha))
print("distinct program names:", len(names))
for sha in sorted(by_sha, key=lambda s: (sorted(by_sha[s]["programs"]), s)):
    entry = by_sha[sha]
    print(
        sha[:12],
        "programs=" + ",".join(sorted(entry["programs"])),
        "computations=" + ",".join(sorted(entry["anchors"])),
    )
