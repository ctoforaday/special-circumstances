import math

M = 2**31 - 1

# Trial division by every integer from 2 to the integer square root of M.
root = math.isqrt(M)
divisors = [d for d in range(2, root + 1) if M % d == 0]
print("M =", M)
print("integer square root of M =", root)
print("divisors of M in 2..root:", divisors)
print("trial division verdict:", "prime" if not divisors else "composite")

# Lucas-Lehmer test for an odd prime exponent p: s0 = 4, s_(i+1) = s_i^2 - 2 mod (2^p - 1), residue s_(p-2).
def lucas_lehmer_residue(p):
    m = 2**p - 1
    s = 4
    for _ in range(p - 2):
        s = (s * s - 2) % m
    return s

r31 = lucas_lehmer_residue(31)
print("Lucas-Lehmer residue for p = 31:", r31)
print("Lucas-Lehmer verdict for p = 31:", "prime" if r31 == 0 else "composite")
print("residue one step later, mod M:", (r31 * r31 - 2) % M)
print("control p = 11 (2^11 - 1 = 2047), residue:", lucas_lehmer_residue(11))
print("control p = 7 (2^7 - 1 = 127), residue:", lucas_lehmer_residue(7))
print("trial divisors of 2047 up to its root:", [d for d in range(2, math.isqrt(2047) + 1) if 2047 % d == 0])
print("46340 squared:", 46340**2, " 46341 squared:", 46341**2, " M:", M)
