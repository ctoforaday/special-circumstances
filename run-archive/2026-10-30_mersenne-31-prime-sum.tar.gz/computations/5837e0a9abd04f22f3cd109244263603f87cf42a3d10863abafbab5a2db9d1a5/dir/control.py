def strong_witness(a, n):
    # True when base a shows odd n > 2 composite (strong-test witness).
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return False
    for _ in range(r - 1):
        x = x * x % n
        if x == n - 1:
            return False
    return True


print("91 = 7 * 13 composite:", 7 * 13 == 91)
print("base 2 witnesses 91:", strong_witness(2, 91))
print("2047 = 23 * 89 composite:", 23 * 89 == 2047)
print("base 2 witnesses 2047:", strong_witness(2, 2047))
