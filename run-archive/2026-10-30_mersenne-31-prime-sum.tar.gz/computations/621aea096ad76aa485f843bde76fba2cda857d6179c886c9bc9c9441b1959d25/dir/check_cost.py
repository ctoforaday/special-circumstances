import re

SENTENCE = "The cost is the programs and their output, plus the sourcing."
numerals = re.findall(r"[0-9]+|\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fourteen|fifteen)\b", SENTENCE, re.IGNORECASE)
print("sentence:", SENTENCE)
print("numerals or number words in the cost sentence:", len(numerals))
print("the sentence states no count, so no count in it can disagree with the record:", len(numerals) == 0)
