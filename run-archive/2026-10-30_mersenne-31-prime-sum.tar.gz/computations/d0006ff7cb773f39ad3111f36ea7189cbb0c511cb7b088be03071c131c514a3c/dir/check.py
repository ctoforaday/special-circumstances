N = 2**31 - 1
BOUND = 4759123141


def strong_witness(a, n):
    # True when base a shows odd n > 2 composite (strong-test witness).
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return False
    for _ in range(r - 1):
        x = x * x % n
        if x == n - 1:
            return False
    return True


print("2^31 - 1 =", N)
print("cited deterministic bound =", BOUND)
print("2^31 - 1 is below the bound:", N < BOUND)
witnesses = [a for a in (2, 7, 61) if strong_witness(a, N)]
print("bases 2, 7, 61 that witness compositeness of 2^31 - 1:", witnesses)
print("the three-base set passes 2^31 - 1 with no witness:", witnesses == [])
