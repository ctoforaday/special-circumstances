M = 2**31 - 1

def is_witness(a, n):
    # True when a shows n composite: n odd, n > 2, n - 1 = 2^r * d with d odd.
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return False
    for _ in range(r - 1):
        x = x * x % n
        if x == n - 1:
            return False
    return True

witnesses = [a for a in range(2, 201) if is_witness(a, M)]
print("bases 2..200 that witness compositeness of M:", witnesses)
print("bases 2, 7, 61 that witness compositeness of M:", [a for a in (2, 7, 61) if is_witness(a, M)])
print("control 91 = 7 * 13, base 2 witnesses it:", is_witness(2, 91))
print("control 2047 = 23 * 89 (base-2 strong pseudoprime), base 2 witnesses it:", is_witness(2, 2047))
