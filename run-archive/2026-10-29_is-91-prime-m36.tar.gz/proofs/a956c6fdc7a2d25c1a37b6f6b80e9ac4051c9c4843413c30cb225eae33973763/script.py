"""Counts of Fermat-test outcomes for 91 over bases a with 2 <= a <= 90 coprime to 91.

Settles the report sentence giving the 71 / 35 / 36 counts. Standard library only.
"""
from math import gcd

N = 91
bases = [a for a in range(2, N) if gcd(a, N) == 1]
passing = [a for a in bases if pow(a, N - 1, N) == 1]
failing = [a for a in bases if pow(a, N - 1, N) != 1]
print(f"coprime bases in [2, 90]: {len(bases)}; pass: {len(passing)}; fail: {len(failing)}")
assert (len(bases), len(passing), len(failing)) == (71, 35, 36)
print("RESULT: 71 coprime bases, 35 pass the Fermat test, 36 fail")
