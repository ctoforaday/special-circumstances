"""Count the phrase "not a prime" in the cached copy of the math.answers page.

Reads the cached text of https://math.answers.com/basic-math/Is_91_a_prime_number_under_100
(sha256 cf7e6e72...), counts non-overlapping case-insensitive occurrences of the
literal phrase, counts the lines that carry it, and prints each such line so a
reader can see which answer it belongs to.
"""
import re
import sys

CACHE = "/home/gblock_ctoforaday_com/.claude/scratch/universe-m36/src/research/2026-10-29_is-91-prime/cache/cf7e6e7212c0672b13632f8d00df085bf868d64d66f6dba5e392df33d6c25d11.txt"
PHRASE = re.compile(r"not a prime", re.IGNORECASE)

with open(CACHE, encoding="utf-8") as fh:
    lines = fh.read().split("\n")

occurrences = 0
hit_lines = []
for number, line in enumerate(lines, start=1):
    found = PHRASE.findall(line)
    if found:
        occurrences += len(found)
        hit_lines.append((number, line.strip()))

print(f"total lines in cached copy: {len(lines)}")
print(f"occurrences of 'not a prime' (case-insensitive, literal): {occurrences}")
print(f"lines carrying the phrase: {len(hit_lines)}")
distinct = {text.lower() for _, text in hit_lines}
print(f"distinct line texts carrying the phrase: {len(distinct)}")
for number, text in hit_lines:
    print(f"  line {number}: {text[:160]}")

# Literal example quoted in the report must occur verbatim in the cached copy.
example = "91 is not a Prime number"
print(f"example '{example}' present verbatim: {example in '\n'.join(lines)}")

sys.exit(0 if occurrences == 5 else 1)
