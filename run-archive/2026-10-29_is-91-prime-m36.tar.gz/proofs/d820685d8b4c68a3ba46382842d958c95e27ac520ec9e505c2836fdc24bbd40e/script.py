"""Positive divisors of 91 under the standard definition of a prime.

The definition: a prime is an integer greater than 1 whose only positive
divisors are 1 and itself. Settles inquiry Q-b8842f51. Standard library only.
"""
N = 91
divisors = [d for d in range(1, N + 1) if N % d == 0]
print(f"positive divisors of {N}: {divisors}")
extra = [d for d in divisors if d not in (1, N)]
print(f"divisors other than 1 and {N}: {extra}")
is_prime_by_definition = N > 1 and extra == []
print(f"prime by definition: {is_prime_by_definition}")
assert extra == [7, 13] and is_prime_by_definition is False
print("RESULT: 91 has positive divisors 7 and 13 besides 1 and 91; not prime by the definition")
