"""Trial division of 91 by every integer from 2 up to floor(sqrt(91)).

Settles inquiry Q-0b3083c2: does trial division find a divisor of 91 other
than 1 and 91? Uses only the Python standard library.
"""
from math import isqrt

N = 91
bound = isqrt(N)  # 9
found = [d for d in range(2, bound + 1) if N % d == 0]
print(f"N = {N}, trial-division bound floor(sqrt(N)) = {bound}")
print(f"divisors d in [2, {bound}] with d | N: {found}")
cofactor = N // found[0] if found else None
print(f"first divisor found: {found[0] if found else None}; cofactor: {cofactor}")
print(f"7 * 13 = {7 * 13}")
assert found and found[0] == 7 and cofactor == 13, "unexpected trial-division result"
print("RESULT: trial division finds the nontrivial divisor 7; 91 = 7 * 13 is composite")
