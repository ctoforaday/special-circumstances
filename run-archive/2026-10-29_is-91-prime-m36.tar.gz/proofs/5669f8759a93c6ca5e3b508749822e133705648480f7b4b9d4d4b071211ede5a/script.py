"""Least composite n with 3^(n-1) == 1 (mod n), by direct search from 4 upward.

Settles the report sentence that 91 is the least composite number passing the
base-3 Fermat test. Standard library only.
"""

def is_prime(n):
    return n > 1 and all(n % d for d in range(2, int(n ** 0.5) + 1))

least = None
for n in range(4, 200):
    if not is_prime(n) and pow(3, n - 1, n) == 1:
        least = n
        break
print(f"least composite n with 3^(n-1) == 1 (mod n): {least}")
print(f"3^90 mod 91 = {pow(3, 90, 91)}; 91 composite: {not is_prime(91)}")
assert least == 91 and not is_prime(91)
print("RESULT: 91 is the least composite number that passes the base-3 Fermat test")
