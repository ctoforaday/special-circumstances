"""Fermat primality test on 91 in every base a with 2 <= a <= 90.

Settles inquiry Q-b4251bea: does a single Fermat test in one fixed base
certify primality, or can some base give a pass although 91 is composite?
Uses only the Python standard library.
"""
from math import gcd

N = 91
coprime_bases = [a for a in range(2, N) if gcd(a, N) == 1]
passing = [a for a in coprime_bases if pow(a, N - 1, N) == 1]
failing = [a for a in coprime_bases if pow(a, N - 1, N) != 1]

print(f"N = {N}; bases coprime to N in [2, {N-1}]: {len(coprime_bases)}")
print(f"bases with a^(N-1) == 1 (mod N): {len(passing)}")
print(f"passing bases: {passing}")
print(f"failing bases: {failing}")

# Independent check via the factorisation 91 = 7 * 13: a^90 == 1 (mod 91)
# holds iff it holds mod 7 and mod 13.
def passes_mod(p, a):
    return pow(a, 90, p) == 1

by_crt = [a for a in coprime_bases if passes_mod(7, a) and passes_mod(13, a)]
print(f"CRT cross-check gives the same set: {by_crt == passing}")
assert by_crt == passing

# Base 3 is a concrete witness: 3^90 mod 91
print(f"witness: 3^90 mod 91 = {pow(3, 90, 91)}")
assert pow(3, 90, 91) == 1 and N == 7 * 13
print("RESULT: a Fermat pass in base 3 (and in other bases) occurs although 91 is composite;"
      " one base alone cannot certify primality")
