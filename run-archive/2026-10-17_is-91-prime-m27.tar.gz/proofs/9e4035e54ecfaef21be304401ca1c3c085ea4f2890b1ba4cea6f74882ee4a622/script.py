# Arithmetic behind the report's residues: trial division, Fermat and Miller-Rabin tests on 91.
n = 91
def divisors_upto_sqrt(n):
    import math
    r = math.isqrt(n)
    return [p for p in range(2, r + 1) if all(p % q for q in range(2, int(p**0.5) + 1)) and n % p == 0]
primes_checked = [p for p in range(2, 10) if all(p % q for q in range(2, p))]
print("primes up to sqrt(91)=9.54:", primes_checked)
print("remainders of 91 mod each:", {p: n % p for p in primes_checked})
print("prime divisors found:", divisors_upto_sqrt(n), "cofactor:", n // 7)
print("2^90 mod 91 =", pow(2, 90, n), "; mod 7 =", pow(2, 90, 7), "; mod 13 =", pow(2, 90, 13))
print("3^90 mod 91 =", pow(3, 90, n), "(Fermat base 3 passes iff 1)")
x = pow(3, 45, n)
print("3^45 mod 91 =", x, "; 27^2 mod 91 =", (x * x) % n, "; 27 not in {1, 90}:", x not in (1, n - 1))
print("Miller-Rabin base 3 rejects 91:", x not in (1, n - 1) and (x * x) % n == 1)
