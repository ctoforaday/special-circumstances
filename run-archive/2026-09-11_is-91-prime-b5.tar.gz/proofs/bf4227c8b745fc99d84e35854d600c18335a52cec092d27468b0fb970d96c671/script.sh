#!/usr/bin/env bash
# Runs OpenSSL's prime subcommand on 91 and prints its exact output.
set -euo pipefail
openssl prime 91
