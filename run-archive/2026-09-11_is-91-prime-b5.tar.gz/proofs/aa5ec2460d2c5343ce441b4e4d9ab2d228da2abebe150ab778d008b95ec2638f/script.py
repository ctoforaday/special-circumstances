#!/usr/bin/env python3
"""Full Miller-Rabin strong-liar sweep for n=91 over every base coprime to n in [2,90]."""
import math


def is_strong_liar(n, a):
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(r - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True
    return False


n = 91
fermat_liars = []
mr_liars = []
checked = 0
for a in range(2, n):
    if math.gcd(a, n) != 1:
        continue
    checked += 1
    if pow(a, n - 1, n) == 1:
        fermat_liars.append(a)
    if is_strong_liar(n, a):
        mr_liars.append(a)

print(f"n = {n}")
print(f"coprime bases checked in [2,{n-1}]: {checked}")
print(f"Miller-Rabin strong liars: {len(mr_liars)} -> {mr_liars}")
print(f"Fermat liars: {len(fermat_liars)} -> {fermat_liars}")
print(f"MR liars subset of Fermat liars: {set(mr_liars).issubset(set(fermat_liars))}")
for a in (17, 29, 10):
    print(f"  base {a} MR liar: {a in mr_liars}")
