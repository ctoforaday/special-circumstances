#!/usr/bin/env python3
"""Full Fermat-liar sweep for n=91 over every base coprime to n in [2,90]."""
import math

n = 91
liars = []
checked = 0
for a in range(2, n):
    if math.gcd(a, n) != 1:
        continue
    checked += 1
    if pow(a, n - 1, n) == 1:
        liars.append(a)

print(f"n = {n}")
print(f"coprime bases checked in [2,{n-1}]: {checked}")
print(f"Fermat liars (a^(n-1) mod n == 1): {len(liars)} -> {liars}")
print(f"correctly-exposing bases: {checked - len(liars)}")
for a in (3, 10, 17, 29):
    print(f"  base {a} in liar set: {a in liars}")
