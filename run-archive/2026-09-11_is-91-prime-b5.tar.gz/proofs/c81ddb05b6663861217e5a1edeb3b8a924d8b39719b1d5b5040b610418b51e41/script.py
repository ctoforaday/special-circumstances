#!/usr/bin/env python3
"""Deterministic primality check for 91: trial division to floor(sqrt(91)),
plus a Fermat test and a Miller-Rabin test at several bases, for cross-check."""
import math

n = 91
bound = math.isqrt(n)
print(f"n = {n}, isqrt(n) = {bound}")

divisors = []
for d in range(2, bound + 1):
    if n % d == 0:
        divisors.append((d, n // d))
print(f"trial division 2..{bound}: divisors found = {divisors}")
print(f"91 is {'COMPOSITE' if divisors else 'PRIME'} by trial division")

def fermat_witness(n, a):
    return pow(a, n - 1, n)

print("\nFermat test (a^(n-1) mod n, want 1 for probable prime):")
for a in [2, 3, 5, 7, 13]:
    if math.gcd(a, n) != 1:
        print(f"  a={a}: gcd(a,n)={math.gcd(a,n)} != 1 -> a is a factor witness, n composite")
        continue
    r = fermat_witness(n, a)
    print(f"  a={a}: {a}^{n-1} mod {n} = {r} -> {'PASSES (probable prime)' if r == 1 else 'FAILS (n is composite, a is a Fermat witness)'}")

def miller_rabin(n, a):
    if n % a == 0:
        return False, "a divides n"
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True, f"x0={x}"
    for _ in range(r - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True, "found -1 in sequence"
    return False, f"no -1 found, final x={x}"

print("\nMiller-Rabin test at several bases (n-1 = d*2^r):")
for a in [2, 3, 5, 7, 13, 17]:
    ok, detail = miller_rabin(n, a)
    print(f"  base a={a}: {'probable prime' if ok else 'COMPOSITE WITNESS'} ({detail})")

print(f"\nFinal factorization: {n} = {divisors[0][0]} x {divisors[0][1]}" if divisors else f"\n{n} has no divisors up to {bound}: prime")
