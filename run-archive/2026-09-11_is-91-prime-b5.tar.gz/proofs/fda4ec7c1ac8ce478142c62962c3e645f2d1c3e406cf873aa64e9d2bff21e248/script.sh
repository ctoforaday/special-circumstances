#!/usr/bin/env bash
# Runs GNU coreutils factor on 91 and prints its exact output.
set -euo pipefail
factor 91
